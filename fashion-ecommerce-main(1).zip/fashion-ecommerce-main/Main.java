/**
 * Entry point for the Fashion E-Commerce Platform CLI application.
 * Creates all repository, service, and presentation objects, then
 * starts the main application loop.
 */
public class Main {

    /**
     * Application entry point.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Build the repository layer
        UserRepository userRepository = new UserRepository();
        ProductRepository productRepository = new ProductRepository();

        // Build the service layer, injecting repositories as dependencies
        AuthService authService = new AuthService(userRepository);
        CartService cartService = new CartService(productRepository);
        OrderService orderService = new OrderService();
        PaymentService paymentService = new PaymentService();

        // Build the presentation layer, injecting all services
        MainMenu mainMenu = new MainMenu(authService, cartService, orderService, paymentService);

        // Start the CLI application loop
        mainMenu.run();
    }
}
