# Fashion E-Commerce Platform

A complete Java CLI application for a fashion e-commerce platform built with a clean
Layered Architecture, SOLID principles, and full Javadoc coverage.

---

## How to Compile and Run

### Requirements

- Java 8 or higher

### Compile

```bash
cd fashion-ecommerce
javac -d out src/model/*.java src/repository/*.java src/service/*.java src/presentation/*.java Main.java
```

### Run

```bash
java -cp out Main
```

---

## Test Login Credentials

| Role     | Email              | Password  |
|----------|--------------------|-----------|
| Customer | john@email.com     | pass123   |
| Customer | sarah@email.com    | pass123   |
| Seller   | seller@email.com   | pass123   |
| Admin    | admin@email.com    | admin123  |

---

## Architecture: Layered Architecture

```
Presentation Layer  →  MainMenu.java (CLI — all user interaction)
        ↓
Service Layer       →  AuthService, CartService, OrderService, PaymentService
        ↓
Model Layer         →  All domain classes (User, Product, Order, Payment, …)
        ↓
Repository Layer    →  UserRepository, ProductRepository (in-memory stores)
```

Each layer only depends on the layer directly below it.

---

## Project Structure

```
fashion-ecommerce/
├── src/
│   ├── model/
│   │   ├── User.java            Abstract base user
│   │   ├── Customer.java        Extends User — shopping capabilities
│   │   ├── Seller.java          Extends User — product management
│   │   ├── Admin.java           Extends User — platform administration
│   │   ├── Product.java         Product listing
│   │   ├── Category.java        Product category (supports hierarchy)
│   │   ├── Cart.java            Shopping cart with line items
│   │   ├── CartItem.java        Single line in a cart
│   │   ├── Wishlist.java        Saved product list
│   │   ├── Order.java           Placed order with status lifecycle
│   │   ├── OrderItem.java       Single line in an order
│   │   ├── Shipment.java        Delivery tracking record
│   │   ├── Payment.java         Abstract payment base class
│   │   ├── CardPayment.java     Credit/debit card implementation
│   │   ├── WalletPayment.java   Digital wallet implementation
│   │   ├── CashOnDelivery.java  COD implementation
│   │   ├── Inventory.java       Stock tracking per product
│   │   └── Review.java          Customer product review
│   ├── service/
│   │   ├── AuthService.java     Registration, login, logout
│   │   ├── CartService.java     Cart CRUD and checkout
│   │   ├── OrderService.java    Order placement and tracking
│   │   └── PaymentService.java  Payment processing and receipts
│   ├── repository/
│   │   ├── UserRepository.java     In-memory user store with sample data
│   │   └── ProductRepository.java  In-memory product/category/inventory store
│   └── presentation/
│       └── MainMenu.java        Full CLI interface driving all flows
├── Main.java                    Entry point
└── README.md                    This file
```

---

## CLI Flow

### Main Menu (unauthenticated)
```
[1] Login
[2] Register
[3] Exit
```

### Customer Menu
```
[1]  Browse Products      — view all 10 products with price and stock
[2]  Add to Cart          — add a product by ID and quantity
[3]  View Cart            — display items, subtotals, and total
[4]  Checkout             — select payment and place order
[5]  View My Orders       — order history with status
[6]  Track Order          — tracking info by order ID
[7]  Add to Wishlist      — save a product for later
[8]  View Wishlist        — display saved products
[9]  Write Review         — rate and comment on a product
[10] Logout
```

### Payment Flow (within Checkout)
- **Card**: enter 16-digit card number, cardholder name, MM/YY expiry, 3-digit CVV
- **Wallet**: choose provider, enter wallet account ID, balance is checked automatically
- **COD**: confirm order — a $5.00 COD service charge is applied

### Seller Menu
```
[1] Add Product      — add a new product (name, price, stock, category)
[2] View My Products — browse all products
[3] View Orders      — see all platform orders
[4] Manage Inventory — view stock and reserved quantities
[5] Logout
```

### Admin Menu
```
[1] View All Users    — table of all registered users
[2] View All Products — full product catalogue
[3] View All Orders   — all orders with details
[4] View Reports      — counts and revenue summary
[5] Logout
```

---

## Sample Data (pre-loaded)

### Users
| Name          | Email             | Password | Role     |
|---------------|-------------------|----------|----------|
| John Smith    | john@email.com    | pass123  | customer |
| Sarah Jones   | sarah@email.com   | pass123  | customer |
| Mike Brown    | mike@email.com    | pass123  | customer |
| Fashion Store | seller@email.com  | pass123  | seller   |
| Style Hub     | style@email.com   | pass123  | seller   |
| Admin User    | admin@email.com   | admin123 | admin    |

### Categories
| ID | Name        |
|----|-------------|
| 1  | Clothing    |
| 2  | Footwear    |
| 3  | Accessories |

### Products
| ID | Name           | Price    | Stock | Category    |
|----|----------------|----------|-------|-------------|
| 1  | Men's T-Shirt  | $29.99   | 50    | Clothing    |
| 2  | Women's Dress  | $59.99   | 30    | Clothing    |
| 3  | Denim Jeans    | $79.99   | 40    | Clothing    |
| 4  | Running Shoes  | $99.99   | 25    | Footwear    |
| 5  | High Heels     | $89.99   | 20    | Footwear    |
| 6  | Sneakers       | $69.99   | 35    | Footwear    |
| 7  | Leather Belt   | $24.99   | 60    | Accessories |
| 8  | Sunglasses     | $34.99   | 45    | Accessories |
| 9  | Handbag        | $149.99  | 15    | Accessories |
| 10 | Watch          | $199.99  | 10    | Accessories |

---

## SOLID Principles Applied

| Principle              | Implementation                                                                    |
|------------------------|-----------------------------------------------------------------------------------|
| **Single Responsibility** | Each class has one job — MainMenu handles UI, services handle business logic, repositories handle data |
| **Open/Closed**           | `Payment` is abstract and closed for modification; `CardPayment`, `WalletPayment`, `CashOnDelivery` extend it without changing the base |
| **Liskov Substitution**   | `Customer`, `Seller`, `Admin` can replace `User` anywhere the base type is used   |
| **Interface Segregation** | Services are separate — CartService, OrderService, PaymentService, AuthService each serve one domain |
| **Dependency Inversion**  | Services receive repositories via constructors; MainMenu receives services via constructor |

---

## Coding Standards

- Every class, constructor, and method has a Javadoc comment with `@param` and `@return`
- Inline comments explain non-obvious logic steps inside method bodies
- Private fields with public getters and setters throughout
- Named constants replace magic numbers (`STATUS_PENDING`, `VALID_CARD_NUMBER_LENGTH`, etc.)
- All user input is validated with `try-catch`; invalid input shows a friendly message and continues
