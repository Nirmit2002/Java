import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * CLI presentation layer for the Fashion E-Commerce Platform.
 * Handles all user interaction, delegates business logic to the service layer,
 * and drives the end-to-end application flow from login through checkout.
 */
public class MainMenu {

    /** Authentication service for login, logout, and registration */
    private AuthService authService;

    /** Cart service for managing shopping carts */
    private CartService cartService;

    /** Order service for placing and tracking orders */
    private OrderService orderService;

    /** Payment service for processing and recording payments */
    private PaymentService paymentService;

    /** Scanner for reading user input from stdin */
    private Scanner scanner;

    /** The currently logged-in user; null when no session is active */
    private User currentUser;

    /** Per-customer wishlist, keyed by customer ID */
    private Map<Integer, Wishlist> wishlists;

    /** Counter used to assign unique wishlist IDs */
    private int nextWishlistId;

    /** Separator line length used for formatting */
    private static final int SEPARATOR_LENGTH = 60;

    /**
     * Constructs the MainMenu and wires together all service dependencies.
     *
     * @param authService    the authentication service
     * @param cartService    the cart service
     * @param orderService   the order service
     * @param paymentService the payment service
     */
    public MainMenu(AuthService authService, CartService cartService,
                    OrderService orderService, PaymentService paymentService) {
        this.authService = authService;
        this.cartService = cartService;
        this.orderService = orderService;
        this.paymentService = paymentService;
        this.scanner = new Scanner(System.in);
        this.currentUser = null;
        this.wishlists = new HashMap<>();
        this.nextWishlistId = 1;
    }

    /**
     * Starts the main application loop, displaying the main menu
     * until the user chooses to exit.
     */
    public void run() {
        printHeader("FASHION E-COMMERCE PLATFORM");
        System.out.println("Welcome to the Fashion E-Commerce Platform!");

        boolean running = true;
        while (running) {
            // When no user is logged in, show the main menu
            if (currentUser == null) {
                displayMainMenu();
                int choice = readIntInput("Enter choice: ");
                switch (choice) {
                    case 1:
                        handleLogin();
                        break;
                    case 2:
                        handleRegister();
                        break;
                    case 3:
                        System.out.println("Thank you for visiting! Goodbye.");
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid option. Please choose 1, 2, or 3.");
                }
            } else {
                // Delegate to role-specific menu
                handleInput();
            }
        }
    }

    /**
     * Displays the unauthenticated main menu options.
     */
    public void displayMainMenu() {
        printSeparator();
        System.out.println("MAIN MENU");
        printSeparator();
        System.out.println("[1] Login");
        System.out.println("[2] Register");
        System.out.println("[3] Exit");
        printSeparator();
    }

    /**
     * Displays the customer-specific menu options.
     */
    public void displayCustomerMenu() {
        printSeparator();
        System.out.println("CUSTOMER MENU - Welcome, " + currentUser.getName() + "!");
        printSeparator();
        System.out.println("[1]  Browse Products");
        System.out.println("[2]  Add to Cart");
        System.out.println("[3]  View Cart");
        System.out.println("[4]  Checkout");
        System.out.println("[5]  View My Orders");
        System.out.println("[6]  Track Order");
        System.out.println("[7]  Add to Wishlist");
        System.out.println("[8]  View Wishlist");
        System.out.println("[9]  Write Review");
        System.out.println("[10] Logout");
        printSeparator();
    }

    /**
     * Displays the seller-specific menu options.
     */
    public void displaySellerMenu() {
        printSeparator();
        System.out.println("SELLER MENU - Welcome, " + currentUser.getName() + "!");
        printSeparator();
        System.out.println("[1] Add Product");
        System.out.println("[2] View My Products");
        System.out.println("[3] View Orders");
        System.out.println("[4] Manage Inventory");
        System.out.println("[5] Logout");
        printSeparator();
    }

    /**
     * Displays the admin-specific menu options.
     */
    public void displayAdminMenu() {
        printSeparator();
        System.out.println("ADMIN MENU - Welcome, " + currentUser.getName() + "!");
        printSeparator();
        System.out.println("[1] View All Users");
        System.out.println("[2] View All Products");
        System.out.println("[3] View All Orders");
        System.out.println("[4] View Reports");
        System.out.println("[5] Logout");
        printSeparator();
    }

    /**
     * Handles the login flow by collecting credentials and authenticating.
     */
    public void handleLogin() {
        printHeader("LOGIN");
        System.out.print("Email   : ");
        String email = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine().trim();

        // Attempt authentication via the auth service
        User loggedInUser = authService.login(email, password);
        if (loggedInUser != null) {
            currentUser = loggedInUser;
        }
    }

    /**
     * Handles the registration flow by collecting user details and saving the account.
     */
    public void handleRegister() {
        printHeader("REGISTER NEW ACCOUNT");
        System.out.print("Full Name : ");
        String name = scanner.nextLine().trim();
        System.out.print("Email     : ");
        String email = scanner.nextLine().trim();
        System.out.print("Password  : ");
        String password = scanner.nextLine().trim();
        System.out.print("Phone     : ");
        String phone = scanner.nextLine().trim();
        System.out.print("Role (customer/seller): ");
        String role = scanner.nextLine().trim().toLowerCase();

        // Validate role before registering
        if (!role.equals("customer") && !role.equals("seller")) {
            System.out.println("Invalid role. Defaulting to 'customer'.");
            role = "customer";
        }

        // Attempt registration
        authService.register(name, email, password, phone, role);
    }

    /**
     * Displays all available products in a formatted table.
     */
    public void handleBrowseProducts() {
        printHeader("AVAILABLE PRODUCTS");
        // Products are stored in the product repository via the cart service's dependency
        ProductRepository productRepository = ((CartService) cartService).getProductRepository();
        List<Product> allProducts = productRepository.findAll();
        List<Category> allCategories = productRepository.findAllCategories();

        if (allProducts.isEmpty()) {
            System.out.println("No products available.");
            return;
        }

        // Print column header
        System.out.printf("%-4s %-26s %-10s %-6s %-12s%n",
                "ID", "Name", "Price", "Stock", "Category");
        printSeparator();

        // Print each product row
        for (Product product : allProducts) {
            // Look up the category name for display
            String categoryName = "Unknown";
            for (Category category : allCategories) {
                if (category.getId() == product.getCategoryId()) {
                    categoryName = category.getName();
                    break;
                }
            }
            System.out.printf("%-4d %-26s $%-9.2f %-6d %-12s%n",
                    product.getId(), product.getName(),
                    product.getPrice(), product.getStockQuantity(), categoryName);
        }
        printSeparator();
    }

    /**
     * Handles adding a product to the current customer's cart.
     */
    public void handleAddToCart() {
        printHeader("ADD TO CART");
        // Show products so the user can choose
        handleBrowseProducts();

        int productId = readIntInput("Enter Product ID to add: ");
        if (productId <= 0) {
            System.out.println("Invalid product ID.");
            return;
        }

        int quantity = readIntInput("Enter quantity: ");
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than zero.");
            return;
        }

        Customer customer = (Customer) currentUser;
        cartService.addToCart(customer.getCustomerId(), productId, quantity);
    }

    /**
     * Displays the current customer's cart contents and totals.
     */
    public void handleViewCart() {
        printHeader("YOUR CART");
        Customer customer = (Customer) currentUser;
        Cart cart = cartService.getCart(customer.getCustomerId());

        if (cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }

        // Print column header
        System.out.printf("%-4s %-26s %-5s %-10s %-10s%n",
                "ID", "Product", "Qty", "Unit Price", "Subtotal");
        printSeparator();

        // Print each cart item
        for (CartItem item : cart.viewItems()) {
            System.out.printf("%-4d %-26s %-5d $%-9.2f $%-9.2f%n",
                    item.getId(),
                    item.getProduct() != null ? item.getProduct().getName() : "Unknown",
                    item.getQuantity(),
                    item.getUnitPrice(),
                    item.getSubtotal());
        }
        printSeparator();
        System.out.printf("Total: $%.2f%n", cart.getTotal());
        printSeparator();
    }

    /**
     * Handles the checkout flow: confirms cart, selects payment, and places order.
     */
    public void handleCheckout() {
        printHeader("CHECKOUT");
        Customer customer = (Customer) currentUser;
        Cart cart = cartService.getCart(customer.getCustomerId());

        if (cart.isEmpty()) {
            System.out.println("Your cart is empty. Add items before checking out.");
            return;
        }

        // Show the cart contents before confirming
        handleViewCart();

        System.out.print("Confirm checkout? (yes/no): ");
        String confirmation = scanner.nextLine().trim().toLowerCase();
        if (!confirmation.equals("yes") && !confirmation.equals("y")) {
            System.out.println("Checkout cancelled.");
            return;
        }

        // Build an order first so we can pass it to the payment handler
        double orderTotal = cart.getTotal();
        Order pendingOrder = new Order(
                0, customer.getCustomerId(),
                java.time.LocalDateTime.now().toString(),
                orderTotal);

        // Collect cart items into the pending order for display in payment handler
        for (CartItem cartItem : cart.viewItems()) {
            OrderItem orderItem = new OrderItem(
                    0, 0,
                    cartItem.getProductId(),
                    cartItem.getQuantity(),
                    cartItem.getUnitPrice(),
                    cartItem.getProduct());
            pendingOrder.addItem(orderItem);
        }

        handlePayment(pendingOrder);
    }

    /**
     * Prompts the customer to choose a payment method, then dispatches to the correct handler.
     *
     * @param order the Order to pay for
     */
    public void handlePayment(Order order) {
        printHeader("SELECT PAYMENT METHOD");
        System.out.printf("Order Total: $%.2f%n", order.getTotalAmount());
        printSeparator();
        System.out.println("[1] Credit / Debit Card");
        System.out.println("[2] Digital Wallet");
        System.out.println("[3] Cash on Delivery");
        System.out.println("[4] Cancel");
        printSeparator();

        int choice = readIntInput("Choose payment method: ");
        switch (choice) {
            case 1:
                handleCardPayment(order);
                break;
            case 2:
                handleWalletPayment(order);
                break;
            case 3:
                handleCODPayment(order);
                break;
            case 4:
                System.out.println("Payment cancelled. Your cart has been kept.");
                break;
            default:
                System.out.println("Invalid choice. Returning to menu.");
        }
    }

    /**
     * Collects card details from the customer, processes the payment, and places the order.
     *
     * @param order the Order to pay for with a card
     */
    public void handleCardPayment(Order order) {
        printHeader("CARD PAYMENT");
        System.out.print("Card Number (16 digits): ");
        String cardNumber = scanner.nextLine().trim();
        System.out.print("Cardholder Name       : ");
        String holderName = scanner.nextLine().trim();
        System.out.print("Expiry Date (MM/YY)   : ");
        String expiryDate = scanner.nextLine().trim();
        System.out.print("CVV (3 digits)        : ");
        String cvv = scanner.nextLine().trim();

        // Create card payment with a temporary ID; PaymentService assigns the real one
        CardPayment cardPayment = new CardPayment(
                0, order.getId(), order.getTotalAmount(),
                cardNumber, holderName, expiryDate, cvv);

        // Process and finalise the order
        finaliseOrder(order, cardPayment);
    }

    /**
     * Collects wallet details, processes the payment, and places the order.
     *
     * @param order the Order to pay for with a digital wallet
     */
    public void handleWalletPayment(Order order) {
        printHeader("DIGITAL WALLET PAYMENT");
        System.out.println("Supported wallets: PayPal, Google Pay, Apple Pay");
        System.out.print("Wallet Provider  : ");
        String provider = scanner.nextLine().trim();
        System.out.print("Wallet Account ID: ");
        String accountId = scanner.nextLine().trim();

        // Create wallet payment object
        WalletPayment walletPayment = new WalletPayment(
                0, order.getId(), order.getTotalAmount(),
                provider, accountId);

        System.out.printf("Wallet Balance: $%.2f%n", walletPayment.checkBalance());
        finaliseOrder(order, walletPayment);
    }

    /**
     * Confirms COD details and places the order with cash collection at delivery.
     *
     * @param order the Order to pay for with cash on delivery
     */
    public void handleCODPayment(Order order) {
        printHeader("CASH ON DELIVERY");
        CashOnDelivery codPayment = new CashOnDelivery(
                0, order.getId(), order.getTotalAmount());

        System.out.printf("Order Amount : $%.2f%n", order.getTotalAmount());
        System.out.printf("COD Charge   : $%.2f%n", codPayment.getCodCharge());
        System.out.printf("Total Due    : $%.2f%n", order.getTotalAmount() + codPayment.getCodCharge());

        System.out.print("Confirm COD order? (yes/no): ");
        String confirmation = scanner.nextLine().trim().toLowerCase();
        if (!confirmation.equals("yes") && !confirmation.equals("y")) {
            System.out.println("COD order cancelled.");
            return;
        }

        finaliseOrder(order, codPayment);
    }

    /**
     * Finalises an order by processing payment, saving the order, and printing confirmation.
     *
     * @param order   the Order being placed
     * @param payment the Payment method to use
     */
    private void finaliseOrder(Order order, Payment payment) {
        Customer customer = (Customer) currentUser;
        Cart cart = cartService.getCart(customer.getCustomerId());

        // Delegate checkout to CartService which handles stock reduction
        Order completedOrder = cartService.checkout(customer.getCustomerId(), payment);

        if (completedOrder != null) {
            // Persist the order in the order service for future lookups
            orderService.saveOrder(completedOrder);
            paymentService.storePayment(payment);

            // Show the order confirmation
            printHeader("ORDER CONFIRMED");
            System.out.println("Order ID      : " + completedOrder.getId());
            System.out.println("Order Date    : " + completedOrder.getOrderDate());
            System.out.println("Status        : " + completedOrder.getStatus());
            System.out.printf("Order Total   : $%.2f%n", completedOrder.getTotalAmount());
            System.out.println("Payment Status: " + payment.getStatus());
            printSeparator();
            System.out.println("Items:");
            for (OrderItem item : completedOrder.getItems()) {
                System.out.println("  " + item.getSummary());
            }
            printSeparator();
            System.out.println("Thank you for your purchase!");
        }
    }

    /**
     * Displays the current customer's order history.
     */
    public void handleViewOrders() {
        printHeader("MY ORDERS");
        Customer customer = (Customer) currentUser;
        List<Order> customerOrders = orderService.getOrders(customer.getCustomerId());

        if (customerOrders.isEmpty()) {
            System.out.println("You have not placed any orders yet.");
            return;
        }

        // Print each order summary
        for (Order order : customerOrders) {
            System.out.printf("Order #%-6d | Date: %-20s | Status: %-12s | Total: $%.2f%n",
                    order.getId(), order.getOrderDate(), order.getStatus(), order.getTotalAmount());
        }
        printSeparator();
    }

    /**
     * Prompts for an order ID and displays tracking information.
     */
    public void handleTrackOrder() {
        printHeader("TRACK ORDER");
        int orderId = readIntInput("Enter Order ID: ");
        if (orderId <= 0) {
            System.out.println("Invalid order ID.");
            return;
        }

        // Retrieve tracking info from the order service
        String trackingInfo = orderService.trackOrder(orderId);
        System.out.println(trackingInfo);
    }

    /**
     * Prompts for a product ID and adds it to the customer's wishlist.
     */
    public void handleAddToWishlist() {
        printHeader("ADD TO WISHLIST");
        handleBrowseProducts();

        int productId = readIntInput("Enter Product ID to add to wishlist: ");
        if (productId <= 0) {
            System.out.println("Invalid product ID.");
            return;
        }

        // Look up the product
        ProductRepository productRepository = ((CartService) cartService).getProductRepository();
        Product targetProduct = productRepository.findById(productId);
        if (targetProduct == null) {
            System.out.println("Product not found.");
            return;
        }

        // Get or create the customer's wishlist
        Customer customer = (Customer) currentUser;
        Wishlist wishlist = getOrCreateWishlist(customer.getCustomerId());
        wishlist.addItem(targetProduct);
    }

    /**
     * Displays all products saved in the customer's wishlist.
     */
    public void handleViewWishlist() {
        printHeader("MY WISHLIST");
        Customer customer = (Customer) currentUser;
        Wishlist wishlist = getOrCreateWishlist(customer.getCustomerId());

        if (wishlist.size() == 0) {
            System.out.println("Your wishlist is empty.");
            return;
        }

        System.out.printf("%-4s %-26s %-10s %-6s%n", "ID", "Name", "Price", "Stock");
        printSeparator();
        for (Product product : wishlist.getItems()) {
            System.out.printf("%-4d %-26s $%-9.2f %-6d%n",
                    product.getId(), product.getName(),
                    product.getPrice(), product.getStockQuantity());
        }
        printSeparator();
    }

    /**
     * Retrieves the wishlist for the given customer, creating one if needed.
     *
     * @param customerId the customer whose wishlist to retrieve
     * @return the customer's Wishlist
     */
    private Wishlist getOrCreateWishlist(int customerId) {
        if (!wishlists.containsKey(customerId)) {
            Wishlist newWishlist = new Wishlist(
                    nextWishlistId++, customerId,
                    java.time.LocalDate.now().toString());
            wishlists.put(customerId, newWishlist);
        }
        return wishlists.get(customerId);
    }

    /**
     * Collects review details from the customer and submits the review.
     */
    public void handleWriteReview() {
        printHeader("WRITE A REVIEW");
        handleBrowseProducts();

        int productId = readIntInput("Enter Product ID to review: ");
        if (productId <= 0) {
            System.out.println("Invalid product ID.");
            return;
        }

        // Validate that the product exists
        ProductRepository productRepository = ((CartService) cartService).getProductRepository();
        Product targetProduct = productRepository.findById(productId);
        if (targetProduct == null) {
            System.out.println("Product not found.");
            return;
        }

        int rating = readIntInput("Rating (1-5): ");
        if (rating < 1 || rating > 5) {
            System.out.println("Rating must be between 1 and 5.");
            return;
        }

        System.out.print("Your comment: ");
        String comment = scanner.nextLine().trim();
        if (comment.isEmpty()) {
            System.out.println("Comment cannot be empty.");
            return;
        }

        Customer customer = (Customer) currentUser;
        customer.writeReview(targetProduct, rating, comment);
    }

    /**
     * Handles the seller flow for adding a new product.
     */
    public void handleSellerAddProduct() {
        printHeader("ADD NEW PRODUCT");
        System.out.print("Product Name       : ");
        String productName = scanner.nextLine().trim();
        System.out.print("Description        : ");
        String description = scanner.nextLine().trim();

        double price = readDoubleInput("Price ($)          : ");
        int stockQty = readIntInput("Stock Quantity     : ");

        System.out.println("Categories: [1] Clothing  [2] Footwear  [3] Accessories");
        int categoryId = readIntInput("Category ID        : ");
        if (categoryId < 1 || categoryId > 3) {
            System.out.println("Invalid category. Defaulting to Clothing (1).");
            categoryId = 1;
        }

        Seller seller = (Seller) currentUser;
        ProductRepository productRepository = ((CartService) cartService).getProductRepository();

        // Build and save the new product
        Product newProduct = new Product(
                0, productName, description, price, stockQty,
                seller.getSellerId(), categoryId,
                java.time.LocalDate.now().toString());
        productRepository.save(newProduct);
        System.out.println("Product added successfully with ID: " + newProduct.getId());
    }

    /**
     * Displays all orders in the system for the seller to review.
     */
    public void handleSellerViewOrders() {
        printHeader("ALL ORDERS");
        List<Order> allOrders = orderService.getAllOrders();

        if (allOrders.isEmpty()) {
            System.out.println("No orders in the system yet.");
            return;
        }

        for (Order order : allOrders) {
            System.out.printf("Order #%-6d | Customer ID: %-4d | Status: %-12s | Total: $%.2f%n",
                    order.getId(), order.getCustomerId(),
                    order.getStatus(), order.getTotalAmount());
        }
        printSeparator();
    }

    /**
     * Displays all registered users for admin management.
     */
    public void handleAdminManageUsers() {
        printHeader("ALL USERS");
        List<User> allUsers = authService.getUserRepository().findAll();

        System.out.printf("%-4s %-20s %-30s %-10s%n", "ID", "Name", "Email", "Role");
        printSeparator();
        for (User user : allUsers) {
            System.out.printf("%-4d %-20s %-30s %-10s%n",
                    user.getUserId(), user.getName(), user.getEmail(), user.getRole());
        }
        printSeparator();
    }

    /**
     * Displays a summary report of the platform's activity.
     */
    public void handleAdminViewReports() {
        printHeader("PLATFORM REPORTS");
        List<User> allUsers = authService.getUserRepository().findAll();
        List<Order> allOrders = orderService.getAllOrders();
        ProductRepository productRepository = ((CartService) cartService).getProductRepository();
        List<Product> allProducts = productRepository.findAll();

        // Compute summary statistics
        long customerCount = 0;
        long sellerCount = 0;
        for (User user : allUsers) {
            if ("customer".equalsIgnoreCase(user.getRole())) customerCount++;
            else if ("seller".equalsIgnoreCase(user.getRole())) sellerCount++;
        }

        double totalRevenue = 0.0;
        for (Order order : allOrders) {
            if (!Order.STATUS_CANCELLED.equals(order.getStatus())) {
                totalRevenue += order.getTotalAmount();
            }
        }

        System.out.println("Total Users    : " + allUsers.size());
        System.out.println("  - Customers  : " + customerCount);
        System.out.println("  - Sellers    : " + sellerCount);
        System.out.println("Total Products : " + allProducts.size());
        System.out.println("Total Orders   : " + allOrders.size());
        System.out.printf("Total Revenue  : $%.2f%n", totalRevenue);
        printSeparator();
    }

    /**
     * Routes input to the correct role-specific menu and handles the selected option.
     */
    public void handleInput() {
        if (currentUser instanceof Customer) {
            displayCustomerMenu();
            int choice = readIntInput("Enter choice: ");
            handleCustomerChoice(choice);
        } else if (currentUser instanceof Seller) {
            displaySellerMenu();
            int choice = readIntInput("Enter choice: ");
            handleSellerChoice(choice);
        } else if (currentUser instanceof Admin) {
            displayAdminMenu();
            int choice = readIntInput("Enter choice: ");
            handleAdminChoice(choice);
        }
    }

    /**
     * Routes a customer menu selection to the appropriate handler.
     *
     * @param choice the menu option chosen by the customer
     */
    private void handleCustomerChoice(int choice) {
        switch (choice) {
            case 1:
                handleBrowseProducts();
                break;
            case 2:
                handleAddToCart();
                break;
            case 3:
                handleViewCart();
                break;
            case 4:
                handleCheckout();
                break;
            case 5:
                handleViewOrders();
                break;
            case 6:
                handleTrackOrder();
                break;
            case 7:
                handleAddToWishlist();
                break;
            case 8:
                handleViewWishlist();
                break;
            case 9:
                handleWriteReview();
                break;
            case 10:
                authService.logout();
                currentUser = null;
                System.out.println("You have been logged out.");
                break;
            default:
                System.out.println("Invalid option. Please choose 1-10.");
        }
    }

    /**
     * Routes a seller menu selection to the appropriate handler.
     *
     * @param choice the menu option chosen by the seller
     */
    private void handleSellerChoice(int choice) {
        switch (choice) {
            case 1:
                handleSellerAddProduct();
                break;
            case 2:
                handleBrowseProducts();
                break;
            case 3:
                handleSellerViewOrders();
                break;
            case 4:
                printHeader("INVENTORY MANAGEMENT");
                ProductRepository productRepository = ((CartService) cartService).getProductRepository();
                List<Inventory> inventories = productRepository.findAllInventories();
                System.out.printf("%-4s %-26s %-12s %-12s%n",
                        "ID", "Product", "Available", "Reserved");
                printSeparator();
                for (Inventory inv : inventories) {
                    Product product = inv.getTrackedProduct();
                    String productName = product != null ? product.getName() : "Unknown";
                    System.out.printf("%-4d %-26s %-12d %-12d%n",
                            inv.getId(), productName,
                            inv.getAvailableQuantity(), inv.getReservedQuantity());
                }
                printSeparator();
                break;
            case 5:
                currentUser.logout();
                currentUser = null;
                System.out.println("You have been logged out.");
                break;
            default:
                System.out.println("Invalid option. Please choose 1-5.");
        }
    }

    /**
     * Routes an admin menu selection to the appropriate handler.
     *
     * @param choice the menu option chosen by the admin
     */
    private void handleAdminChoice(int choice) {
        switch (choice) {
            case 1:
                handleAdminManageUsers();
                break;
            case 2:
                handleBrowseProducts();
                break;
            case 3:
                printHeader("ALL ORDERS");
                List<Order> allOrders = orderService.getAllOrders();
                if (allOrders.isEmpty()) {
                    System.out.println("No orders in the system.");
                } else {
                    for (Order order : allOrders) {
                        System.out.println(order.getOrderDetails());
                        printSeparator();
                    }
                }
                break;
            case 4:
                handleAdminViewReports();
                break;
            case 5:
                currentUser.logout();
                currentUser = null;
                System.out.println("You have been logged out.");
                break;
            default:
                System.out.println("Invalid option. Please choose 1-5.");
        }
    }

    /**
     * Reads an integer from stdin, returning -1 on invalid input.
     *
     * @param prompt the message to display before reading input
     * @return the integer entered, or -1 on parse failure
     */
    private int readIntInput(String prompt) {
        System.out.print(prompt);
        try {
            String line = scanner.nextLine().trim();
            return Integer.parseInt(line);
        } catch (NumberFormatException formatException) {
            // Inform the user and return a sentinel value
            System.out.println("Please enter a valid number.");
            return -1;
        }
    }

    /**
     * Reads a double from stdin, returning -1.0 on invalid input.
     *
     * @param prompt the message to display before reading input
     * @return the double entered, or -1.0 on parse failure
     */
    private double readDoubleInput(String prompt) {
        System.out.print(prompt);
        try {
            String line = scanner.nextLine().trim();
            return Double.parseDouble(line);
        } catch (NumberFormatException formatException) {
            System.out.println("Please enter a valid number.");
            return -1.0;
        }
    }

    /**
     * Prints a horizontal separator line.
     */
    private void printSeparator() {
        // Repeat dashes to form a visual separator
        for (int index = 0; index < SEPARATOR_LENGTH; index++) {
            System.out.print("-");
        }
        System.out.println();
    }

    /**
     * Prints a centred section header with separators above and below.
     *
     * @param title the header text to display
     */
    private void printHeader(String title) {
        System.out.println();
        printSeparator();
        System.out.println("  " + title);
        printSeparator();
    }
}
