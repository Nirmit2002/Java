import java.util.ArrayList;
import java.util.List;

/**
 * In-memory repository for Product, Category, and Inventory entities.
 * Pre-loads 10 sample fashion products across 3 categories and provides
 * query and update methods used by the service layer.
 */
public class ProductRepository {

    /** In-memory list acting as the product data store */
    private List<Product> products;

    /** In-memory list of all product categories */
    private List<Category> categories;

    /** In-memory list of inventory records, one per product */
    private List<Inventory> inventories;

    /** Counter for generating unique IDs for new products */
    private int nextProductId;

    /**
     * Constructs the ProductRepository and pre-loads all sample data.
     */
    public ProductRepository() {
        this.products = new ArrayList<>();
        this.categories = new ArrayList<>();
        this.inventories = new ArrayList<>();
        this.nextProductId = 20; // Reserve IDs 1-19 for pre-loaded data
        loadSampleData();
    }

    /**
     * Populates the repository with sample categories, products, and inventory records.
     */
    private void loadSampleData() {
        // ---- Categories ----
        Category clothing = new Category(1, "Clothing",
                "Men's and women's clothing items", null);
        Category footwear = new Category(2, "Footwear",
                "Shoes, boots, and sandals", null);
        Category accessories = new Category(3, "Accessories",
                "Bags, belts, jewellery, and watches", null);

        categories.add(clothing);
        categories.add(footwear);
        categories.add(accessories);

        // ---- Products ----
        // Seller ID 1 = TrendyFashion
        String sampleDate = "2024-01-01";

        Product mensTShirt = new Product(1, "Men's T-Shirt",
                "Classic cotton crew-neck T-shirt", 29.99, 50, 1, 1, sampleDate);
        Product womensDress = new Product(2, "Women's Dress",
                "Elegant floral summer dress", 59.99, 30, 1, 1, sampleDate);
        Product denimJeans = new Product(3, "Denim Jeans",
                "Slim-fit blue denim jeans", 79.99, 40, 1, 1, sampleDate);
        Product runningShoes = new Product(4, "Running Shoes",
                "Lightweight performance running shoes", 99.99, 25, 1, 2, sampleDate);
        Product highHeels = new Product(5, "High Heels",
                "Stiletto heels for formal occasions", 89.99, 20, 1, 2, sampleDate);
        Product sneakers = new Product(6, "Sneakers",
                "Casual canvas sneakers", 69.99, 35, 1, 2, sampleDate);
        Product leatherBelt = new Product(7, "Leather Belt",
                "Genuine leather dress belt", 24.99, 60, 1, 3, sampleDate);
        Product sunglasses = new Product(8, "Sunglasses",
                "UV400 polarised sunglasses", 34.99, 45, 1, 3, sampleDate);
        Product handbag = new Product(9, "Handbag",
                "Faux leather tote handbag", 149.99, 15, 1, 3, sampleDate);
        Product watch = new Product(10, "Watch",
                "Stainless steel analogue watch", 199.99, 10, 1, 3, sampleDate);

        // Add all products to the list
        products.add(mensTShirt);
        products.add(womensDress);
        products.add(denimJeans);
        products.add(runningShoes);
        products.add(highHeels);
        products.add(sneakers);
        products.add(leatherBelt);
        products.add(sunglasses);
        products.add(handbag);
        products.add(watch);

        // ---- Inventory records ----
        String inventoryDate = "2024-01-01";
        for (Product product : products) {
            Inventory inventoryRecord = new Inventory(
                    product.getId(),
                    product.getId(),
                    product.getStockQuantity(),
                    0,
                    inventoryDate,
                    product);
            inventories.add(inventoryRecord);
        }
    }

    /**
     * Finds and returns the product with the given ID.
     *
     * @param productId the ID to search for
     * @return matching Product, or null if not found
     */
    public Product findById(int productId) {
        for (Product product : products) {
            if (product.getId() == productId) {
                return product;
            }
        }
        return null;
    }

    /**
     * Returns all products in the repository.
     *
     * @return list of all Product objects
     */
    public List<Product> findAll() {
        return new ArrayList<>(products);
    }

    /**
     * Returns all products belonging to the specified category.
     *
     * @param categoryId the category ID to filter by
     * @return list of Products in that category
     */
    public List<Product> findByCategory(int categoryId) {
        List<Product> result = new ArrayList<>();
        // Collect products whose categoryId matches the requested value
        for (Product product : products) {
            if (product.getCategoryId() == categoryId) {
                result.add(product);
            }
        }
        return result;
    }

    /**
     * Saves a product to the repository, assigning an ID if needed.
     *
     * @param product the Product to save
     */
    public void save(Product product) {
        // Assign a new ID if the product is new
        if (product.getId() == 0) {
            product.setId(nextProductId++);
        }
        // Check if the product already exists and replace it
        for (int index = 0; index < products.size(); index++) {
            if (products.get(index).getId() == product.getId()) {
                products.set(index, product);
                return;
            }
        }
        // New product — add it to the list and create an inventory record
        products.add(product);
        Inventory newInventory = new Inventory(
                product.getId(), product.getId(),
                product.getStockQuantity(), 0,
                java.time.LocalDate.now().toString(), product);
        inventories.add(newInventory);
    }

    /**
     * Updates the stock quantity for the product with the given ID.
     *
     * @param productId ID of the product to update
     * @param quantity  new stock quantity
     */
    public void updateStock(int productId, int quantity) {
        // Update the product's stock field
        Product targetProduct = findById(productId);
        if (targetProduct != null) {
            targetProduct.setStockQuantity(quantity);
        }
        // Also update the corresponding inventory record
        for (Inventory inventoryRecord : inventories) {
            if (inventoryRecord.getProductId() == productId) {
                inventoryRecord.setAvailableQuantity(quantity);
                inventoryRecord.setUpdatedAt(java.time.LocalDateTime.now().toString());
                break;
            }
        }
    }

    /**
     * Returns all categories in the repository.
     *
     * @return list of Category objects
     */
    public List<Category> findAllCategories() {
        return new ArrayList<>(categories);
    }

    /**
     * Returns the category with the given ID.
     *
     * @param categoryId the ID to search for
     * @return matching Category, or null if not found
     */
    public Category findCategoryById(int categoryId) {
        for (Category category : categories) {
            if (category.getId() == categoryId) {
                return category;
            }
        }
        return null;
    }

    /**
     * Returns all inventory records.
     *
     * @return list of Inventory objects
     */
    public List<Inventory> findAllInventories() {
        return new ArrayList<>(inventories);
    }
}
