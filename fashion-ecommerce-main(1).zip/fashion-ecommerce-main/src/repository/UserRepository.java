import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * In-memory repository for User entities in the fashion e-commerce system.
 * Pre-loads sample customers, sellers, and an admin, and provides CRUD-style
 * query methods used by the service layer.
 */
public class UserRepository {

    /** In-memory list acting as the user data store */
    private List<User> users;

    /** Counter for generating unique user IDs for newly registered users */
    private int nextUserId;

    /**
     * Constructs the UserRepository and pre-loads it with sample user data.
     */
    public UserRepository() {
        this.users = new ArrayList<>();
        this.nextUserId = 10; // Reserve IDs 1-9 for pre-loaded data
        loadSampleData();
    }

    /**
     * Populates the repository with a set of realistic sample users for demonstration.
     */
    private void loadSampleData() {
        // Create sample customers
        Customer customerJohn = new Customer(
                1, "John Smith", "john@email.com", "pass123",
                "555-0101", "2024-01-15",
                1, "123 Main St, New York, NY 10001", 150, "2024-01-15");

        Customer customerSarah = new Customer(
                2, "Sarah Jones", "sarah@email.com", "pass123",
                "555-0102", "2024-02-20",
                2, "456 Oak Ave, Los Angeles, CA 90001", 75, "2024-02-20");

        Customer customerMike = new Customer(
                3, "Mike Brown", "mike@email.com", "pass123",
                "555-0103", "2024-03-10",
                3, "789 Pine Rd, Chicago, IL 60601", 0, "2024-03-10");

        // Create sample sellers
        Seller sellerFashion = new Seller(
                4, "Fashion Store", "seller@email.com", "pass123",
                "555-0201", "2023-06-01",
                1, "TrendyFashion", "Premium fashion products for all occasions",
                true, "2023-06-01");

        Seller sellerStyle = new Seller(
                5, "Style Hub", "style@email.com", "pass123",
                "555-0202", "2023-08-15",
                2, "StyleHub", "Affordable everyday fashion",
                false, "2023-08-15");

        // Create admin user
        List<String> adminPermissions = Arrays.asList(
                "MANAGE_USERS", "MANAGE_PRODUCTS", "MANAGE_ORDERS", "VIEW_REPORTS");
        Admin adminUser = new Admin(
                6, "Admin User", "admin@email.com", "admin123",
                "555-0301", "2023-01-01",
                1, "superadmin", adminPermissions, "2024-05-16");

        // Add all users to the repository
        users.add(customerJohn);
        users.add(customerSarah);
        users.add(customerMike);
        users.add(sellerFashion);
        users.add(sellerStyle);
        users.add(adminUser);
    }

    /**
     * Saves a user to the repository. If the user has no ID, one is auto-assigned.
     *
     * @param user the User to save
     */
    public void save(User user) {
        // Check if we need to assign a new ID
        if (user.getUserId() == 0) {
            user.setUserId(nextUserId++);
        }
        // If this is an update, replace the existing entry
        for (int index = 0; index < users.size(); index++) {
            if (users.get(index).getUserId() == user.getUserId()) {
                users.set(index, user);
                return;
            }
        }
        // Not found — this is a new user, so add it
        users.add(user);
    }

    /**
     * Finds and returns the user with the given email address.
     *
     * @param email the email address to search for
     * @return matching User, or null if not found
     */
    public User findByEmail(String email) {
        // Linear scan through all users for a case-insensitive email match
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return user;
            }
        }
        return null;
    }

    /**
     * Finds and returns the user with the given user ID.
     *
     * @param userId the ID to search for
     * @return matching User, or null if not found
     */
    public User findById(int userId) {
        // Linear scan through all users for an ID match
        for (User user : users) {
            if (user.getUserId() == userId) {
                return user;
            }
        }
        return null;
    }

    /**
     * Returns all users in the repository.
     *
     * @return list of all User objects
     */
    public List<User> findAll() {
        // Return a copy to prevent external mutation of the internal list
        return new ArrayList<>(users);
    }

    /**
     * Checks whether a user with the given email already exists.
     *
     * @param email the email address to check
     * @return true if a user with that email is registered
     */
    public boolean existsByEmail(String email) {
        return findByEmail(email) != null;
    }
}
