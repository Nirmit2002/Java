import java.util.HashMap;
import java.util.Map;

/**
 * Service class responsible for payment processing, refunds,
 * and receipt generation in the fashion e-commerce system.
 * Maintains an in-memory map of payment ID to Payment record.
 */
public class PaymentService {

    /** In-memory store of payment records keyed by payment ID */
    private Map<Integer, Payment> payments;

    /** Counter used to generate unique payment IDs */
    private int nextPaymentId;

    /**
     * Constructs a PaymentService with an empty payment store.
     */
    public PaymentService() {
        this.payments = new HashMap<>();
        this.nextPaymentId = 1;
    }

    /**
     * Processes a payment for the given order using the provided Payment object.
     * Persists the payment record regardless of success or failure.
     *
     * @param orderId the ID of the order being paid for
     * @param payment the Payment object containing method-specific details
     * @return true if the payment was processed successfully
     */
    public boolean processPayment(int orderId, Payment payment) {
        // Assign a unique ID if the payment doesn't have one
        if (payment.getId() == 0) {
            payment.setId(nextPaymentId++);
        }

        // Delegate to the payment's own processing logic
        boolean success = payment.processPayment();

        // Store the payment record for future lookup
        payments.put(payment.getId(), payment);

        if (success) {
            System.out.println("Payment recorded with ID: " + payment.getId());
        }
        return success;
    }

    /**
     * Initiates a refund for the payment with the given ID.
     *
     * @param paymentId the ID of the payment to refund
     * @return true if the refund was successfully issued
     */
    public boolean refundPayment(int paymentId) {
        Payment targetPayment = payments.get(paymentId);
        if (targetPayment == null) {
            System.out.println("Payment not found: ID " + paymentId);
            return false;
        }
        // Delegate to the payment's refund logic
        return targetPayment.refund();
    }

    /**
     * Returns the Payment record with the given ID.
     *
     * @param paymentId the ID to look up
     * @return matching Payment, or null if not found
     */
    public Payment getPayment(int paymentId) {
        return payments.get(paymentId);
    }

    /**
     * Returns a formatted receipt for the payment with the given ID.
     *
     * @param paymentId the ID of the payment
     * @return receipt string, or an error message if not found
     */
    public String getReceipt(int paymentId) {
        Payment targetPayment = payments.get(paymentId);
        if (targetPayment == null) {
            return "Receipt not available: payment ID " + paymentId + " not found.";
        }
        // Delegate receipt generation to the Payment model
        return targetPayment.getReceipt();
    }

    /**
     * Stores an already-processed payment object directly.
     * Used when a payment is created and processed outside this service.
     *
     * @param payment the Payment to store
     */
    public void storePayment(Payment payment) {
        if (payment.getId() == 0) {
            payment.setId(nextPaymentId++);
        }
        payments.put(payment.getId(), payment);
    }
}
