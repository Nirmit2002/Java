import java.util.ArrayList;
import java.util.List;

/**
 * Service class responsible for order lifecycle management
 * in the fashion e-commerce system.
 * Stores orders in memory and provides methods to place, query, and track them.
 */
public class OrderService {

    /** In-memory list of all orders in the system */
    private List<Order> orders;

    /** In-memory map of order ID to Shipment for tracking purposes */
    private java.util.Map<Integer, Shipment> shipments;

    /** Counter for generating unique shipment IDs */
    private int nextShipmentId;

    /**
     * Constructs an OrderService with an empty order list.
     */
    public OrderService() {
        this.orders = new ArrayList<>();
        this.shipments = new java.util.HashMap<>();
        this.nextShipmentId = 1;
    }

    /**
     * Creates and persists a new order from the provided cart contents and payment.
     *
     * @param customerId the ID of the placing customer
     * @param cart       the Cart containing ordered items
     * @param payment    the Payment object for this order
     * @return the newly created Order, or null if the cart is empty or payment fails
     */
    public Order placeOrder(int customerId, Cart cart, Payment payment) {
        // Validate that the cart is not empty before creating an order
        if (cart == null || cart.isEmpty()) {
            System.out.println("Cannot place order: cart is empty.");
            return null;
        }

        double orderTotal = cart.getTotal();

        // Build the order object
        Order newOrder = new Order(
                generateOrderId(),
                customerId,
                java.time.LocalDateTime.now().toString(),
                orderTotal);

        // Convert each cart item to an order item
        int orderItemId = 1;
        for (CartItem cartItem : cart.viewItems()) {
            OrderItem orderItem = new OrderItem(
                    orderItemId++,
                    newOrder.getId(),
                    cartItem.getProductId(),
                    cartItem.getQuantity(),
                    cartItem.getUnitPrice(),
                    cartItem.getProduct());
            newOrder.addItem(orderItem);
        }

        // Process payment before confirming the order
        boolean paymentSuccess = payment.processPayment();
        if (!paymentSuccess) {
            System.out.println("Order not placed: payment processing failed.");
            return null;
        }

        // Confirm the order status
        newOrder.placeOrder();

        // Create a shipment record for tracking
        Shipment shipment = new Shipment(
                nextShipmentId++,
                newOrder.getId(),
                "TRK-" + newOrder.getId() + "-" + System.currentTimeMillis() % 10000,
                "FastShip Logistics",
                "PROCESSING",
                null,
                null);
        shipments.put(newOrder.getId(), shipment);

        // Persist the order
        orders.add(newOrder);
        return newOrder;
    }

    /**
     * Generates a unique order ID using a counter offset by timestamp.
     *
     * @return unique order ID
     */
    private int generateOrderId() {
        // Use the list size plus a base to produce a simple unique ID
        return 1000 + orders.size() + 1;
    }

    /**
     * Returns the order with the specified ID.
     *
     * @param orderId the ID to search for
     * @return matching Order, or null if not found
     */
    public Order getOrder(int orderId) {
        for (Order order : orders) {
            if (order.getId() == orderId) {
                return order;
            }
        }
        return null;
    }

    /**
     * Attempts to cancel the order with the given ID.
     *
     * @param orderId the ID of the order to cancel
     * @return true if the order was found and cancelled successfully
     */
    public boolean cancelOrder(int orderId) {
        Order targetOrder = getOrder(orderId);
        if (targetOrder == null) {
            System.out.println("Order not found: #" + orderId);
            return false;
        }
        // Delegate cancellation logic to the Order model
        targetOrder.cancelOrder();
        return Order.STATUS_CANCELLED.equals(targetOrder.getStatus());
    }

    /**
     * Returns all orders placed by the specified customer.
     *
     * @param customerId the customer whose orders to retrieve
     * @return list of the customer's orders
     */
    public List<Order> getOrders(int customerId) {
        List<Order> customerOrders = new ArrayList<>();
        // Filter orders by customer ID
        for (Order order : orders) {
            if (order.getCustomerId() == customerId) {
                customerOrders.add(order);
            }
        }
        return customerOrders;
    }

    /**
     * Updates the status of the specified order.
     *
     * @param orderId   the ID of the order to update
     * @param newStatus the new status string (use Order.STATUS_* constants)
     */
    public void updateStatus(int orderId, String newStatus) {
        Order targetOrder = getOrder(orderId);
        if (targetOrder != null) {
            targetOrder.updateStatus(newStatus);
            System.out.println("Order #" + orderId + " status updated to: " + newStatus);
        } else {
            System.out.println("Order not found: #" + orderId);
        }
    }

    /**
     * Returns tracking information for the specified order.
     *
     * @param orderId the ID of the order to track
     * @return tracking info string, or an error message if not found
     */
    public String trackOrder(int orderId) {
        Order targetOrder = getOrder(orderId);
        if (targetOrder == null) {
            return "Order #" + orderId + " not found.";
        }

        // Build a status summary combining order and shipment info
        StringBuilder trackingInfo = new StringBuilder();
        trackingInfo.append("Order #").append(orderId)
                .append(" | Status: ").append(targetOrder.getStatus())
                .append("\n");

        Shipment shipment = shipments.get(orderId);
        if (shipment != null) {
            trackingInfo.append(shipment.getTrackingInfo());
        } else {
            trackingInfo.append("Shipment not yet created.");
        }
        return trackingInfo.toString();
    }

    /**
     * Saves an externally created order into the service's order list.
     *
     * @param order the Order to save
     */
    public void saveOrder(Order order) {
        // Add the order if it is not already tracked
        for (Order existingOrder : orders) {
            if (existingOrder.getId() == order.getId()) {
                return; // Already saved
            }
        }
        orders.add(order);
    }

    /**
     * Returns all orders in the system.
     *
     * @return list of all Order objects
     */
    public List<Order> getAllOrders() {
        return new ArrayList<>(orders);
    }
}
