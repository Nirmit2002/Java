/**
 * Service class responsible for user authentication and registration
 * in the fashion e-commerce system.
 * Interacts with the UserRepository to look up and persist user records.
 */
public class AuthService {

    /** Repository used to look up and persist user records */
    private UserRepository userRepository;

    /** The currently authenticated customer session; null if no customer is logged in */
    private Customer currentCustomer;

    /**
     * Constructs an AuthService with the provided UserRepository.
     *
     * @param userRepository the repository to use for user lookups
     */
    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.currentCustomer = null;
    }

    /**
     * Registers a new user in the system after validating input and checking for duplicates.
     *
     * @param name     full name of the new user
     * @param email    email address (must be unique)
     * @param password account password
     * @param phone    contact phone number
     * @param role     user role: "customer" or "seller"
     * @return true if registration succeeded, false if email already exists
     */
    public boolean register(String name, String email, String password,
                            String phone, String role) {
        // Reject registration if email is already in use
        if (userRepository.existsByEmail(email)) {
            System.out.println("Registration failed: email already registered.");
            return false;
        }

        String timestamp = java.time.LocalDateTime.now().toString();

        // Create the correct user subtype based on role
        if ("seller".equalsIgnoreCase(role)) {
            Seller newSeller = new Seller(
                    0, name, email, password, phone, timestamp,
                    0, name + "'s Shop", "New seller shop",
                    false, timestamp);
            userRepository.save(newSeller);
        } else {
            // Default to customer role for any unrecognised role value
            Customer newCustomer = new Customer(
                    0, name, email, password, phone, timestamp,
                    0, "Not set", 0, timestamp);
            userRepository.save(newCustomer);
        }

        System.out.println("Registration successful. Welcome, " + name + "!");
        return true;
    }

    /**
     * Authenticates a user with the provided email and password.
     *
     * @param email    the user's email address
     * @param password the user's password
     * @return the authenticated User object, or null if credentials are invalid
     */
    public User login(String email, String password) {
        // Look up user by email first
        User foundUser = userRepository.findByEmail(email);
        if (foundUser == null) {
            System.out.println("Login failed: email not found.");
            return null;
        }

        // Verify the password matches stored credentials
        if (!foundUser.login(email, password)) {
            System.out.println("Login failed: incorrect password.");
            return null;
        }

        // Cache the customer reference if the user is a customer
        if (foundUser instanceof Customer) {
            currentCustomer = (Customer) foundUser;
        }

        System.out.println("Welcome back, " + foundUser.getName() + "!");
        return foundUser;
    }

    /**
     * Logs out the currently authenticated user and clears the session.
     */
    public void logout() {
        if (currentCustomer != null) {
            // Call the inherited logout logic on the user object
            currentCustomer.logout();
            currentCustomer = null;
        } else {
            System.out.println("No user is currently logged in.");
        }
    }

    /**
     * Placeholder for token-based authentication (not implemented).
     *
     * @param token the authentication token to verify
     * @return false as token auth is not implemented in this demo
     */
    public boolean authenticate(String token) {
        // Token-based authentication is outside the scope of this demo
        return false;
    }

    /**
     * Retrieves a user by their email address.
     *
     * @param email the email to search for
     * @return the matching User, or null if not found
     */
    public User getUser(String email) {
        return userRepository.findByEmail(email);
    }

    /**
     * Validates email and password without creating a session.
     *
     * @param email    the email to check
     * @param password the password to verify
     * @return true if credentials are valid
     */
    public boolean validateCredentials(String email, String password) {
        User foundUser = userRepository.findByEmail(email);
        if (foundUser == null) {
            return false;
        }
        // Use the User's own login method for credential comparison
        return foundUser.login(email, password);
    }

    /**
     * Returns the currently logged-in customer, or null if none.
     *
     * @return currentCustomer
     */
    public Customer getCurrentCustomer() {
        return currentCustomer;
    }

    /**
     * Sets the current customer session.
     *
     * @param customer the Customer to set as logged in
     */
    public void setCurrentCustomer(Customer customer) {
        this.currentCustomer = customer;
    }

    /**
     * Returns the UserRepository used by this service.
     *
     * @return userRepository
     */
    public UserRepository getUserRepository() {
        return userRepository;
    }
}
