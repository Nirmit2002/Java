import java.util.HashMap;
import java.util.Map;

/**
 * Service class responsible for shopping cart operations
 * in the fashion e-commerce system.
 * Manages one cart per customer using an in-memory map.
 */
public class CartService {

    /** Repository used to look up product information */
    private ProductRepository productRepository;

    /** Map of customerId to Cart, providing one cart per customer */
    private Map<Integer, Cart> customerCarts;

    /** Counter used to generate unique cart IDs */
    private int nextCartId;

    /**
     * Constructs a CartService with the provided ProductRepository.
     *
     * @param productRepository the repository used to validate product lookups
     */
    public CartService(ProductRepository productRepository) {
        this.productRepository = productRepository;
        this.customerCarts = new HashMap<>();
        this.nextCartId = 1;
    }

    /**
     * Returns the cart for the specified customer, creating one if it does not exist.
     *
     * @param customerId the ID of the customer
     * @return the customer's Cart
     */
    public Cart getCart(int customerId) {
        // Auto-create a cart if the customer does not yet have one
        if (!customerCarts.containsKey(customerId)) {
            Cart newCart = new Cart(nextCartId++, customerId,
                    java.time.LocalDateTime.now().toString());
            customerCarts.put(customerId, newCart);
        }
        return customerCarts.get(customerId);
    }

    /**
     * Adds a product to the customer's cart with the specified quantity.
     *
     * @param customerId the ID of the customer
     * @param productId  the ID of the product to add
     * @param quantity   the number of units to add
     */
    public void addToCart(int customerId, int productId, int quantity) {
        // Validate product exists in the repository
        Product targetProduct = productRepository.findById(productId);
        if (targetProduct == null) {
            System.out.println("Product not found: ID " + productId);
            return;
        }

        // Check sufficient stock is available
        if (targetProduct.getStockQuantity() < quantity) {
            System.out.println("Insufficient stock. Available: " + targetProduct.getStockQuantity());
            return;
        }

        // Retrieve or create the customer's cart and add the item
        Cart cart = getCart(customerId);
        cart.addItem(targetProduct, quantity);
        System.out.println("Added " + quantity + " x " + targetProduct.getName() + " to cart.");
    }

    /**
     * Removes a product from the customer's cart by its cart item ID.
     *
     * @param customerId the ID of the customer
     * @param cartItemId the ID of the cart item to remove
     */
    public void removeFromCart(int customerId, int cartItemId) {
        Cart cart = getCart(customerId);
        if (cart.isEmpty()) {
            System.out.println("Your cart is already empty.");
            return;
        }
        // Remove the specified item from the cart
        cart.removeItem(cartItemId);
        System.out.println("Item removed from cart.");
    }

    /**
     * Clears all items from the customer's cart.
     *
     * @param customerId the ID of the customer
     */
    public void clearCart(int customerId) {
        Cart cart = getCart(customerId);
        cart.clearCart();
        System.out.println("Cart cleared.");
    }

    /**
     * Returns the total monetary value of all items in the customer's cart.
     *
     * @param customerId the ID of the customer
     * @return total cost as a double
     */
    public double getTotal(int customerId) {
        Cart cart = getCart(customerId);
        return cart.getTotal();
    }

    /**
     * Converts the customer's cart into an Order using the provided payment method.
     * Clears the cart after a successful order is created.
     *
     * @param customerId the ID of the customer placing the order
     * @param payment    the Payment object to use for this order
     * @return the created Order, or null if the cart is empty
     */
    public Order checkout(int customerId, Payment payment) {
        Cart cart = getCart(customerId);

        // Cannot checkout with an empty cart
        if (cart.isEmpty()) {
            System.out.println("Cannot checkout: cart is empty.");
            return null;
        }

        // Delegate order creation to the order service indirectly via the cart total
        double orderTotal = cart.getTotal();

        // Create an order from the cart contents
        Order newOrder = new Order(
                (int) (System.currentTimeMillis() % 100000),
                customerId,
                java.time.LocalDateTime.now().toString(),
                orderTotal);

        // Copy each cart item into an order item
        int orderItemId = 1;
        for (CartItem cartItem : cart.viewItems()) {
            OrderItem orderItem = new OrderItem(
                    orderItemId++,
                    newOrder.getId(),
                    cartItem.getProductId(),
                    cartItem.getQuantity(),
                    cartItem.getUnitPrice(),
                    cartItem.getProduct());
            newOrder.addItem(orderItem);

            // Reduce the product's stock to reflect the purchase
            Product purchasedProduct = cartItem.getProduct();
            int newStock = purchasedProduct.getStockQuantity() - cartItem.getQuantity();
            productRepository.updateStock(purchasedProduct.getId(), Math.max(0, newStock));
        }

        // Process the payment
        boolean paymentSuccess = payment.processPayment();
        if (!paymentSuccess) {
            System.out.println("Payment failed. Order not placed.");
            return null;
        }

        // Confirm the order and clear the cart
        newOrder.placeOrder();
        clearCart(customerId);

        return newOrder;
    }

    /**
     * Returns the ProductRepository used by this service.
     * Exposed so the presentation layer can perform direct product lookups.
     *
     * @return productRepository
     */
    public ProductRepository getProductRepository() {
        return productRepository;
    }
}
