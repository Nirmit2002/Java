/**
 * Represents a customer in the fashion e-commerce system.
 * Extends User with shopping-specific capabilities such as cart management,
 * order placement, wishlist handling, and product reviews.
 */
public class Customer extends User {

    /** Unique identifier for the customer record */
    private int customerId;

    /** Default shipping address for orders */
    private String defaultAddress;

    /** Loyalty points accumulated through purchases */
    private int loyaltyPoints;

    /** Timestamp when the customer registered */
    private String registeredAt;

    /**
     * Constructs a Customer with all required fields.
     *
     * @param userId         unique user ID
     * @param name           full name
     * @param email          email address
     * @param password       account password
     * @param phone          contact phone
     * @param createdAt      account creation timestamp
     * @param customerId     unique customer ID
     * @param defaultAddress default shipping address
     * @param loyaltyPoints  initial loyalty points
     * @param registeredAt   registration timestamp
     */
    public Customer(int userId, String name, String email, String password,
                    String phone, String createdAt,
                    int customerId, String defaultAddress,
                    int loyaltyPoints, String registeredAt) {
        super(userId, name, email, password, phone, createdAt, "customer");
        this.customerId = customerId;
        this.defaultAddress = defaultAddress;
        this.loyaltyPoints = loyaltyPoints;
        this.registeredAt = registeredAt;
    }

    /**
     * Updates the customer profile by printing a prompt for profile changes.
     * In a full implementation this would collect input and persist changes.
     */
    @Override
    public void updateProfile() {
        // Display profile update confirmation for the customer
        System.out.println("Customer profile updated for: " + getName());
    }

    /**
     * Simulates browsing the product catalog.
     * Actual product listing is delegated to the presentation layer.
     */
    public void browseProducts() {
        // Signal that the customer initiated a product browse action
        System.out.println("Browsing available products...");
    }

    /**
     * Adds a specified quantity of a product to the customer's cart.
     *
     * @param cart     the Cart object belonging to this customer
     * @param product  the Product to add
     * @param quantity how many units to add
     */
    public void addToCart(Cart cart, Product product, int quantity) {
        // Delegate to the Cart's addItem logic
        cart.addItem(product, quantity);
        System.out.println("Added " + quantity + " x " + product.getName() + " to cart.");
    }

    /**
     * Initiates the order placement process.
     * Full logic is handled by the service and presentation layers.
     */
    public void placeOrder() {
        // Signal that the customer has started checkout
        System.out.println("Placing order for customer: " + getName());
    }

    /**
     * Submits a review for a product.
     *
     * @param product the Product being reviewed
     * @param rating  rating between 1 and 5
     * @param comment written feedback from the customer
     */
    public void writeReview(Product product, int rating, String comment) {
        // Create and validate the review object
        Review review = new Review(0, product.getId(), this.customerId,
                rating, comment, java.time.LocalDate.now().toString());
        if (review.validate()) {
            System.out.println("Review submitted for: " + product.getName());
        } else {
            System.out.println("Invalid review. Rating must be between 1 and 5.");
        }
    }

    /**
     * Returns the customer's unique ID.
     *
     * @return customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * Sets the customer's unique ID.
     *
     * @param customerId new customer ID
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the default shipping address.
     *
     * @return defaultAddress
     */
    public String getDefaultAddress() {
        return defaultAddress;
    }

    /**
     * Sets the default shipping address.
     *
     * @param defaultAddress new address
     */
    public void setDefaultAddress(String defaultAddress) {
        this.defaultAddress = defaultAddress;
    }

    /**
     * Returns the number of loyalty points.
     *
     * @return loyaltyPoints
     */
    public int getLoyaltyPoints() {
        return loyaltyPoints;
    }

    /**
     * Sets the loyalty points balance.
     *
     * @param loyaltyPoints new points balance
     */
    public void setLoyaltyPoints(int loyaltyPoints) {
        this.loyaltyPoints = loyaltyPoints;
    }

    /**
     * Returns the registration timestamp.
     *
     * @return registeredAt
     */
    public String getRegisteredAt() {
        return registeredAt;
    }

    /**
     * Sets the registration timestamp.
     *
     * @param registeredAt new timestamp
     */
    public void setRegisteredAt(String registeredAt) {
        this.registeredAt = registeredAt;
    }
}
