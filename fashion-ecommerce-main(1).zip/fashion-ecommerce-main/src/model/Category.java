import java.util.ArrayList;
import java.util.List;

/**
 * Represents a product category in the fashion e-commerce system.
 * Categories can form a hierarchy through the optional parentId field,
 * allowing sub-categories such as "Men's Shoes" under "Footwear".
 */
public class Category {

    /** Unique identifier for the category */
    private int id;

    /** Display name of the category */
    private String name;

    /** Short description of the category */
    private String description;

    /** ID of the parent category, or null if this is a top-level category */
    private Integer parentId;

    /**
     * Constructs a Category with all fields.
     *
     * @param id          unique category ID
     * @param name        display name
     * @param description short description
     * @param parentId    parent category ID, or null for top-level
     */
    public Category(int id, String name, String description, Integer parentId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.parentId = parentId;
    }

    /**
     * Filters and returns all products belonging to this category.
     *
     * @param allProducts the full list of products to search
     * @return list of products whose categoryId matches this category's id
     */
    public List<Product> getProducts(List<Product> allProducts) {
        List<Product> categoryProducts = new ArrayList<>();
        // Iterate through all products and collect matching ones
        for (Product product : allProducts) {
            if (product.getCategoryId() == this.id) {
                categoryProducts.add(product);
            }
        }
        return categoryProducts;
    }

    /**
     * Simulates adding a sub-category under this category.
     */
    public void addSubCategory() {
        // In a full implementation this would persist a new Category with this id as parentId
        System.out.println("Sub-category added under: " + name);
    }

    /**
     * Simulates updating this category's information.
     */
    public void updateCategory() {
        // Signal that an update operation has been initiated
        System.out.println("Category updated: " + name);
    }

    /**
     * Simulates deleting this category from the system.
     */
    public void deleteCategory() {
        // Signal that a delete operation has been initiated
        System.out.println("Category deleted: " + name);
    }

    /**
     * Returns the category's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the category's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the category name.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the category name.
     *
     * @param name new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the category description.
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the category description.
     *
     * @param description new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the parent category ID, or null if top-level.
     *
     * @return parentId
     */
    public Integer getParentId() {
        return parentId;
    }

    /**
     * Sets the parent category ID.
     *
     * @param parentId new parent ID, or null
     */
    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }
}
