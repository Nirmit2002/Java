import java.util.ArrayList;
import java.util.List;

/**
 * Represents a customer order in the fashion e-commerce system.
 * Tracks the ordered items, the current fulfilment status, and the
 * total monetary value of the order.
 */
public class Order {

    /** Status constant indicating the order has been placed but not yet confirmed */
    public static final String STATUS_PENDING = "PENDING";

    /** Status constant indicating the seller has confirmed the order */
    public static final String STATUS_CONFIRMED = "CONFIRMED";

    /** Status constant indicating the order has been dispatched */
    public static final String STATUS_SHIPPED = "SHIPPED";

    /** Status constant indicating the order has been delivered to the customer */
    public static final String STATUS_DELIVERED = "DELIVERED";

    /** Status constant indicating the order has been cancelled */
    public static final String STATUS_CANCELLED = "CANCELLED";

    /** Unique identifier for this order */
    private int id;

    /** ID of the customer who placed the order */
    private int customerId;

    /** Timestamp when the order was placed */
    private String orderDate;

    /** Current fulfilment status of the order */
    private String status;

    /** Total monetary value of the order */
    private double totalAmount;

    /** List of individual product line items in this order */
    private List<OrderItem> items;

    /**
     * Constructs an Order with all required fields and an empty items list.
     *
     * @param id          unique order ID
     * @param customerId  ID of the placing customer
     * @param orderDate   date and time the order was placed
     * @param totalAmount total cost of the order
     */
    public Order(int id, int customerId, String orderDate, double totalAmount) {
        this.id = id;
        this.customerId = customerId;
        this.orderDate = orderDate;
        // New orders always start in the PENDING state
        this.status = STATUS_PENDING;
        this.totalAmount = totalAmount;
        this.items = new ArrayList<>();
    }

    /**
     * Transitions the order to CONFIRMED status, simulating order placement.
     */
    public void placeOrder() {
        // Move from PENDING to CONFIRMED once the order is accepted
        this.status = STATUS_CONFIRMED;
        System.out.println("Order #" + id + " has been placed and confirmed.");
    }

    /**
     * Attempts to cancel the order if it has not yet been shipped or delivered.
     */
    public void cancelOrder() {
        // Only allow cancellation before the order is shipped
        if (STATUS_PENDING.equals(status) || STATUS_CONFIRMED.equals(status)) {
            this.status = STATUS_CANCELLED;
            System.out.println("Order #" + id + " has been cancelled.");
        } else {
            System.out.println("Order #" + id + " cannot be cancelled (status: " + status + ").");
        }
    }

    /**
     * Returns a formatted multi-line summary of the order.
     *
     * @return formatted order details string
     */
    public String getOrderDetails() {
        StringBuilder builder = new StringBuilder();
        builder.append("Order ID  : ").append(id).append("\n");
        builder.append("Date      : ").append(orderDate).append("\n");
        builder.append("Status    : ").append(status).append("\n");
        builder.append("Total     : $").append(String.format("%.2f", totalAmount)).append("\n");
        builder.append("Items     :\n");
        // List each line item
        for (OrderItem item : items) {
            builder.append("  ").append(item.getSummary()).append("\n");
        }
        return builder.toString();
    }

    /**
     * Updates the order's status to the provided value.
     *
     * @param newStatus the new status string (use Order.STATUS_* constants)
     */
    public void updateStatus(String newStatus) {
        // Assign the new status value
        this.status = newStatus;
    }

    /**
     * Calculates the total from individual order items as a cross-check.
     *
     * @return sum of all order item subtotals
     */
    public double getTotal() {
        double total = 0.0;
        for (OrderItem item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    /**
     * Returns all line items in this order.
     *
     * @return list of OrderItem objects
     */
    public List<OrderItem> getItems() {
        return items;
    }

    /**
     * Adds an order item to this order.
     *
     * @param item the OrderItem to add
     */
    public void addItem(OrderItem item) {
        items.add(item);
    }

    /**
     * Returns the order's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the order's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the customer ID.
     *
     * @return customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * Sets the customer ID.
     *
     * @param customerId new customer ID
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the order date timestamp.
     *
     * @return orderDate
     */
    public String getOrderDate() {
        return orderDate;
    }

    /**
     * Sets the order date timestamp.
     *
     * @param orderDate new order date
     */
    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    /**
     * Returns the current order status.
     *
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the order status.
     *
     * @param status new status value
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Returns the total order amount.
     *
     * @return totalAmount
     */
    public double getTotalAmount() {
        return totalAmount;
    }

    /**
     * Sets the total order amount.
     *
     * @param totalAmount new total
     */
    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
}
