/**
 * Abstract base class representing all users in the fashion e-commerce system.
 * Provides common fields and behaviors shared by Customer, Seller, and Admin.
 */
public abstract class User {

    /** Unique identifier for the user */
    private int userId;

    /** Full name of the user */
    private String name;

    /** Email address used for login */
    private String email;

    /** Hashed or plain password for authentication */
    private String password;

    /** Contact phone number */
    private String phone;

    /** Timestamp when the account was created */
    private String createdAt;

    /** Role of the user: "customer", "seller", or "admin" */
    private String role;

    /**
     * Constructs a User with all required fields.
     *
     * @param userId    unique identifier
     * @param name      full name
     * @param email     email address
     * @param password  account password
     * @param phone     contact phone
     * @param createdAt account creation timestamp
     * @param role      user role
     */
    public User(int userId, String name, String email, String password,
                String phone, String createdAt, String role) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.createdAt = createdAt;
        this.role = role;
    }

    /**
     * Abstract method that subclasses implement to update profile-specific fields.
     */
    public abstract void updateProfile();

    /**
     * Validates the provided credentials against stored values.
     *
     * @param inputEmail    email entered by the user
     * @param inputPassword password entered by the user
     * @return true if both email and password match, false otherwise
     */
    public boolean login(String inputEmail, String inputPassword) {
        // Compare provided credentials with stored credentials
        return this.email.equals(inputEmail) && this.password.equals(inputPassword);
    }

    /**
     * Logs out the current user by printing a confirmation message.
     */
    public void logout() {
        // Inform the user that the session has ended
        System.out.println("User " + name + " has been logged out successfully.");
    }

    /**
     * Returns the unique user ID.
     *
     * @return userId
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Sets the unique user ID.
     *
     * @param userId new user ID
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * Returns the user's full name.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the user's full name.
     *
     * @param name new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the user's email address.
     *
     * @return email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the user's email address.
     *
     * @param email new email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Returns the user's password.
     *
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the user's password.
     *
     * @param password new password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Returns the user's phone number.
     *
     * @return phone
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Sets the user's phone number.
     *
     * @param phone new phone number
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * Returns the account creation timestamp.
     *
     * @return createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the account creation timestamp.
     *
     * @param createdAt new timestamp
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Returns the user's role in the system.
     *
     * @return role
     */
    public String getRole() {
        return role;
    }

    /**
     * Sets the user's role.
     *
     * @param role new role
     */
    public void setRole(String role) {
        this.role = role;
    }
}
