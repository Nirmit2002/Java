import java.util.ArrayList;
import java.util.List;

/**
 * Represents a shopping cart belonging to a specific customer.
 * Provides methods to add, remove, and view items, as well as
 * calculate the total cost of all items in the cart.
 */
public class Cart {

    /** Unique identifier for this cart */
    private int id;

    /** ID of the customer who owns this cart */
    private int customerId;

    /** Timestamp when this cart was created */
    private String createdAt;

    /** List of items currently in this cart */
    private List<CartItem> items;

    /** Counter used to generate unique IDs for new cart items */
    private int nextItemId;

    /**
     * Constructs a Cart with all required fields and an empty item list.
     *
     * @param id         unique cart ID
     * @param customerId owning customer's ID
     * @param createdAt  creation timestamp
     */
    public Cart(int id, int customerId, String createdAt) {
        this.id = id;
        this.customerId = customerId;
        this.createdAt = createdAt;
        this.items = new ArrayList<>();
        this.nextItemId = 1;
    }

    /**
     * Adds a product to the cart with the specified quantity.
     * If the product already exists in the cart, its quantity is increased.
     *
     * @param product  the Product to add
     * @param quantity the number of units to add
     */
    public void addItem(Product product, int quantity) {
        // Check if this product is already in the cart
        for (CartItem existingItem : items) {
            if (existingItem.getProductId() == product.getId()) {
                // Increase existing quantity instead of adding a duplicate line
                existingItem.updateQuantity(existingItem.getQuantity() + quantity);
                return;
            }
        }
        // Product not found — create a new cart item using current product price
        CartItem newItem = new CartItem(nextItemId++, this.id,
                product.getId(), quantity, product.getPrice(), product);
        items.add(newItem);
    }

    /**
     * Removes the cart item with the specified ID from the cart.
     *
     * @param cartItemId ID of the item to remove
     */
    public void removeItem(int cartItemId) {
        // Iterate and remove the matching item
        items.removeIf(item -> item.getId() == cartItemId);
    }

    /**
     * Removes all items from the cart.
     */
    public void clearCart() {
        // Empty the items list completely
        items.clear();
    }

    /**
     * Calculates and returns the total cost of all items in the cart.
     *
     * @return sum of all item subtotals
     */
    public double getTotal() {
        double total = 0.0;
        // Accumulate subtotals from each line item
        for (CartItem item : items) {
            total += item.getSubtotal();
        }
        return total;
    }

    /**
     * Returns all items currently in the cart.
     *
     * @return list of CartItem objects
     */
    public List<CartItem> viewItems() {
        return items;
    }

    /**
     * Checks whether the cart contains no items.
     *
     * @return true if the cart is empty
     */
    public boolean isEmpty() {
        return items.isEmpty();
    }

    /**
     * Returns the total number of line items in the cart.
     *
     * @return number of distinct cart items
     */
    public int itemCount() {
        return items.size();
    }

    /**
     * Returns the cart's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the cart's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the owning customer's ID.
     *
     * @return customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * Sets the owning customer's ID.
     *
     * @param customerId new customer ID
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the cart creation timestamp.
     *
     * @return createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the cart creation timestamp.
     *
     * @param createdAt new timestamp
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Returns the list of items in the cart.
     *
     * @return items list
     */
    public List<CartItem> getItems() {
        return items;
    }

    /**
     * Replaces the items list.
     *
     * @param items new items list
     */
    public void setItems(List<CartItem> items) {
        this.items = items;
    }
}
