/**
 * Represents a single line item within a shopping cart.
 * Holds a reference to the product, the quantity requested, and the
 * unit price at the time the item was added.
 */
public class CartItem {

    /** Unique identifier for this cart item */
    private int id;

    /** ID of the cart this item belongs to */
    private int cartId;

    /** ID of the product referenced by this item */
    private int productId;

    /** Number of units of the product in this line item */
    private int quantity;

    /** Price per unit at the time the item was added to the cart */
    private double unitPrice;

    /** Reference to the full Product object for display purposes */
    private Product product;

    /**
     * Constructs a CartItem with all required fields.
     *
     * @param id        unique cart item ID
     * @param cartId    parent cart ID
     * @param productId ID of the associated product
     * @param quantity  number of units
     * @param unitPrice price per unit at time of addition
     * @param product   full Product reference
     */
    public CartItem(int id, int cartId, int productId, int quantity,
                    double unitPrice, Product product) {
        this.id = id;
        this.cartId = cartId;
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.product = product;
    }

    /**
     * Calculates the total cost for this line item.
     *
     * @return quantity multiplied by unit price
     */
    public double getSubtotal() {
        // Multiply quantity by per-unit price to get line total
        return quantity * unitPrice;
    }

    /**
     * Updates the quantity for this line item.
     *
     * @param newQty the new quantity to set (must be greater than zero)
     */
    public void updateQuantity(int newQty) {
        // Only update if the new quantity is a positive value
        if (newQty > 0) {
            this.quantity = newQty;
        } else {
            System.out.println("Quantity must be greater than zero.");
        }
    }

    /**
     * Returns the Product associated with this cart item.
     *
     * @return product
     */
    public Product getProduct() {
        return product;
    }

    /**
     * Simulates removing this item from the cart (sets quantity to zero).
     */
    public void remove() {
        // Setting quantity to zero effectively marks this item for removal
        this.quantity = 0;
        System.out.println("Cart item removed: " + (product != null ? product.getName() : "Unknown"));
    }

    /**
     * Returns a human-readable summary of this cart item.
     *
     * @return formatted summary string
     */
    public String getSummary() {
        String productName = product != null ? product.getName() : "Unknown Product";
        // Format: "ProductName x Qty @ $Price = $Subtotal"
        return String.format("%-25s x %-3d @ $%-8.2f = $%.2f",
                productName, quantity, unitPrice, getSubtotal());
    }

    /**
     * Returns the unique ID of this cart item.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the unique ID of this cart item.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the parent cart ID.
     *
     * @return cartId
     */
    public int getCartId() {
        return cartId;
    }

    /**
     * Sets the parent cart ID.
     *
     * @param cartId new cart ID
     */
    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    /**
     * Returns the product ID.
     *
     * @return productId
     */
    public int getProductId() {
        return productId;
    }

    /**
     * Sets the product ID.
     *
     * @param productId new product ID
     */
    public void setProductId(int productId) {
        this.productId = productId;
    }

    /**
     * Returns the quantity of this item.
     *
     * @return quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Sets the quantity of this item.
     *
     * @param quantity new quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Returns the unit price for this item.
     *
     * @return unitPrice
     */
    public double getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the unit price for this item.
     *
     * @param unitPrice new unit price
     */
    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }
}
