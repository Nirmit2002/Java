/**
 * Represents a digital wallet payment in the fashion e-commerce system.
 * Extends Payment to provide wallet-specific balance checking and processing.
 */
public class WalletPayment extends Payment {

    /** Name of the wallet provider (e.g., "PayPal", "Google Pay") */
    private String walletProvider;

    /** Unique account identifier within the wallet provider's system */
    private String walletAccountId;

    /** Transaction reference ID returned after a successful payment */
    private String transactionId;

    /** Simulated wallet balance used for demonstration purposes */
    private double simulatedBalance;

    /** Default simulated wallet balance for demo accounts */
    private static final double DEFAULT_WALLET_BALANCE = 500.00;

    /**
     * Constructs a WalletPayment with all required wallet fields.
     * Simulated balance defaults to 500.00 for demo purposes.
     *
     * @param id              unique payment ID
     * @param orderId         associated order ID
     * @param amount          amount to charge
     * @param walletProvider  name of the wallet provider
     * @param walletAccountId account ID in the wallet system
     */
    public WalletPayment(int id, int orderId, double amount,
                         String walletProvider, String walletAccountId) {
        super(id, orderId, amount);
        this.walletProvider = walletProvider;
        this.walletAccountId = walletAccountId;
        // Set a simulated balance for demonstration
        this.simulatedBalance = DEFAULT_WALLET_BALANCE;
    }

    /**
     * Processes the wallet payment by checking the available balance first.
     *
     * @return true if sufficient balance exists and payment succeeds
     */
    @Override
    public boolean processPayment() {
        // Verify the wallet has enough funds before proceeding
        double availableBalance = checkBalance();
        if (availableBalance < getAmount()) {
            setStatus("FAILED");
            System.out.println("Wallet payment failed: insufficient balance ($"
                    + String.format("%.2f", availableBalance) + " available).");
            return false;
        }
        // Deduct the amount from simulated balance
        simulatedBalance -= getAmount();
        // Generate a mock transaction ID
        transactionId = "TXN-" + System.currentTimeMillis();
        setStatus("SUCCESS");
        setPaidAt(java.time.LocalDateTime.now().toString());
        System.out.println("Wallet payment of $" + String.format("%.2f", getAmount())
                + " processed via " + walletProvider + ".");
        System.out.println("Transaction ID: " + transactionId);
        return true;
    }

    /**
     * Returns the current simulated wallet balance.
     *
     * @return available balance amount
     */
    public double checkBalance() {
        // Return the in-memory simulated balance
        return simulatedBalance;
    }

    /**
     * Returns the name of the wallet provider.
     *
     * @return walletProvider
     */
    public String getProvider() {
        return walletProvider;
    }

    /**
     * Returns the wallet provider name.
     *
     * @return walletProvider
     */
    public String getWalletProvider() {
        return walletProvider;
    }

    /**
     * Sets the wallet provider name.
     *
     * @param walletProvider new provider name
     */
    public void setWalletProvider(String walletProvider) {
        this.walletProvider = walletProvider;
    }

    /**
     * Returns the wallet account ID.
     *
     * @return walletAccountId
     */
    public String getWalletAccountId() {
        return walletAccountId;
    }

    /**
     * Sets the wallet account ID.
     *
     * @param walletAccountId new account ID
     */
    public void setWalletAccountId(String walletAccountId) {
        this.walletAccountId = walletAccountId;
    }

    /**
     * Returns the transaction ID assigned after successful payment.
     *
     * @return transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the transaction ID.
     *
     * @param transactionId new transaction ID
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
}
