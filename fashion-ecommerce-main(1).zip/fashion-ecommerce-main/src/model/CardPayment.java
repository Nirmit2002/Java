/**
 * Represents a credit or debit card payment in the fashion e-commerce system.
 * Extends Payment to provide card-specific validation and processing logic.
 */
public class CardPayment extends Payment {

    /** The 16-digit card number (stored as string to preserve leading zeros) */
    private String cardNumber;

    /** Name of the cardholder as it appears on the card */
    private String cardHolderName;

    /** Card expiry date in MM/YY format */
    private String expiryDate;

    /** 3 or 4 digit card verification value */
    private String cvv;

    /** Expected length for a valid card number */
    private static final int VALID_CARD_NUMBER_LENGTH = 16;

    /** Expected length for a valid CVV */
    private static final int VALID_CVV_LENGTH = 3;

    /**
     * Constructs a CardPayment with all required card fields.
     *
     * @param id             unique payment ID
     * @param orderId        associated order ID
     * @param amount         amount to charge
     * @param cardNumber     16-digit card number
     * @param cardHolderName name on the card
     * @param expiryDate     expiry in MM/YY format
     * @param cvv            card verification value
     */
    public CardPayment(int id, int orderId, double amount,
                       String cardNumber, String cardHolderName,
                       String expiryDate, String cvv) {
        super(id, orderId, amount);
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
        this.expiryDate = expiryDate;
        this.cvv = cvv;
    }

    /**
     * Processes the card payment by validating the card details first.
     *
     * @return true if the card is valid and payment succeeds
     */
    @Override
    public boolean processPayment() {
        // Validate card before attempting to charge
        if (!validateCard()) {
            setStatus("FAILED");
            System.out.println("Card payment failed: invalid card details.");
            return false;
        }
        // Simulate a successful charge
        setStatus("SUCCESS");
        setPaidAt(java.time.LocalDateTime.now().toString());
        System.out.println("Card payment of $" + String.format("%.2f", getAmount()) + " processed successfully.");
        System.out.println("Card: " + maskCardNumber());
        return true;
    }

    /**
     * Validates the card number length and CVV length.
     *
     * @return true if both card number and CVV meet length requirements
     */
    public boolean validateCard() {
        // Check that the card number has exactly 16 digits
        if (cardNumber == null || cardNumber.replaceAll("\\s", "").length() != VALID_CARD_NUMBER_LENGTH) {
            return false;
        }
        // Check that the CVV has exactly 3 digits
        if (cvv == null || cvv.length() != VALID_CVV_LENGTH) {
            return false;
        }
        // Check that the card holder name is not blank
        if (cardHolderName == null || cardHolderName.trim().isEmpty()) {
            return false;
        }
        // Check that the expiry date is in the expected format
        if (expiryDate == null || !expiryDate.matches("\\d{2}/\\d{2}")) {
            return false;
        }
        return true;
    }

    /**
     * Returns the card number with all but the last four digits replaced by asterisks.
     *
     * @return masked card number string
     */
    public String maskCardNumber() {
        if (cardNumber == null || cardNumber.length() < VALID_CARD_NUMBER_LENGTH) {
            return "****-****-****-????";
        }
        // Keep only the last 4 digits visible
        String lastFour = cardNumber.substring(cardNumber.length() - 4);
        return "****-****-****-" + lastFour;
    }

    /**
     * Returns the card number.
     *
     * @return cardNumber
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the card number.
     *
     * @param cardNumber new card number
     */
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    /**
     * Returns the cardholder's name.
     *
     * @return cardHolderName
     */
    public String getCardHolderName() {
        return cardHolderName;
    }

    /**
     * Sets the cardholder's name.
     *
     * @param cardHolderName new name
     */
    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    /**
     * Returns the card expiry date.
     *
     * @return expiryDate
     */
    public String getExpiryDate() {
        return expiryDate;
    }

    /**
     * Sets the card expiry date.
     *
     * @param expiryDate new expiry date
     */
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    /**
     * Returns the CVV.
     *
     * @return cvv
     */
    public String getCvv() {
        return cvv;
    }

    /**
     * Sets the CVV.
     *
     * @param cvv new CVV
     */
    public void setCvv(String cvv) {
        this.cvv = cvv;
    }
}
