/**
 * Represents a customer review for a product in the fashion e-commerce system.
 * Stores the rating, written comment, and metadata required to display
 * and moderate product feedback.
 */
public class Review {

    /** Unique identifier for this review */
    private int id;

    /** ID of the product being reviewed */
    private int productId;

    /** ID of the customer who wrote the review */
    private int customerId;

    /** Numerical rating between 1 (lowest) and 5 (highest) */
    private int rating;

    /** Written comment provided by the customer */
    private String comment;

    /** Timestamp when the review was submitted */
    private String createdAt;

    /** Minimum valid rating value */
    private static final int MIN_RATING = 1;

    /** Maximum valid rating value */
    private static final int MAX_RATING = 5;

    /**
     * Constructs a Review with all required fields.
     *
     * @param id         unique review ID
     * @param productId  ID of the reviewed product
     * @param customerId ID of the reviewing customer
     * @param rating     star rating (1-5)
     * @param comment    written feedback
     * @param createdAt  submission timestamp
     */
    public Review(int id, int productId, int customerId,
                  int rating, String comment, String createdAt) {
        this.id = id;
        this.productId = productId;
        this.customerId = customerId;
        this.rating = rating;
        this.comment = comment;
        this.createdAt = createdAt;
    }

    /**
     * Validates that the review contains a valid rating and a non-empty comment.
     *
     * @return true if rating is in range and comment is not blank
     */
    public boolean validate() {
        // Rating must be within the accepted 1-5 range
        if (rating < MIN_RATING || rating > MAX_RATING) {
            return false;
        }
        // Comment must contain at least some content
        if (comment == null || comment.trim().isEmpty()) {
            return false;
        }
        return true;
    }

    /**
     * Updates the review's comment and rating.
     *
     * @param newComment the revised comment text
     * @param newRating  the revised star rating (1-5)
     */
    public void editReview(String newComment, int newRating) {
        // Validate before applying changes
        if (newRating >= MIN_RATING && newRating <= MAX_RATING
                && newComment != null && !newComment.trim().isEmpty()) {
            this.comment = newComment;
            this.rating = newRating;
            System.out.println("Review updated successfully.");
        } else {
            System.out.println("Invalid review content. Changes not saved.");
        }
    }

    /**
     * Marks this review as deleted by clearing its content.
     * In a full implementation this would remove the record from the repository.
     */
    public void deleteReview() {
        // Clear content to indicate logical deletion
        this.comment = "[deleted]";
        this.rating = 0;
        System.out.println("Review #" + id + " has been deleted.");
    }

    /**
     * Returns the review's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the review's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the reviewed product's ID.
     *
     * @return productId
     */
    public int getProductId() {
        return productId;
    }

    /**
     * Sets the reviewed product's ID.
     *
     * @param productId new product ID
     */
    public void setProductId(int productId) {
        this.productId = productId;
    }

    /**
     * Returns the reviewing customer's ID.
     *
     * @return customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * Sets the reviewing customer's ID.
     *
     * @param customerId new customer ID
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the star rating.
     *
     * @return rating
     */
    public int getRating() {
        return rating;
    }

    /**
     * Sets the star rating.
     *
     * @param rating new rating (1-5)
     */
    public void setRating(int rating) {
        this.rating = rating;
    }

    /**
     * Returns the written comment.
     *
     * @return comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * Sets the written comment.
     *
     * @param comment new comment
     */
    public void setComment(String comment) {
        this.comment = comment;
    }

    /**
     * Returns the submission timestamp.
     *
     * @return createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the submission timestamp.
     *
     * @param createdAt new timestamp
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
