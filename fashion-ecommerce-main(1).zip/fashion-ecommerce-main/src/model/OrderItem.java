/**
 * Represents a single product line within a placed order.
 * Records the product, quantity, and price snapshot at the time of purchase.
 */
public class OrderItem {

    /** Unique identifier for this order item */
    private int id;

    /** ID of the order this item belongs to */
    private int orderId;

    /** ID of the product referenced by this item */
    private int productId;

    /** Number of units purchased */
    private int quantity;

    /** Price per unit at the time of purchase */
    private double unitPrice;

    /** Pre-calculated subtotal (quantity * unitPrice) */
    private double subtotal;

    /** Reference to the full Product object for display purposes */
    private Product product;

    /**
     * Constructs an OrderItem with all required fields.
     * The subtotal is automatically calculated from quantity and unitPrice.
     *
     * @param id        unique order item ID
     * @param orderId   parent order ID
     * @param productId ID of the purchased product
     * @param quantity  units purchased
     * @param unitPrice price per unit at time of purchase
     * @param product   full Product reference
     */
    public OrderItem(int id, int orderId, int productId,
                     int quantity, double unitPrice, Product product) {
        this.id = id;
        this.orderId = orderId;
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        // Calculate subtotal once at creation time (price snapshot)
        this.subtotal = quantity * unitPrice;
        this.product = product;
    }

    /**
     * Returns the subtotal for this line item.
     *
     * @return quantity multiplied by unit price
     */
    public double getSubtotal() {
        return subtotal;
    }

    /**
     * Returns a formatted summary of this order item.
     *
     * @return string summary
     */
    public String getSummary() {
        String productName = product != null ? product.getName() : "Unknown Product";
        // Format: "ProductName x Qty @ $Price = $Subtotal"
        return String.format("%-25s x %-3d @ $%-8.2f = $%.2f",
                productName, quantity, unitPrice, subtotal);
    }

    /**
     * Returns the Product associated with this order item.
     *
     * @return product
     */
    public Product getProduct() {
        return product;
    }

    /**
     * Returns the quantity of this order item.
     *
     * @return quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Returns the unit price for this order item.
     *
     * @return unitPrice
     */
    public double getPrice() {
        return unitPrice;
    }

    /**
     * Returns the unique ID of this order item.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the unique ID of this order item.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the parent order ID.
     *
     * @return orderId
     */
    public int getOrderId() {
        return orderId;
    }

    /**
     * Sets the parent order ID.
     *
     * @param orderId new order ID
     */
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    /**
     * Returns the product ID.
     *
     * @return productId
     */
    public int getProductId() {
        return productId;
    }

    /**
     * Sets the product ID.
     *
     * @param productId new product ID
     */
    public void setProductId(int productId) {
        this.productId = productId;
    }

    /**
     * Sets the unit price.
     *
     * @param unitPrice new unit price
     */
    public void setUnitPrice(double unitPrice) {
        this.unitPrice = unitPrice;
    }

    /**
     * Sets the pre-calculated subtotal.
     *
     * @param subtotal new subtotal value
     */
    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }
}
