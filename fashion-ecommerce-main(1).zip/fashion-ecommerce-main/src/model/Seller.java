/**
 * Represents a seller on the fashion e-commerce platform.
 * Extends User with seller-specific capabilities such as product management,
 * inventory control, and order fulfilment.
 */
public class Seller extends User {

    /** Unique identifier for the seller record */
    private int sellerId;

    /** Display name of the seller's shop */
    private String shopName;

    /** Short description of the seller's shop */
    private String shopDescription;

    /** Whether the platform has verified this seller */
    private boolean isVerified;

    /** Timestamp when the seller joined the platform */
    private String joinedAt;

    /**
     * Constructs a Seller with all required fields.
     *
     * @param userId          unique user ID
     * @param name            full name of the seller
     * @param email           email address
     * @param password        account password
     * @param phone           contact phone
     * @param createdAt       account creation timestamp
     * @param sellerId        unique seller ID
     * @param shopName        name of the shop
     * @param shopDescription short description of the shop
     * @param isVerified      verification status
     * @param joinedAt        joining timestamp
     */
    public Seller(int userId, String name, String email, String password,
                  String phone, String createdAt,
                  int sellerId, String shopName, String shopDescription,
                  boolean isVerified, String joinedAt) {
        super(userId, name, email, password, phone, createdAt, "seller");
        this.sellerId = sellerId;
        this.shopName = shopName;
        this.shopDescription = shopDescription;
        this.isVerified = isVerified;
        this.joinedAt = joinedAt;
    }

    /**
     * Updates the seller's profile information.
     */
    @Override
    public void updateProfile() {
        // Confirm profile update action for seller
        System.out.println("Seller profile updated for shop: " + shopName);
    }

    /**
     * Adds a new product to the platform under this seller.
     *
     * @param product the Product to add
     */
    public void addProduct(Product product) {
        // Associate the product with this seller's ID
        product.setSellerId(this.sellerId);
        System.out.println("Product added: " + product.getName());
    }

    /**
     * Updates an existing product's details.
     *
     * @param product the Product with updated information
     */
    public void updateProduct(Product product) {
        // Trigger the product's own update logic
        product.updateProduct();
        System.out.println("Product updated: " + product.getName());
    }

    /**
     * Displays inventory management options for the seller.
     */
    public void manageInventory() {
        // Signal that inventory management has been requested
        System.out.println("Managing inventory for shop: " + shopName);
    }

    /**
     * Displays orders that include products from this seller.
     */
    public void viewOrders() {
        // Signal that order viewing has been requested
        System.out.println("Viewing orders for shop: " + shopName);
    }

    /**
     * Returns the seller's unique ID.
     *
     * @return sellerId
     */
    public int getSellerId() {
        return sellerId;
    }

    /**
     * Sets the seller's unique ID.
     *
     * @param sellerId new seller ID
     */
    public void setSellerId(int sellerId) {
        this.sellerId = sellerId;
    }

    /**
     * Returns the shop name.
     *
     * @return shopName
     */
    public String getShopName() {
        return shopName;
    }

    /**
     * Sets the shop name.
     *
     * @param shopName new shop name
     */
    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    /**
     * Returns the shop description.
     *
     * @return shopDescription
     */
    public String getShopDescription() {
        return shopDescription;
    }

    /**
     * Sets the shop description.
     *
     * @param shopDescription new description
     */
    public void setShopDescription(String shopDescription) {
        this.shopDescription = shopDescription;
    }

    /**
     * Returns whether the seller is verified.
     *
     * @return true if verified
     */
    public boolean isVerified() {
        return isVerified;
    }

    /**
     * Sets the verification status.
     *
     * @param verified new verification status
     */
    public void setVerified(boolean verified) {
        isVerified = verified;
    }

    /**
     * Returns the timestamp when the seller joined.
     *
     * @return joinedAt
     */
    public String getJoinedAt() {
        return joinedAt;
    }

    /**
     * Sets the joining timestamp.
     *
     * @param joinedAt new timestamp
     */
    public void setJoinedAt(String joinedAt) {
        this.joinedAt = joinedAt;
    }
}
