/**
 * Represents the inventory record for a specific product in the system.
 * Tracks available and reserved quantities, and provides stock management
 * operations to ensure accurate availability information.
 */
public class Inventory {

    /** Unique identifier for this inventory record */
    private int id;

    /** ID of the product this inventory record tracks */
    private int productId;

    /** Number of units available for new orders */
    private int availableQuantity;

    /** Number of units reserved for pending orders but not yet dispatched */
    private int reservedQuantity;

    /** Timestamp of the most recent inventory update */
    private String updatedAt;

    /** Reference to the Product this inventory record belongs to */
    private Product trackedProduct;

    /**
     * Constructs an Inventory record with all required fields.
     *
     * @param id                unique inventory ID
     * @param productId         ID of the tracked product
     * @param availableQuantity initial available stock
     * @param reservedQuantity  initial reserved stock
     * @param updatedAt         last update timestamp
     * @param trackedProduct    reference to the Product object
     */
    public Inventory(int id, int productId, int availableQuantity,
                     int reservedQuantity, String updatedAt, Product trackedProduct) {
        this.id = id;
        this.productId = productId;
        this.availableQuantity = availableQuantity;
        this.reservedQuantity = reservedQuantity;
        this.updatedAt = updatedAt;
        this.trackedProduct = trackedProduct;
    }

    /**
     * Adjusts the available quantity by the given delta (positive to add, negative to remove).
     *
     * @param quantity positive value to add stock, negative to reduce
     */
    public void updateStock(int quantity) {
        // Apply the stock adjustment
        this.availableQuantity += quantity;
        // Keep available quantity non-negative
        if (this.availableQuantity < 0) {
            this.availableQuantity = 0;
        }
        this.updatedAt = java.time.LocalDateTime.now().toString();
        // Sync the product's stockQuantity field to match
        if (trackedProduct != null) {
            trackedProduct.setStockQuantity(this.availableQuantity);
        }
    }

    /**
     * Moves the specified quantity from available to reserved stock.
     *
     * @param quantity units to reserve
     * @return true if enough available stock existed and reservation succeeded
     */
    public boolean reserveStock(int quantity) {
        // Cannot reserve more than what is currently available
        if (quantity > availableQuantity) {
            return false;
        }
        // Transfer units from available to reserved
        availableQuantity -= quantity;
        reservedQuantity += quantity;
        this.updatedAt = java.time.LocalDateTime.now().toString();
        return true;
    }

    /**
     * Moves the specified quantity from reserved back to available stock.
     * Called when a pending order is cancelled before dispatch.
     *
     * @param quantity units to release back to available
     */
    public void releaseStock(int quantity) {
        // Determine how many reserved units can actually be released
        int releasable = Math.min(quantity, reservedQuantity);
        reservedQuantity -= releasable;
        availableQuantity += releasable;
        this.updatedAt = java.time.LocalDateTime.now().toString();
    }

    /**
     * Checks whether the required number of units is currently available.
     *
     * @param required number of units needed
     * @return true if availableQuantity is at least required
     */
    public boolean checkAvailability(int required) {
        return availableQuantity >= required;
    }

    /**
     * Returns the inventory record's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the inventory record's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the tracked product's ID.
     *
     * @return productId
     */
    public int getProductId() {
        return productId;
    }

    /**
     * Sets the tracked product's ID.
     *
     * @param productId new product ID
     */
    public void setProductId(int productId) {
        this.productId = productId;
    }

    /**
     * Returns the available quantity.
     *
     * @return availableQuantity
     */
    public int getAvailableQuantity() {
        return availableQuantity;
    }

    /**
     * Sets the available quantity.
     *
     * @param availableQuantity new available quantity
     */
    public void setAvailableQuantity(int availableQuantity) {
        this.availableQuantity = availableQuantity;
    }

    /**
     * Returns the reserved quantity.
     *
     * @return reservedQuantity
     */
    public int getReservedQuantity() {
        return reservedQuantity;
    }

    /**
     * Sets the reserved quantity.
     *
     * @param reservedQuantity new reserved quantity
     */
    public void setReservedQuantity(int reservedQuantity) {
        this.reservedQuantity = reservedQuantity;
    }

    /**
     * Returns the last update timestamp.
     *
     * @return updatedAt
     */
    public String getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets the last update timestamp.
     *
     * @param updatedAt new timestamp
     */
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    /**
     * Returns the tracked Product reference.
     *
     * @return trackedProduct
     */
    public Product getTrackedProduct() {
        return trackedProduct;
    }

    /**
     * Sets the tracked Product reference.
     *
     * @param trackedProduct new product reference
     */
    public void setTrackedProduct(Product trackedProduct) {
        this.trackedProduct = trackedProduct;
    }
}
