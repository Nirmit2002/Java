/**
 * Abstract base class for all payment types - implements Open/Closed Principle.
 * Provides shared payment fields and behaviour while requiring subclasses to
 * implement their own payment-processing logic via processPayment().
 */
public abstract class Payment {

    /** Unique identifier for this payment record */
    private int id;

    /** ID of the order this payment is for */
    private int orderId;

    /** Amount to be charged */
    private double amount;

    /** Current status of the payment (e.g., "PENDING", "SUCCESS", "FAILED") */
    private String status;

    /** Timestamp when the payment was completed; null until processed */
    private String paidAt;

    /**
     * Constructs a Payment with all required fields.
     * Status defaults to "PENDING" until processPayment() succeeds.
     *
     * @param id      unique payment ID
     * @param orderId associated order ID
     * @param amount  monetary amount to charge
     */
    public Payment(int id, int orderId, double amount) {
        this.id = id;
        this.orderId = orderId;
        this.amount = amount;
        // All payments begin in a PENDING state
        this.status = "PENDING";
        this.paidAt = null;
    }

    /**
     * Processes the payment according to the specific payment method.
     * Must be implemented by each concrete subclass.
     *
     * @return true if the payment was processed successfully
     */
    public abstract boolean processPayment();

    /**
     * Attempts to refund this payment by reversing the charge.
     *
     * @return true if the refund was issued successfully
     */
    public boolean refund() {
        // Only refund payments that have already succeeded
        if ("SUCCESS".equals(status)) {
            this.status = "REFUNDED";
            System.out.println("Payment #" + id + " has been refunded.");
            return true;
        }
        System.out.println("Cannot refund payment with status: " + status);
        return false;
    }

    /**
     * Generates and returns a printable receipt for this payment.
     *
     * @return formatted receipt string
     */
    public String getReceipt() {
        // Compose a basic receipt from the stored fields
        return String.format(
                "Receipt%n--------%nPayment ID : %d%nOrder ID   : %d%nAmount     : $%.2f%nStatus     : %s%nPaid At    : %s",
                id, orderId, amount, status, paidAt != null ? paidAt : "N/A");
    }

    /**
     * Returns the current payment status.
     *
     * @return status string
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the payment status.
     *
     * @param status new status value
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Returns the payment's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the payment's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the associated order ID.
     *
     * @return orderId
     */
    public int getOrderId() {
        return orderId;
    }

    /**
     * Sets the associated order ID.
     *
     * @param orderId new order ID
     */
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    /**
     * Returns the payment amount.
     *
     * @return amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Sets the payment amount.
     *
     * @param amount new amount
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * Returns the payment completion timestamp.
     *
     * @return paidAt, or null if not yet processed
     */
    public String getPaidAt() {
        return paidAt;
    }

    /**
     * Sets the payment completion timestamp.
     *
     * @param paidAt new timestamp
     */
    public void setPaidAt(String paidAt) {
        this.paidAt = paidAt;
    }
}
