/**
 * Represents the shipping record associated with a customer order.
 * Tracks the carrier, tracking number, and current delivery status
 * of the physical goods dispatched for an order.
 */
public class Shipment {

    /** Unique identifier for this shipment */
    private int id;

    /** ID of the order this shipment fulfils */
    private int orderId;

    /** Carrier-issued tracking number */
    private String trackingNumber;

    /** Name of the logistics carrier (e.g., "FedEx", "UPS") */
    private String carrier;

    /** Current delivery status (e.g., "IN_TRANSIT", "DELIVERED") */
    private String status;

    /** Timestamp when the shipment was dispatched */
    private String shippedAt;

    /** Timestamp when the shipment was delivered; null until delivered */
    private String deliveredAt;

    /**
     * Constructs a Shipment with all required fields.
     *
     * @param id             unique shipment ID
     * @param orderId        associated order ID
     * @param trackingNumber carrier tracking number
     * @param carrier        name of the logistics carrier
     * @param status         initial shipment status
     * @param shippedAt      dispatch timestamp
     * @param deliveredAt    delivery timestamp (null if not yet delivered)
     */
    public Shipment(int id, int orderId, String trackingNumber, String carrier,
                    String status, String shippedAt, String deliveredAt) {
        this.id = id;
        this.orderId = orderId;
        this.trackingNumber = trackingNumber;
        this.carrier = carrier;
        this.status = status;
        this.shippedAt = shippedAt;
        this.deliveredAt = deliveredAt;
    }

    /**
     * Updates the delivery status of this shipment.
     *
     * @param newStatus the new status string to apply
     */
    public void updateStatus(String newStatus) {
        // Store the updated status
        this.status = newStatus;
        System.out.println("Shipment status updated to: " + newStatus);
    }

    /**
     * Returns a formatted string with tracking information for this shipment.
     *
     * @return formatted tracking info
     */
    public String getTrackingInfo() {
        // Build a multi-line tracking summary
        return String.format(
                "Tracking #  : %s%nCarrier     : %s%nStatus      : %s%nShipped At  : %s%nDelivered At: %s",
                trackingNumber,
                carrier,
                status,
                shippedAt != null ? shippedAt : "N/A",
                deliveredAt != null ? deliveredAt : "Pending");
    }

    /**
     * Returns the name of the logistics carrier.
     *
     * @return carrier
     */
    public String getCarrier() {
        return carrier;
    }

    /**
     * Returns whether the shipment has been delivered.
     *
     * @return true if status is "DELIVERED"
     */
    public boolean isDelivered() {
        // Compare status string to the delivered sentinel value
        return "DELIVERED".equalsIgnoreCase(status);
    }

    /**
     * Returns the shipment's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the shipment's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the associated order ID.
     *
     * @return orderId
     */
    public int getOrderId() {
        return orderId;
    }

    /**
     * Sets the associated order ID.
     *
     * @param orderId new order ID
     */
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    /**
     * Returns the carrier tracking number.
     *
     * @return trackingNumber
     */
    public String getTrackingNumber() {
        return trackingNumber;
    }

    /**
     * Sets the carrier tracking number.
     *
     * @param trackingNumber new tracking number
     */
    public void setTrackingNumber(String trackingNumber) {
        this.trackingNumber = trackingNumber;
    }

    /**
     * Sets the carrier name.
     *
     * @param carrier new carrier name
     */
    public void setCarrier(String carrier) {
        this.carrier = carrier;
    }

    /**
     * Returns the current delivery status.
     *
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the delivery status.
     *
     * @param status new status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Returns the dispatch timestamp.
     *
     * @return shippedAt
     */
    public String getShippedAt() {
        return shippedAt;
    }

    /**
     * Sets the dispatch timestamp.
     *
     * @param shippedAt new timestamp
     */
    public void setShippedAt(String shippedAt) {
        this.shippedAt = shippedAt;
    }

    /**
     * Returns the delivery timestamp.
     *
     * @return deliveredAt, or null if not yet delivered
     */
    public String getDeliveredAt() {
        return deliveredAt;
    }

    /**
     * Sets the delivery timestamp.
     *
     * @param deliveredAt new delivery timestamp
     */
    public void setDeliveredAt(String deliveredAt) {
        this.deliveredAt = deliveredAt;
    }
}
