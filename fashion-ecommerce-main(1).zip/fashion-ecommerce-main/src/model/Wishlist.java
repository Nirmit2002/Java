import java.util.ArrayList;
import java.util.List;

/**
 * Represents a customer's wishlist on the fashion e-commerce platform.
 * Allows customers to save products they are interested in for later purchase.
 */
public class Wishlist {

    /** Unique identifier for this wishlist */
    private int id;

    /** ID of the customer who owns this wishlist */
    private int customerId;

    /** Timestamp when this wishlist was created */
    private String createdAt;

    /** List of products saved in this wishlist */
    private List<Product> items;

    /**
     * Constructs a Wishlist with all required fields and an empty item list.
     *
     * @param id         unique wishlist ID
     * @param customerId owning customer's ID
     * @param createdAt  creation timestamp
     */
    public Wishlist(int id, int customerId, String createdAt) {
        this.id = id;
        this.customerId = customerId;
        this.createdAt = createdAt;
        this.items = new ArrayList<>();
    }

    /**
     * Adds a product to the wishlist if it is not already present.
     *
     * @param product the Product to add
     */
    public void addItem(Product product) {
        // Prevent duplicate entries by checking before adding
        if (!contains(product.getId())) {
            items.add(product);
            System.out.println("Added to wishlist: " + product.getName());
        } else {
            System.out.println(product.getName() + " is already in your wishlist.");
        }
    }

    /**
     * Removes the product with the specified ID from the wishlist.
     *
     * @param productId ID of the product to remove
     */
    public void removeItem(int productId) {
        // Use removeIf for concise in-place removal
        items.removeIf(product -> product.getId() == productId);
    }

    /**
     * Returns all products currently saved in the wishlist.
     *
     * @return list of Product objects
     */
    public List<Product> getItems() {
        return items;
    }

    /**
     * Removes all products from the wishlist.
     */
    public void clearWishlist() {
        items.clear();
        System.out.println("Wishlist cleared.");
    }

    /**
     * Checks whether a product with the given ID is in the wishlist.
     *
     * @param productId ID to search for
     * @return true if the product is already in the wishlist
     */
    public boolean contains(int productId) {
        // Linear scan to find a matching product ID
        for (Product product : items) {
            if (product.getId() == productId) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the number of products in the wishlist.
     *
     * @return item count
     */
    public int size() {
        return items.size();
    }

    /**
     * Returns the wishlist's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the wishlist's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the owning customer's ID.
     *
     * @return customerId
     */
    public int getCustomerId() {
        return customerId;
    }

    /**
     * Sets the owning customer's ID.
     *
     * @param customerId new customer ID
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the wishlist creation timestamp.
     *
     * @return createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the wishlist creation timestamp.
     *
     * @param createdAt new timestamp
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
