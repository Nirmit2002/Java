/**
 * Represents a product listed on the fashion e-commerce platform.
 * Holds pricing, inventory, and categorisation information, and provides
 * methods to inspect and modify the product's state.
 */
public class Product {

    /** Unique identifier for the product */
    private int id;

    /** Display name of the product */
    private String name;

    /** Detailed description of the product */
    private String description;

    /** Selling price of the product */
    private double price;

    /** Number of units currently in stock */
    private int stockQuantity;

    /** ID of the seller who listed this product */
    private int sellerId;

    /** ID of the category this product belongs to */
    private int categoryId;

    /** Timestamp when the product was added to the platform */
    private String createdAt;

    /**
     * Constructs a Product with all required fields.
     *
     * @param id            unique product ID
     * @param name          display name
     * @param description   product description
     * @param price         selling price
     * @param stockQuantity available stock
     * @param sellerId      owning seller's ID
     * @param categoryId    associated category ID
     * @param createdAt     creation timestamp
     */
    public Product(int id, String name, String description, double price,
                   int stockQuantity, int sellerId, int categoryId, String createdAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.sellerId = sellerId;
        this.categoryId = categoryId;
        this.createdAt = createdAt;
    }

    /**
     * Simulates updating this product's details on the platform.
     */
    public void updateProduct() {
        // In a full implementation this would persist changes to the repository
        System.out.println("Product updated: " + name);
    }

    /**
     * Simulates removing this product from the platform.
     */
    public void deleteProduct() {
        // Signal that the product has been marked for deletion
        System.out.println("Product deleted: " + name);
    }

    /**
     * Builds and returns a formatted string with the product's key details.
     *
     * @return formatted product details string
     */
    public String getProductDetails() {
        // Format all relevant fields into a readable summary
        return String.format("ID: %d | Name: %-25s | Price: $%-8.2f | Stock: %-4d | Category ID: %d",
                id, name, price, stockQuantity, categoryId);
    }

    /**
     * Checks whether the product has at least one unit in stock.
     *
     * @return true if stockQuantity is greater than zero
     */
    public boolean isInStock() {
        // Any positive stock count means the product is available
        return stockQuantity > 0;
    }

    /**
     * Returns the product's unique ID.
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the product's unique ID.
     *
     * @param id new ID
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Returns the product name.
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the product name.
     *
     * @param name new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the product description.
     *
     * @return description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the product description.
     *
     * @param description new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the product price.
     *
     * @return price
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the product price.
     *
     * @param price new price
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Returns the current stock quantity.
     *
     * @return stockQuantity
     */
    public int getStockQuantity() {
        return stockQuantity;
    }

    /**
     * Sets the stock quantity.
     *
     * @param stockQuantity new quantity
     */
    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    /**
     * Returns the seller's ID.
     *
     * @return sellerId
     */
    public int getSellerId() {
        return sellerId;
    }

    /**
     * Sets the seller's ID.
     *
     * @param sellerId new seller ID
     */
    public void setSellerId(int sellerId) {
        this.sellerId = sellerId;
    }

    /**
     * Returns the category ID.
     *
     * @return categoryId
     */
    public int getCategoryId() {
        return categoryId;
    }

    /**
     * Sets the category ID.
     *
     * @param categoryId new category ID
     */
    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    /**
     * Returns the creation timestamp.
     *
     * @return createdAt
     */
    public String getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the creation timestamp.
     *
     * @param createdAt new timestamp
     */
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
}
