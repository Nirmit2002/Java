import java.util.ArrayList;
import java.util.List;

/**
 * Represents a platform administrator in the fashion e-commerce system.
 * Extends User with administrative capabilities such as user management,
 * product oversight, order administration, and reporting.
 */
public class Admin extends User {

    /** Unique identifier for the admin record */
    private int adminId;

    /** Specific administrative role (e.g., "superadmin", "support") */
    private String adminRole;

    /** List of permission strings granted to this admin */
    private List<String> permissions;

    /** Timestamp of the most recent login */
    private String lastLogin;

    /**
     * Constructs an Admin with all required fields.
     *
     * @param userId      unique user ID
     * @param name        full name
     * @param email       email address
     * @param password    account password
     * @param phone       contact phone
     * @param createdAt   account creation timestamp
     * @param adminId     unique admin ID
     * @param adminRole   specific administrative role
     * @param permissions list of granted permissions
     * @param lastLogin   last login timestamp
     */
    public Admin(int userId, String name, String email, String password,
                 String phone, String createdAt,
                 int adminId, String adminRole,
                 List<String> permissions, String lastLogin) {
        super(userId, name, email, password, phone, createdAt, "admin");
        this.adminId = adminId;
        this.adminRole = adminRole;
        // Defensive copy to avoid external mutation
        this.permissions = permissions != null ? new ArrayList<>(permissions) : new ArrayList<>();
        this.lastLogin = lastLogin;
    }

    /**
     * Updates the admin's profile information.
     */
    @Override
    public void updateProfile() {
        // Confirm profile update action for admin
        System.out.println("Admin profile updated for: " + getName());
    }

    /**
     * Provides access to user management functionality.
     */
    public void manageUsers() {
        // Signal that user management has been requested
        System.out.println("Managing users... (admin: " + getName() + ")");
    }

    /**
     * Provides access to product management functionality.
     */
    public void manageProducts() {
        // Signal that product management has been requested
        System.out.println("Managing products... (admin: " + getName() + ")");
    }

    /**
     * Provides access to order management functionality.
     */
    public void manageOrders() {
        // Signal that order management has been requested
        System.out.println("Managing orders... (admin: " + getName() + ")");
    }

    /**
     * Displays platform-wide reports such as sales and user statistics.
     */
    public void viewReports() {
        // Signal that the reports view has been requested
        System.out.println("Viewing system reports... (admin: " + getName() + ")");
    }

    /**
     * Returns the admin's unique ID.
     *
     * @return adminId
     */
    public int getAdminId() {
        return adminId;
    }

    /**
     * Sets the admin's unique ID.
     *
     * @param adminId new admin ID
     */
    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }

    /**
     * Returns the admin's specific role.
     *
     * @return adminRole
     */
    public String getAdminRole() {
        return adminRole;
    }

    /**
     * Sets the admin's specific role.
     *
     * @param adminRole new role
     */
    public void setAdminRole(String adminRole) {
        this.adminRole = adminRole;
    }

    /**
     * Returns the list of permissions granted to this admin.
     *
     * @return permissions list
     */
    public List<String> getPermissions() {
        return permissions;
    }

    /**
     * Sets the permissions list.
     *
     * @param permissions new list of permissions
     */
    public void setPermissions(List<String> permissions) {
        this.permissions = permissions != null ? new ArrayList<>(permissions) : new ArrayList<>();
    }

    /**
     * Returns the last login timestamp.
     *
     * @return lastLogin
     */
    public String getLastLogin() {
        return lastLogin;
    }

    /**
     * Sets the last login timestamp.
     *
     * @param lastLogin new timestamp
     */
    public void setLastLogin(String lastLogin) {
        this.lastLogin = lastLogin;
    }
}
