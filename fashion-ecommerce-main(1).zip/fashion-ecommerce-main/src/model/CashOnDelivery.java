/**
 * Represents a Cash on Delivery payment in the fashion e-commerce system.
 * Extends Payment to support COD-specific charges and delivery confirmation.
 */
public class CashOnDelivery extends Payment {

    /** Additional charge levied for cash on delivery service */
    private double codCharge;

    /** Whether the delivery agent has confirmed cash collection */
    private boolean deliveryConfirmed;

    /** Standard COD service charge applied to all COD orders */
    private static final double STANDARD_COD_CHARGE = 5.00;

    /**
     * Constructs a CashOnDelivery payment with the standard COD charge.
     *
     * @param id      unique payment ID
     * @param orderId associated order ID
     * @param amount  base order amount (COD charge added on top)
     */
    public CashOnDelivery(int id, int orderId, double amount) {
        super(id, orderId, amount);
        // Apply the fixed COD service charge
        this.codCharge = STANDARD_COD_CHARGE;
        this.deliveryConfirmed = false;
    }

    /**
     * Processes the COD payment by confirming the order for cash collection.
     * For COD the payment is not captured now — it is confirmed at delivery.
     *
     * @return true as COD orders are always accepted
     */
    @Override
    public boolean processPayment() {
        // COD orders are automatically confirmed without upfront charge
        setStatus("CONFIRMED_COD");
        System.out.println("Cash on Delivery order confirmed.");
        System.out.println("Amount to collect at door: $"
                + String.format("%.2f", getAmount() + codCharge));
        System.out.println("COD Charge: $" + String.format("%.2f", codCharge));
        return true;
    }

    /**
     * Returns the COD service charge.
     *
     * @return codCharge
     */
    public double getCodCharge() {
        return codCharge;
    }

    /**
     * Confirms that the delivery agent has collected the cash from the customer.
     *
     * @return true if delivery has been confirmed, false if already confirmed
     */
    public boolean confirmDelivery() {
        if (!deliveryConfirmed) {
            // Mark the payment as fully collected
            deliveryConfirmed = true;
            setStatus("SUCCESS");
            setPaidAt(java.time.LocalDateTime.now().toString());
            System.out.println("COD payment confirmed. Cash collected successfully.");
            return true;
        }
        // Delivery was already confirmed previously
        System.out.println("Delivery already confirmed for this order.");
        return false;
    }

    /**
     * Returns whether the delivery has been confirmed.
     *
     * @return true if cash has been collected
     */
    public boolean isDeliveryConfirmed() {
        return deliveryConfirmed;
    }

    /**
     * Sets the COD charge.
     *
     * @param codCharge new COD charge amount
     */
    public void setCodCharge(double codCharge) {
        this.codCharge = codCharge;
    }
}
