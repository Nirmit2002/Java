package voguecart;

import voguecart.controller.CartController;
import voguecart.controller.OrderController;
import voguecart.controller.PaymentController;
import voguecart.controller.ProductController;
import voguecart.controller.UserController;
import voguecart.model.Admin;
import voguecart.model.Customer;
import voguecart.model.Inventory;
import voguecart.model.Product;
import voguecart.model.Seller;
import voguecart.model.User;
import voguecart.view.AdminView;
import voguecart.view.CustomerView;
import voguecart.view.MainMenu;
import voguecart.view.SellerView;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        UserController userController = new UserController();
        ProductController productController = new ProductController();
        CartController cartController = new CartController();
        OrderController orderController = new OrderController();
        PaymentController paymentController = new PaymentController();

        seedData(userController, productController);

        MainMenu mainMenu = new MainMenu(scanner);
        CustomerView customerView = new CustomerView(scanner, productController,
                cartController, orderController, paymentController, userController);
        SellerView sellerView = new SellerView(scanner, productController, orderController);
        AdminView adminView = new AdminView(scanner, userController, productController,
                orderController, paymentController);

        boolean running = true;
        while (running) {
            mainMenu.displayMenu();
            int choice = mainMenu.getUserChoice();

            switch (choice) {
                case 1:
                    User loggedInUser = handleLogin(scanner, userController);
                    if (loggedInUser != null) {
                        routeToView(loggedInUser, customerView, sellerView, adminView);
                    }
                    break;
                case 2:
                    handleRegister(scanner, userController);
                    break;
                case 3:
                    System.out.println("=========================");
                    System.out.println(" Thank you for visiting  ");
                    System.out.println("     VogueCart!          ");
                    System.out.println("=========================");
                    running = false;
                    break;
                default:
                    System.out.println("✗ Invalid choice. Please enter 1, 2, or 3.");
            }
        }

        scanner.close();
    }

    private static User handleLogin(Scanner scanner, UserController userController) {
        System.out.println("=========================");
        System.out.println("         Login           ");
        System.out.println("=========================");
        System.out.print("Email   : ");
        String email;
        String password;
        try {
            email = scanner.nextLine().trim();
            System.out.print("Password: ");
            password = scanner.nextLine().trim();
        } catch (NoSuchElementException exception) {
            return null;
        }

        User user = userController.login(email, password);
        if (user == null) {
            System.out.println("✗ Invalid credentials! Please check your email and password.");
        }
        return user;
    }

    private static void handleRegister(Scanner scanner, UserController userController) {
        System.out.println("=========================");
        System.out.println("        Register         ");
        System.out.println("=========================");
        System.out.println("Register as:");
        System.out.println("1) Customer");
        System.out.println("2) Seller");
        System.out.print("Choice: ");
        int roleChoice;
        try {
            roleChoice = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException exception) {
            roleChoice = -1;
        }

        System.out.print("Full Name : ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            System.out.println("✗ Name cannot be empty.");
            return;
        }

        System.out.print("Email     : ");
        String email = scanner.nextLine().trim();
        if (email.isEmpty()) {
            System.out.println("✗ Email cannot be empty.");
            return;
        }

        System.out.print("Password  : ");
        String password = scanner.nextLine().trim();
        if (password.isEmpty()) {
            System.out.println("✗ Password cannot be empty.");
            return;
        }

        System.out.print("Phone     : ");
        String phone = scanner.nextLine().trim();

        if (roleChoice == 2) {
            System.out.print("Store Name: ");
            String storeName = scanner.nextLine().trim();
            if (storeName.isEmpty()) {
                System.out.println("✗ Store name cannot be empty.");
                return;
            }
            userController.registerSeller(name, email, password, phone, storeName);
        } else {
            userController.register(name, email, password, phone);
        }
    }

    private static void routeToView(User user, CustomerView customerView,
                                     SellerView sellerView, AdminView adminView) {
        switch (user.getRole()) {
            case "CUSTOMER":
                customerView.showMenu((Customer) user);
                break;
            case "SELLER":
                sellerView.showMenu((Seller) user);
                break;
            case "ADMIN":
                adminView.showMenu((Admin) user);
                break;
            default:
                System.out.println("✗ Unknown role: " + user.getRole());
        }
    }

    private static void seedData(UserController userController,
                                  ProductController productController) {

        Customer customer1 = new Customer("U1", "C1", "Arjun Sharma",
                "arjun@email.com", "arjun123", "9876501001");
        Customer customer2 = new Customer("U2", "C2", "Priya Patel",
                "priya@email.com", "priya123", "9876501002");
        userController.addUser(customer1);
        userController.addUser(customer2);

        Seller seller1 = new Seller("U3", "S1", "Rahul Mehta",
                "rahul@email.com", "rahul123", "9876501003", "RahulFashion Store");
        Seller seller2 = new Seller("U4", "S2", "Ananya Singh",
                "ananya@email.com", "ananya123", "9876501004", "Ananya Style Boutique");
        userController.addUser(seller1);
        userController.addUser(seller2);

        Admin admin = new Admin("U5", "A1", "Vikram Nair",
                "vikram@voguecart.com", "vikram123", "9876501000", 10);
        userController.addUser(admin);

        // Nike Air Shoes
        Product product1 = new Product("P1", "Nike Air Shoes",
                "Lightweight and comfortable running shoes by Nike.",
                120.00, "Footwear", "S1", "Nike");
        ArrayList<String> shoeSizes = new ArrayList<>();
        shoeSizes.add("S"); shoeSizes.add("M"); shoeSizes.add("L"); shoeSizes.add("XL");
        ArrayList<String> shoeColors = new ArrayList<>();
        shoeColors.add("White"); shoeColors.add("Black"); shoeColors.add("Red");
        product1.setSizes(shoeSizes);
        product1.setColors(shoeColors);
        product1.setRating(4.5);
        productController.addProductDirect(product1);
        productController.addInventoryDirect(
                new Inventory("INV1", "P1", 50, "Warehouse-A", 5));

        // Levi's Jeans
        Product product2 = new Product("P2", "Levi's Jeans",
                "Classic straight-fit denim jeans by Levi's.",
                80.00, "Bottoms", "S1", "Levis");
        ArrayList<String> jeanSizes = new ArrayList<>();
        jeanSizes.add("28"); jeanSizes.add("30"); jeanSizes.add("32"); jeanSizes.add("34");
        ArrayList<String> jeanColors = new ArrayList<>();
        jeanColors.add("Blue"); jeanColors.add("Black"); jeanColors.add("Grey");
        product2.setSizes(jeanSizes);
        product2.setColors(jeanColors);
        product2.setRating(4.3);
        productController.addProductDirect(product2);
        productController.addInventoryDirect(
                new Inventory("INV2", "P2", 30, "Warehouse-A", 5));

        // Zara Summer Dress
        Product product3 = new Product("P3", "Zara Summer Dress",
                "Floral printed summer dress, perfect for warm weather.",
                65.00, "Dresses", "S2", "Zara");
        ArrayList<String> dressSizes = new ArrayList<>();
        dressSizes.add("XS"); dressSizes.add("S"); dressSizes.add("M"); dressSizes.add("L");
        ArrayList<String> dressColors = new ArrayList<>();
        dressColors.add("Floral"); dressColors.add("White"); dressColors.add("Pink");
        product3.setSizes(dressSizes);
        product3.setColors(dressColors);
        product3.setRating(4.6);
        productController.addProductDirect(product3);
        productController.addInventoryDirect(
                new Inventory("INV3", "P3", 25, "Warehouse-B", 5));

        // H&M Basic T-Shirt
        Product product4 = new Product("P4", "H&M Basic T-Shirt",
                "Everyday essential cotton T-shirt in multiple colors.",
                25.00, "Tops", "S2", "HnM");
        ArrayList<String> tshirtSizes = new ArrayList<>();
        tshirtSizes.add("S"); tshirtSizes.add("M"); tshirtSizes.add("L");
        tshirtSizes.add("XL"); tshirtSizes.add("XXL");
        ArrayList<String> tshirtColors = new ArrayList<>();
        tshirtColors.add("White"); tshirtColors.add("Black"); tshirtColors.add("Navy");
        tshirtColors.add("Grey");
        product4.setSizes(tshirtSizes);
        product4.setColors(tshirtColors);
        product4.setRating(4.1);
        productController.addProductDirect(product4);
        productController.addInventoryDirect(
                new Inventory("INV4", "P4", 100, "Warehouse-B", 10));

        // Adidas Hoodie
        Product product5 = new Product("P5", "Adidas Hoodie",
                "Cozy fleece hoodie with kangaroo pocket by Adidas.",
                95.00, "Outerwear", "S1", "Adidas");
        ArrayList<String> hoodieSizes = new ArrayList<>();
        hoodieSizes.add("S"); hoodieSizes.add("M"); hoodieSizes.add("L"); hoodieSizes.add("XL");
        ArrayList<String> hoodieColors = new ArrayList<>();
        hoodieColors.add("Black"); hoodieColors.add("Navy"); hoodieColors.add("Grey");
        product5.setSizes(hoodieSizes);
        product5.setColors(hoodieColors);
        product5.setRating(4.7);
        productController.addProductDirect(product5);
        productController.addInventoryDirect(
                new Inventory("INV5", "P5", 40, "Warehouse-A", 5));

        System.out.println("=========================");
        System.out.println(" VogueCart Data Loaded!  ");
        System.out.println(" 5 Users | 5 Products    ");
        System.out.println("=========================");
    }
}
