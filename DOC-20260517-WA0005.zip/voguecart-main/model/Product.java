package voguecart.model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Product {

    private String productId;
    private String name;
    private String description;
    private double price;
    private double discountPrice;
    private String imageURL;
    private String categoryId;
    private String sellerId;
    private String brand;
    private ArrayList<String> sizes;
    private ArrayList<String> colors;
    private double rating;
    private LocalDateTime createdAt;

    public Product() {
        this.sizes = new ArrayList<>();
        this.colors = new ArrayList<>();
        this.rating = 0.0;
        this.createdAt = LocalDateTime.now();
    }

    public Product(String productId, String name, String description, double price,
                   String categoryId, String sellerId, String brand) {
        this.productId = productId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.discountPrice = 0.0;
        this.imageURL = "";
        this.categoryId = categoryId;
        this.sellerId = sellerId;
        this.brand = brand;
        this.sizes = new ArrayList<>();
        this.colors = new ArrayList<>();
        this.rating = 0.0;
        this.createdAt = LocalDateTime.now();
    }

    public String getDetails() {
        double displayPrice = (discountPrice > 0) ? discountPrice : price;
        return String.format("ID: %s | %s | Brand: %s | Price: $%.2f | Rating: %.1f",
                productId, name, brand, displayPrice, rating);
    }

    public void updatePrice(double newPrice) {
        this.price = newPrice;
        System.out.println("✓ Price updated to $" + String.format("%.2f", newPrice));
    }

    public void applyDiscount(double discountPercent) {
        this.discountPrice = price - (price * discountPercent / 100);
        System.out.println("✓ Discount applied. New price: $" + String.format("%.2f", discountPrice));
    }

    public double getAverageRating() {
        return this.rating;
    }

    public boolean isAvailable() {
        return this.price > 0;
    }

    public double getEffectivePrice() {
        return (discountPrice > 0) ? discountPrice : price;
    }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public double getDiscountPrice() { return discountPrice; }
    public void setDiscountPrice(double discountPrice) { this.discountPrice = discountPrice; }

    public String getImageURL() { return imageURL; }
    public void setImageURL(String imageURL) { this.imageURL = imageURL; }

    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }

    public String getSellerId() { return sellerId; }
    public void setSellerId(String sellerId) { this.sellerId = sellerId; }

    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public ArrayList<String> getSizes() { return sizes; }
    public void setSizes(ArrayList<String> sizes) { this.sizes = sizes; }

    public ArrayList<String> getColors() { return colors; }
    public void setColors(ArrayList<String> colors) { this.colors = colors; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
