package voguecart.model;

public class Category {

    private String categoryId;
    private String name;
    private String description;
    private String parentCategoryId;

    public Category() {}

    public Category(String categoryId, String name, String description) {
        this.categoryId = categoryId;
        this.name = name;
        this.description = description;
        this.parentCategoryId = null;
    }

    public String getDetails() {
        return String.format("ID: %s | Name: %s | Description: %s", categoryId, name, description);
    }

    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getParentCategoryId() { return parentCategoryId; }
    public void setParentCategoryId(String parentCategoryId) { this.parentCategoryId = parentCategoryId; }
}
