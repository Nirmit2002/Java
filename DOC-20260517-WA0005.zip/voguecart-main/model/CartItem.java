package voguecart.model;

public class CartItem {

    private String cartItemId;
    private String productId;
    private String productName;
    private int quantity;
    private double unitPrice;
    private String selectedSize;
    private String selectedColor;
    private double subTotal;

    public CartItem() {}

    public CartItem(String cartItemId, String productId, String productName,
                    int quantity, double unitPrice, String selectedSize, String selectedColor) {
        this.cartItemId = cartItemId;
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.selectedSize = selectedSize;
        this.selectedColor = selectedColor;
        this.subTotal = quantity * unitPrice;
    }

    public double getSubTotal() {
        this.subTotal = quantity * unitPrice;
        return subTotal;
    }

    public void updateQuantity(int newQuantity) {
        this.quantity = newQuantity;
        this.subTotal = newQuantity * unitPrice;
    }

    public String getDetails() {
        return String.format("%-20s | Size: %-4s | Color: %-8s | Qty: %d | $%.2f each | Total: $%.2f",
                productName, selectedSize, selectedColor, quantity, unitPrice, getSubTotal());
    }

    public String getCartItemId() { return cartItemId; }
    public void setCartItemId(String cartItemId) { this.cartItemId = cartItemId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public String getSelectedSize() { return selectedSize; }
    public void setSelectedSize(String selectedSize) { this.selectedSize = selectedSize; }

    public String getSelectedColor() { return selectedColor; }
    public void setSelectedColor(String selectedColor) { this.selectedColor = selectedColor; }

    public void setSubTotal(double subTotal) { this.subTotal = subTotal; }
}
