package voguecart.model;

public class OrderItem {

    private String orderItemId;
    private String orderId;
    private String productId;
    private String productName;
    private int quantity;
    private double unitPrice;
    private double subTotal;

    public OrderItem() {}

    public OrderItem(String orderItemId, String orderId, String productId,
                     String productName, int quantity, double unitPrice) {
        this.orderItemId = orderItemId;
        this.orderId = orderId;
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.subTotal = quantity * unitPrice;
    }

    public double getSubTotal() {
        return quantity * unitPrice;
    }

    public String getDetails() {
        return String.format("%-20s | Qty: %d | $%.2f each | Total: $%.2f",
                productName, quantity, unitPrice, getSubTotal());
    }

    public String getOrderItemId() { return orderItemId; }
    public void setOrderItemId(String orderItemId) { this.orderItemId = orderItemId; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public void setSubTotal(double subTotal) { this.subTotal = subTotal; }
}
