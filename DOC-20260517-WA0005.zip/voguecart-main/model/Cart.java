package voguecart.model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Cart {

    private String cartId;
    private String customerId;
    private ArrayList<CartItem> items;
    private double totalPrice;
    private LocalDateTime lastUpdated;

    public Cart() {
        this.items = new ArrayList<>();
        this.totalPrice = 0.0;
        this.lastUpdated = LocalDateTime.now();
    }

    public Cart(String cartId, String customerId) {
        this.cartId = cartId;
        this.customerId = customerId;
        this.items = new ArrayList<>();
        this.totalPrice = 0.0;
        this.lastUpdated = LocalDateTime.now();
    }

    public void addItem(CartItem item) {
        for (CartItem existing : items) {
            if (existing.getProductId().equals(item.getProductId())
                    && existing.getSelectedSize().equals(item.getSelectedSize())
                    && existing.getSelectedColor().equals(item.getSelectedColor())) {
                existing.updateQuantity(existing.getQuantity() + item.getQuantity());
                calculateTotal();
                this.lastUpdated = LocalDateTime.now();
                System.out.println("✓ Item quantity updated in cart!");
                return;
            }
        }
        items.add(item);
        calculateTotal();
        this.lastUpdated = LocalDateTime.now();
        System.out.println("✓ Item added to cart!");
    }

    public boolean removeItem(String cartItemId) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getCartItemId().equals(cartItemId)) {
                items.remove(i);
                calculateTotal();
                this.lastUpdated = LocalDateTime.now();
                System.out.println("✓ Item removed from cart!");
                return true;
            }
        }
        System.out.println("✗ Cart item not found!");
        return false;
    }

    public boolean updateQuantity(String cartItemId, int newQuantity) {
        for (CartItem item : items) {
            if (item.getCartItemId().equals(cartItemId)) {
                if (newQuantity <= 0) {
                    return removeItem(cartItemId);
                }
                item.updateQuantity(newQuantity);
                calculateTotal();
                this.lastUpdated = LocalDateTime.now();
                System.out.println("✓ Quantity updated!");
                return true;
            }
        }
        System.out.println("✗ Cart item not found!");
        return false;
    }

    public double calculateTotal() {
        this.totalPrice = 0.0;
        for (CartItem item : items) {
            this.totalPrice += item.getSubTotal();
        }
        return this.totalPrice;
    }

    public void clearCart() {
        items.clear();
        this.totalPrice = 0.0;
        this.lastUpdated = LocalDateTime.now();
        System.out.println("✓ Cart cleared!");
    }

    public ArrayList<CartItem> getItems() {
        return items;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public String getCartId() { return cartId; }
    public void setCartId(String cartId) { this.cartId = cartId; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public void setItems(ArrayList<CartItem> items) { this.items = items; }

    public double getTotalPrice() { return calculateTotal(); }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    public LocalDateTime getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDateTime lastUpdated) { this.lastUpdated = lastUpdated; }
}
