package voguecart.model;

import java.time.LocalDateTime;

public class Notification {

    private String notificationId;
    private String userId;
    private String message;
    private String type;
    private boolean isRead;
    private LocalDateTime createdAt;
    private String redirectURL;

    public Notification() {
        this.isRead = false;
        this.createdAt = LocalDateTime.now();
    }

    public Notification(String notificationId, String userId, String message,
                        String type, String redirectURL) {
        this.notificationId = notificationId;
        this.userId = userId;
        this.message = message;
        this.type = type;
        this.isRead = false;
        this.createdAt = LocalDateTime.now();
        this.redirectURL = redirectURL;
    }

    public void sendNotification() {
        System.out.println("[NOTIFICATION] To User " + userId + " [" + type + "]: " + message);
    }

    public void markAsRead() {
        this.isRead = true;
    }

    public void deleteNotification() {
        this.message = "[Deleted]";
        this.isRead = true;
        System.out.println("✓ Notification deleted.");
    }

    public int getUnreadCount() {
        return isRead ? 0 : 1;
    }

    public String getNotificationId() { return notificationId; }
    public void setNotificationId(String notificationId) { this.notificationId = notificationId; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public boolean isRead() { return isRead; }
    public void setRead(boolean isRead) { this.isRead = isRead; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public String getRedirectURL() { return redirectURL; }
    public void setRedirectURL(String redirectURL) { this.redirectURL = redirectURL; }
}
