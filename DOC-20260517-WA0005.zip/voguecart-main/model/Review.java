package voguecart.model;

import java.time.LocalDateTime;

public class Review {

    private String reviewId;
    private String customerId;
    private String productId;
    private int rating;
    private String comment;
    private LocalDateTime date;
    private boolean isVerifiedPurchase;
    private int helpfulCount;

    public Review() {
        this.date = LocalDateTime.now();
        this.helpfulCount = 0;
        this.isVerifiedPurchase = false;
    }

    public Review(String reviewId, String customerId, String productId,
                  int rating, String comment, boolean isVerifiedPurchase) {
        this.reviewId = reviewId;
        this.customerId = customerId;
        this.productId = productId;
        this.rating = rating;
        this.comment = comment;
        this.date = LocalDateTime.now();
        this.isVerifiedPurchase = isVerifiedPurchase;
        this.helpfulCount = 0;
    }

    public void submitReview() {
        System.out.println("✓ Review submitted successfully!");
        System.out.println("  Rating : " + rating + "/5");
        System.out.println("  Comment: " + comment);
    }

    public void deleteReview() {
        this.comment = "[Deleted]";
        System.out.println("✓ Review deleted.");
    }

    public void markAsHelpful() {
        this.helpfulCount++;
        System.out.println("✓ Marked as helpful! Total: " + helpfulCount);
    }

    public void editReview(int newRating, String newComment) {
        this.rating = newRating;
        this.comment = newComment;
        this.date = LocalDateTime.now();
        System.out.println("✓ Review updated successfully!");
    }

    public String getDetails() {
        return String.format("Review by Customer %s | Rating: %d/5 | %s%s\n  \"%s\"",
                customerId, rating, date,
                isVerifiedPurchase ? " [Verified Purchase]" : "",
                comment);
    }

    public String getReviewId() { return reviewId; }
    public void setReviewId(String reviewId) { this.reviewId = reviewId; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public LocalDateTime getDate() { return date; }
    public void setDate(LocalDateTime date) { this.date = date; }

    public boolean isVerifiedPurchase() { return isVerifiedPurchase; }
    public void setVerifiedPurchase(boolean verifiedPurchase) { isVerifiedPurchase = verifiedPurchase; }

    public int getHelpfulCount() { return helpfulCount; }
    public void setHelpfulCount(int helpfulCount) { this.helpfulCount = helpfulCount; }
}
