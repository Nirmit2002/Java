package voguecart.model;

import java.util.ArrayList;

public class Customer extends User {

    private String customerId;
    private int loyaltyPoints;
    private ArrayList<String> wishlist;
    private ShippingAddress defaultAddress;

    public Customer() {
        super();
        this.wishlist = new ArrayList<>();
        this.loyaltyPoints = 0;
    }

    public Customer(String userId, String customerId, String name, String email,
                    String password, String phone) {
        super(userId, name, email, password, phone, "CUSTOMER");
        this.customerId = customerId;
        this.wishlist = new ArrayList<>();
        this.loyaltyPoints = 0;
    }

    @Override
    public boolean login(String email, String password) {
        if (this.getEmail().equals(email) && this.getPassword().equals(password)) {
            System.out.println("✓ Login successful! Welcome, " + getName() + "!");
            return true;
        }
        return false;
    }

    @Override
    public void logout() {
        System.out.println("✓ Logged out successfully. Goodbye, " + getName() + "!");
    }

    public void browseProducts() {
        System.out.println("Browsing all products...");
    }

    public void searchProduct(String keyword) {
        System.out.println("Searching for: " + keyword);
    }

    public void addToCart(String productId) {
        System.out.println("Adding product " + productId + " to cart...");
    }

    public void removeFromCart(String cartItemId) {
        System.out.println("Removing item " + cartItemId + " from cart...");
    }

    public void placeOrder() {
        System.out.println("Placing order...");
    }

    public void makePayment(String orderId) {
        System.out.println("Processing payment for order " + orderId + "...");
    }

    public void trackOrder(String orderId) {
        System.out.println("Tracking order: " + orderId);
    }

    public void writeReview(String productId, int rating, String comment) {
        System.out.println("Writing review for product: " + productId);
    }

    public void viewOrderHistory() {
        System.out.println("Loading order history...");
    }

    public void addToWishlist(String productId) {
        if (!wishlist.contains(productId)) {
            wishlist.add(productId);
            System.out.println("✓ Product added to wishlist!");
        } else {
            System.out.println("Product already in wishlist.");
        }
    }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public int getLoyaltyPoints() { return loyaltyPoints; }
    public void setLoyaltyPoints(int loyaltyPoints) { this.loyaltyPoints = loyaltyPoints; }

    public ArrayList<String> getWishlist() { return wishlist; }
    public void setWishlist(ArrayList<String> wishlist) { this.wishlist = wishlist; }

    public ShippingAddress getDefaultAddress() { return defaultAddress; }
    public void setDefaultAddress(ShippingAddress defaultAddress) { this.defaultAddress = defaultAddress; }
}
