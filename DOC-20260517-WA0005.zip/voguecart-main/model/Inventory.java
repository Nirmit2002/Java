package voguecart.model;

import java.time.LocalDateTime;

public class Inventory {

    private String inventoryId;
    private String productId;
    private int stockLevel;
    private int reservedStock;
    private String warehouseLocation;
    private LocalDateTime lastRestocked;
    private int minimumStockAlert;

    public Inventory() {
        this.stockLevel = 0;
        this.reservedStock = 0;
        this.minimumStockAlert = 5;
        this.lastRestocked = LocalDateTime.now();
    }

    public Inventory(String inventoryId, String productId, int stockLevel,
                     String warehouseLocation, int minimumStockAlert) {
        this.inventoryId = inventoryId;
        this.productId = productId;
        this.stockLevel = stockLevel;
        this.reservedStock = 0;
        this.warehouseLocation = warehouseLocation;
        this.lastRestocked = LocalDateTime.now();
        this.minimumStockAlert = minimumStockAlert;
    }

    public void updateStock(int delta) {
        this.stockLevel += delta;
        if (delta > 0) {
            this.lastRestocked = LocalDateTime.now();
            System.out.println("✓ Stock updated. New level: " + stockLevel);
        }
        sendLowStockAlert();
    }

    public boolean checkAvailability(int requestedQuantity) {
        return (stockLevel - reservedStock) >= requestedQuantity;
    }

    public boolean reserveStock(int quantity) {
        if (checkAvailability(quantity)) {
            reservedStock += quantity;
            System.out.println("✓ Stock reserved: " + quantity + " units");
            return true;
        }
        System.out.println("✗ Insufficient stock to reserve " + quantity + " units");
        return false;
    }

    public void releaseStock(int quantity) {
        if (reservedStock >= quantity) {
            reservedStock -= quantity;
            System.out.println("✓ Stock released: " + quantity + " units");
        }
    }

    public void sendLowStockAlert() {
        if (stockLevel <= minimumStockAlert) {
            System.out.println("⚠ LOW STOCK ALERT: Product " + productId
                    + " has only " + stockLevel + " units remaining!");
        }
    }

    public int getAvailableStock() {
        return stockLevel - reservedStock;
    }

    public String getInventoryId() { return inventoryId; }
    public void setInventoryId(String inventoryId) { this.inventoryId = inventoryId; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public int getStockLevel() { return stockLevel; }
    public void setStockLevel(int stockLevel) { this.stockLevel = stockLevel; }

    public int getReservedStock() { return reservedStock; }
    public void setReservedStock(int reservedStock) { this.reservedStock = reservedStock; }

    public String getWarehouseLocation() { return warehouseLocation; }
    public void setWarehouseLocation(String warehouseLocation) { this.warehouseLocation = warehouseLocation; }

    public LocalDateTime getLastRestocked() { return lastRestocked; }
    public void setLastRestocked(LocalDateTime lastRestocked) { this.lastRestocked = lastRestocked; }

    public int getMinimumStockAlert() { return minimumStockAlert; }
    public void setMinimumStockAlert(int minimumStockAlert) { this.minimumStockAlert = minimumStockAlert; }
}
