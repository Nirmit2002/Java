package voguecart.model;

import java.time.LocalDateTime;

public class Admin extends User {

    private String adminId;
    private int accessLevel;
    private LocalDateTime lastLogin;

    public Admin() {
        super();
        this.accessLevel = 1;
    }

    public Admin(String userId, String adminId, String name, String email,
                 String password, String phone, int accessLevel) {
        super(userId, name, email, password, phone, "ADMIN");
        this.adminId = adminId;
        this.accessLevel = accessLevel;
        this.lastLogin = LocalDateTime.now();
    }

    @Override
    public boolean login(String email, String password) {
        if (this.getEmail().equals(email) && this.getPassword().equals(password)) {
            this.lastLogin = LocalDateTime.now();
            System.out.println("✓ Login successful! Welcome, Admin " + getName() + "!");
            return true;
        }
        return false;
    }

    @Override
    public void logout() {
        System.out.println("✓ Admin logged out successfully. Goodbye, " + getName() + "!");
    }

    public void manageUsers() {
        System.out.println("Opening user management panel...");
    }

    public void manageProducts() {
        System.out.println("Opening product management panel...");
    }

    public void manageOrders() {
        System.out.println("Opening order management panel...");
    }

    public void viewSystemReport() {
        System.out.println("Generating system report...");
    }

    public void sendNotification(String userId, String message) {
        System.out.println("Sending notification to user " + userId + ": " + message);
    }

    public void manageCategories() {
        System.out.println("Opening category management panel...");
    }

    public String getAdminId() { return adminId; }
    public void setAdminId(String adminId) { this.adminId = adminId; }

    public int getAccessLevel() { return accessLevel; }
    public void setAccessLevel(int accessLevel) { this.accessLevel = accessLevel; }

    public LocalDateTime getLastLogin() { return lastLogin; }
    public void setLastLogin(LocalDateTime lastLogin) { this.lastLogin = lastLogin; }
}
