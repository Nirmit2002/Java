package voguecart.model;

public class Seller extends User {

    private String sellerId;
    private String storeName;
    private String storeDescription;
    private double rating;
    private int totalSales;
    private String bankDetails;

    public Seller() {
        super();
        this.rating = 0.0;
        this.totalSales = 0;
    }

    public Seller(String userId, String sellerId, String name, String email,
                  String password, String phone, String storeName) {
        super(userId, name, email, password, phone, "SELLER");
        this.sellerId = sellerId;
        this.storeName = storeName;
        this.storeDescription = "";
        this.rating = 0.0;
        this.totalSales = 0;
        this.bankDetails = "";
    }

    @Override
    public boolean login(String email, String password) {
        if (this.getEmail().equals(email) && this.getPassword().equals(password)) {
            System.out.println("✓ Login successful! Welcome, " + getName() + " (" + storeName + ")!");
            return true;
        }
        return false;
    }

    @Override
    public void logout() {
        System.out.println("✓ Logged out successfully. Goodbye, " + getName() + "!");
    }

    public void addProduct(String productName, double price, String category) {
        System.out.println("Adding product: " + productName);
    }

    public void updateProduct(String productId) {
        System.out.println("Updating product: " + productId);
    }

    public void deleteProduct(String productId) {
        System.out.println("Deleting product: " + productId);
    }

    public void viewSalesReport() {
        System.out.println("Total Sales: " + totalSales);
        System.out.println("Store Rating: " + rating);
    }

    public void manageInventory() {
        System.out.println("Managing inventory for store: " + storeName);
    }

    public void viewOrders() {
        System.out.println("Viewing orders for store: " + storeName);
    }

    public void incrementTotalSales(int amount) {
        this.totalSales += amount;
    }

    public String getSellerId() { return sellerId; }
    public void setSellerId(String sellerId) { this.sellerId = sellerId; }

    public String getStoreName() { return storeName; }
    public void setStoreName(String storeName) { this.storeName = storeName; }

    public String getStoreDescription() { return storeDescription; }
    public void setStoreDescription(String storeDescription) { this.storeDescription = storeDescription; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    public int getTotalSales() { return totalSales; }
    public void setTotalSales(int totalSales) { this.totalSales = totalSales; }

    public String getBankDetails() { return bankDetails; }
    public void setBankDetails(String bankDetails) { this.bankDetails = bankDetails; }
}
