package voguecart.model;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Order {

    private String orderId;
    private String customerId;
    private LocalDateTime orderDate;
    private LocalDateTime deliveryDate;
    private String status;
    private double totalAmount;
    private double shippingCost;
    private String trackingNumber;
    private ArrayList<OrderItem> items;

    public Order() {
        this.items = new ArrayList<>();
        this.status = "PENDING";
        this.orderDate = LocalDateTime.now();
        this.shippingCost = 0.0;
        this.totalAmount = 0.0;
    }

    public Order(String orderId, String customerId, double shippingCost) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.status = "PENDING";
        this.orderDate = LocalDateTime.now();
        this.shippingCost = shippingCost;
        this.items = new ArrayList<>();
        this.trackingNumber = "TRK" + orderId;
    }

    public void placeOrder() {
        this.status = "CONFIRMED";
        this.totalAmount = calculateTotal();
        System.out.println("✓ Order placed successfully! Order ID: " + orderId);
        System.out.println("  Tracking Number: " + trackingNumber);
    }

    public boolean cancelOrder() {
        if (status.equals("PENDING") || status.equals("CONFIRMED")) {
            this.status = "CANCELLED";
            System.out.println("✓ Order " + orderId + " has been cancelled.");
            return true;
        }
        System.out.println("✗ Cannot cancel order. Current status: " + status);
        return false;
    }

    public String getStatus() {
        return status;
    }

    public void updateStatus(String newStatus) {
        this.status = newStatus;
        System.out.println("✓ Order status updated to: " + newStatus);
    }

    public void generateInvoice() {
        System.out.println("=========================");
        System.out.println("       INVOICE           ");
        System.out.println("=========================");
        System.out.println("Order ID    : " + orderId);
        System.out.println("Customer ID : " + customerId);
        System.out.println("Order Date  : " + orderDate);
        System.out.println("Status      : " + status);
        System.out.println("-------------------------");
        System.out.println("Items:");
        for (OrderItem item : items) {
            System.out.println("  " + item.getDetails());
        }
        System.out.println("-------------------------");
        System.out.println("Shipping Cost : $" + String.format("%.2f", shippingCost));
        System.out.println("Total Amount  : $" + String.format("%.2f", totalAmount));
        System.out.println("Tracking No.  : " + trackingNumber);
        System.out.println("=========================");
    }

    public double calculateTotal() {
        double itemsTotal = 0.0;
        for (OrderItem item : items) {
            itemsTotal += item.getSubTotal();
        }
        this.totalAmount = itemsTotal + shippingCost;
        return this.totalAmount;
    }

    public void addItem(OrderItem item) {
        items.add(item);
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public LocalDateTime getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDateTime orderDate) { this.orderDate = orderDate; }

    public LocalDateTime getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(LocalDateTime deliveryDate) { this.deliveryDate = deliveryDate; }

    public void setStatus(String status) { this.status = status; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public double getShippingCost() { return shippingCost; }
    public void setShippingCost(double shippingCost) { this.shippingCost = shippingCost; }

    public String getTrackingNumber() { return trackingNumber; }
    public void setTrackingNumber(String trackingNumber) { this.trackingNumber = trackingNumber; }

    public ArrayList<OrderItem> getItems() { return items; }
    public void setItems(ArrayList<OrderItem> items) { this.items = items; }
}
