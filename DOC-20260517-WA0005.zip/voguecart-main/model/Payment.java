package voguecart.model;

import java.time.LocalDateTime;
import java.util.UUID;

public class Payment {

    private String paymentId;
    private String orderId;
    private String customerId;
    private double amount;
    private String method;
    private String status;
    private LocalDateTime transactionDate;
    private String transactionId;
    private String currency;

    public Payment() {
        this.status = "PENDING";
        this.currency = "USD";
        this.transactionDate = LocalDateTime.now();
    }

    public Payment(String paymentId, String orderId, String customerId,
                   double amount, String method) {
        this.paymentId = paymentId;
        this.orderId = orderId;
        this.customerId = customerId;
        this.amount = amount;
        this.method = method;
        this.status = "PENDING";
        this.currency = "USD";
        this.transactionDate = LocalDateTime.now();
    }

    public boolean processPayment() {
        if (!validatePayment()) {
            System.out.println("✗ Payment validation failed!");
            return false;
        }
        this.transactionId = "TXN" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.status = "COMPLETED";
        this.transactionDate = LocalDateTime.now();
        System.out.println("✓ Payment processed successfully!");
        System.out.println("  Transaction ID: " + transactionId);
        System.out.println("  Amount: $" + String.format("%.2f", amount) + " " + currency);
        System.out.println("  Method: " + method);
        return true;
    }

    public boolean refundPayment() {
        if (status.equals("COMPLETED")) {
            this.status = "REFUNDED";
            System.out.println("✓ Payment refunded successfully!");
            System.out.println("  Refund Amount: $" + String.format("%.2f", amount));
            return true;
        }
        System.out.println("✗ Cannot refund. Payment status: " + status);
        return false;
    }

    public String getPaymentStatus() {
        return status;
    }

    public void generateReceipt() {
        System.out.println("=========================");
        System.out.println("       RECEIPT           ");
        System.out.println("=========================");
        System.out.println("Payment ID     : " + paymentId);
        System.out.println("Order ID       : " + orderId);
        System.out.println("Transaction ID : " + transactionId);
        System.out.println("Amount         : $" + String.format("%.2f", amount) + " " + currency);
        System.out.println("Method         : " + method);
        System.out.println("Status         : " + status);
        System.out.println("Date           : " + transactionDate);
        System.out.println("=========================");
    }

    public boolean validatePayment() {
        return amount > 0 && method != null && !method.trim().isEmpty();
    }

    public String getPaymentId() { return paymentId; }
    public void setPaymentId(String paymentId) { this.paymentId = paymentId; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getTransactionDate() { return transactionDate; }
    public void setTransactionDate(LocalDateTime transactionDate) { this.transactionDate = transactionDate; }

    public String getTransactionId() { return transactionId; }
    public void setTransactionId(String transactionId) { this.transactionId = transactionId; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
}
