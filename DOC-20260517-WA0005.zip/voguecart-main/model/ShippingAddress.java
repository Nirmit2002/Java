package voguecart.model;

public class ShippingAddress {

    private String addressId;
    private String customerId;
    private String fullName;
    private String street;
    private String city;
    private String state;
    private String country;
    private String zipCode;
    private boolean isDefault;
    private String phone;

    public ShippingAddress() {
        this.isDefault = false;
    }

    public ShippingAddress(String addressId, String customerId, String fullName,
                           String street, String city, String state,
                           String country, String zipCode, String phone) {
        this.addressId = addressId;
        this.customerId = customerId;
        this.fullName = fullName;
        this.street = street;
        this.city = city;
        this.state = state;
        this.country = country;
        this.zipCode = zipCode;
        this.phone = phone;
        this.isDefault = false;
    }

    public boolean validateAddress() {
        if (fullName == null || fullName.trim().isEmpty()) return false;
        if (street == null || street.trim().isEmpty()) return false;
        if (city == null || city.trim().isEmpty()) return false;
        if (state == null || state.trim().isEmpty()) return false;
        if (country == null || country.trim().isEmpty()) return false;
        if (zipCode == null || zipCode.trim().isEmpty()) return false;
        return true;
    }

    public void setAsDefault() {
        this.isDefault = true;
        System.out.println("✓ Address set as default.");
    }

    public String getFullAddress() {
        return fullName + "\n"
                + street + "\n"
                + city + ", " + state + " " + zipCode + "\n"
                + country + "\n"
                + "Phone: " + phone;
    }

    public String getAddressId() { return addressId; }
    public void setAddressId(String addressId) { this.addressId = addressId; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public String getStreet() { return street; }
    public void setStreet(String street) { this.street = street; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getState() { return state; }
    public void setState(String state) { this.state = state; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getZipCode() { return zipCode; }
    public void setZipCode(String zipCode) { this.zipCode = zipCode; }

    public boolean isDefault() { return isDefault; }
    public void setDefault(boolean isDefault) { this.isDefault = isDefault; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}
