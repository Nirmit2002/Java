package voguecart.view;

import voguecart.controller.OrderController;
import voguecart.controller.PaymentController;
import voguecart.controller.ProductController;
import voguecart.controller.UserController;
import voguecart.model.Admin;
import voguecart.model.Order;
import voguecart.model.Payment;
import voguecart.model.Product;
import voguecart.model.User;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class AdminView {

    private Scanner scanner;
    private UserController userController;
    private ProductController productController;
    private OrderController orderController;
    private PaymentController paymentController;
    private ProductView productView;

    public AdminView(Scanner scanner, UserController userController,
                     ProductController productController, OrderController orderController,
                     PaymentController paymentController) {
        this.scanner = scanner;
        this.userController = userController;
        this.productController = productController;
        this.orderController = orderController;
        this.paymentController = paymentController;
        this.productView = new ProductView();
    }

    public void showMenu(Admin admin) {
        boolean loggedIn = true;
        while (loggedIn) {
            System.out.println("=========================");
            System.out.println("     Admin Dashboard     ");
            System.out.println("  Admin: " + admin.getName());
            System.out.println("=========================");
            System.out.println("1) Manage Users");
            System.out.println("2) Manage Products");
            System.out.println("3) Manage Orders");
            System.out.println("4) View System Report");
            System.out.println("5) Send Notification");
            System.out.println("6) Logout");
            System.out.println("=========================");
            System.out.print("Enter your choice: ");

            int choice = readInt();
            switch (choice) {
                case 1:
                    handleManageUsers();
                    break;
                case 2:
                    handleManageProducts();
                    break;
                case 3:
                    handleManageOrders();
                    break;
                case 4:
                    handleViewSystemReport();
                    break;
                case 5:
                    handleSendNotification();
                    break;
                case 6:
                    loggedIn = false;
                    admin.logout();
                    break;
                default:
                    System.out.println("✗ Invalid option. Please try again.");
            }
        }
    }

    private void handleManageUsers() {
        userController.listUsers();
        System.out.println("Options:");
        System.out.println("1) View User Details");
        System.out.println("2) Back");
        System.out.print("Choice: ");
        int choice = readInt();
        if (choice == 1) {
            System.out.print("Enter User ID: ");
            String userId = scanner.nextLine().trim();
            User user = userController.getUserDetails(userId);
            if (user != null) {
                System.out.println("=========================");
                System.out.println("Name  : " + user.getName());
                System.out.println("Email : " + user.getEmail());
                System.out.println("Role  : " + user.getRole());
                System.out.println("Phone : " + user.getPhone());
                System.out.println("ID    : " + user.getUserId());
                System.out.println("=========================");
            }
        }
    }

    private void handleManageProducts() {
        ArrayList<Product> allProducts = productController.listProducts();
        productView.displayProductList(allProducts);
        System.out.println("Options:");
        System.out.println("1) View Product Details");
        System.out.println("2) Delete Product");
        System.out.println("3) Back");
        System.out.print("Choice: ");
        int choice = readInt();
        if (choice == 1) {
            System.out.print("Enter Product ID: ");
            String productId = scanner.nextLine().trim();
            Product product = productController.getProductDetails(productId);
            if (product != null) {
                productView.displayProductDetails(product);
            }
        } else if (choice == 2) {
            System.out.print("Enter Product ID to delete: ");
            String productId = scanner.nextLine().trim();
            productController.deleteProduct(productId);
        }
    }

    private void handleManageOrders() {
        ArrayList<Order> allOrders = orderController.listAllOrders();
        if (allOrders.isEmpty()) {
            System.out.println("No orders in the system.");
            return;
        }
        System.out.println("=========================");
        System.out.println("        All Orders       ");
        System.out.println("=========================");
        for (Order order : allOrders) {
            System.out.println("Order ID    : " + order.getOrderId());
            System.out.println("Customer ID : " + order.getCustomerId());
            System.out.println("Status      : " + order.getStatus());
            System.out.println("Total       : $" + String.format("%.2f", order.getTotalAmount()));
            System.out.println("Date        : " + order.getOrderDate());
            System.out.println("-------------------------");
        }
        System.out.println("Options:");
        System.out.println("1) Update Order Status");
        System.out.println("2) Back");
        System.out.print("Choice: ");
        int choice = readInt();
        if (choice == 1) {
            System.out.print("Enter Order ID: ");
            String orderId = scanner.nextLine().trim();
            System.out.println("New Status options: PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED");
            System.out.print("Enter new status: ");
            String newStatus = scanner.nextLine().trim().toUpperCase();
            orderController.updateOrderStatus(orderId, newStatus);
        }
    }

    private void handleViewSystemReport() {
        System.out.println("=========================");
        System.out.println("     System Report       ");
        System.out.println("=========================");
        System.out.println("Total Users    : " + userController.getAllUsers().size());
        System.out.println("Total Products : " + productController.listProducts().size());
        System.out.println("Total Orders   : " + orderController.listAllOrders().size());
        double totalRevenue = 0.0;
        for (Payment payment : paymentController.getAllPayments()) {
            if (payment.getStatus().equals("COMPLETED")) {
                totalRevenue += payment.getAmount();
            }
        }
        System.out.printf("Total Revenue  : $%.2f%n", totalRevenue);
        System.out.println("=========================");
    }

    private void handleSendNotification() {
        System.out.print("Enter User ID to notify: ");
        String userId = scanner.nextLine().trim();
        User user = userController.getUserDetails(userId);
        if (user == null) return;

        System.out.print("Enter notification message: ");
        String message = scanner.nextLine().trim();
        if (message.isEmpty()) {
            System.out.println("✗ Message cannot be empty.");
            return;
        }
        userController.sendNotification(userId, message, "ADMIN");
    }

    private int readInt() {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException exception) {
            return -1;
        } catch (NoSuchElementException exception) {
            return 6;
        }
    }
}
