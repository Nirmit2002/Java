package voguecart.view;

import voguecart.model.Product;

import java.util.ArrayList;

public class ProductView {

    public void displayProductDetails(Product product) {
        System.out.println("=========================");
        System.out.println("    Product Details      ");
        System.out.println("=========================");
        System.out.println("ID          : " + product.getProductId());
        System.out.println("Name        : " + product.getName());
        System.out.println("Brand       : " + product.getBrand());
        System.out.println("Description : " + product.getDescription());
        System.out.println("Price       : $" + String.format("%.2f", product.getPrice()));
        if (product.getDiscountPrice() > 0) {
            System.out.println("Sale Price  : $" + String.format("%.2f", product.getDiscountPrice()));
        }
        System.out.println("Rating      : " + product.getRating() + "/5.0");
        System.out.println("Sizes       : " + product.getSizes());
        System.out.println("Colors      : " + product.getColors());
        System.out.println("=========================");
    }

    public void displayProductList(ArrayList<Product> products) {
        if (products.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        System.out.println("=========================");
        System.out.println("     Product Catalog     ");
        System.out.println("=========================");
        int index = 1;
        for (Product product : products) {
            double displayPrice = (product.getDiscountPrice() > 0)
                    ? product.getDiscountPrice() : product.getPrice();
            System.out.printf("%-3d %-20s | %-10s | $%-8.2f | Rating: %.1f | Sizes: %s%n",
                    index, product.getName(), product.getBrand(),
                    displayPrice, product.getRating(), product.getSizes());
            System.out.println("    ID: " + product.getProductId());
            index++;
        }
        System.out.println("=========================");
    }

    public void displaySearchResults(ArrayList<Product> results, String keyword) {
        System.out.println("=========================");
        System.out.println("Search Results for: \"" + keyword + "\"");
        System.out.println("=========================");
        if (results.isEmpty()) {
            System.out.println("No products found matching \"" + keyword + "\".");
        } else {
            System.out.println("Found " + results.size() + " result(s):");
            displayProductList(results);
        }
    }
}
