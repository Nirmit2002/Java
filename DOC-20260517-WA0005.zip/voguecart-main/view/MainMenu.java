package voguecart.view;

import java.util.NoSuchElementException;
import java.util.Scanner;

public class MainMenu {

    private Scanner scanner;

    public MainMenu(Scanner scanner) {
        this.scanner = scanner;
    }

    public void displayMenu() {
        System.out.println("=========================");
        System.out.println("   Welcome to VogueCart  ");
        System.out.println("  Fashion E-Commerce App ");
        System.out.println("=========================");
        System.out.println("1) Login");
        System.out.println("2) Register");
        System.out.println("3) Exit");
        System.out.println("=========================");
        System.out.print("Enter your choice: ");
    }

    public int getUserChoice() {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException exception) {
            return -1;
        } catch (NoSuchElementException exception) {
            return 3;
        }
    }
}
