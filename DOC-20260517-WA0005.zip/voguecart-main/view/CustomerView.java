package voguecart.view;

import voguecart.controller.CartController;
import voguecart.controller.OrderController;
import voguecart.controller.PaymentController;
import voguecart.controller.ProductController;
import voguecart.controller.UserController;
import voguecart.model.Cart;
import voguecart.model.CartItem;
import voguecart.model.Customer;
import voguecart.model.Inventory;
import voguecart.model.Order;
import voguecart.model.Payment;
import voguecart.model.Product;
import voguecart.model.Review;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class CustomerView {

    private Scanner scanner;
    private ProductController productController;
    private CartController cartController;
    private OrderController orderController;
    private PaymentController paymentController;
    private UserController userController;
    private ProductView productView;

    public CustomerView(Scanner scanner, ProductController productController,
                        CartController cartController, OrderController orderController,
                        PaymentController paymentController, UserController userController) {
        this.scanner = scanner;
        this.productController = productController;
        this.cartController = cartController;
        this.orderController = orderController;
        this.paymentController = paymentController;
        this.userController = userController;
        this.productView = new ProductView();
    }

    public void showMenu(Customer customer) {
        boolean loggedIn = true;
        while (loggedIn) {
            System.out.println("=========================");
            System.out.println("   Customer Dashboard    ");
            System.out.println("  Hello, " + customer.getName() + "!");
            System.out.println("=========================");
            System.out.println("1) Browse Products");
            System.out.println("2) Search Product");
            System.out.println("3) View Cart");
            System.out.println("4) Add to Cart");
            System.out.println("5) Place Order");
            System.out.println("6) View Orders");
            System.out.println("7) Write Review");
            System.out.println("8) Logout");
            System.out.println("=========================");
            System.out.print("Enter your choice: ");

            int choice = readInt();
            switch (choice) {
                case 1:
                    handleBrowseProducts();
                    break;
                case 2:
                    handleSearchProduct();
                    break;
                case 3:
                    handleViewCart(customer);
                    break;
                case 4:
                    handleAddToCart(customer);
                    break;
                case 5:
                    handlePlaceOrder(customer);
                    break;
                case 6:
                    handleViewOrders(customer);
                    break;
                case 7:
                    handleWriteReview(customer);
                    break;
                case 8:
                    loggedIn = false;
                    customer.logout();
                    break;
                default:
                    System.out.println("✗ Invalid option. Please try again.");
            }
        }
    }

    private void handleBrowseProducts() {
        ArrayList<Product> allProducts = productController.listProducts();
        productView.displayProductList(allProducts);
    }

    private void handleSearchProduct() {
        System.out.print("Enter search keyword: ");
        String keyword = scanner.nextLine().trim();
        if (keyword.isEmpty()) {
            System.out.println("✗ Keyword cannot be empty.");
            return;
        }
        ArrayList<Product> results = productController.searchProduct(keyword);
        productView.displaySearchResults(results, keyword);
    }

    private void handleViewCart(Customer customer) {
        Cart cart = cartController.getCart(customer.getCustomerId());
        if (cart == null || cart.isEmpty()) {
            System.out.println("Your cart is empty.");
            return;
        }
        System.out.println("=========================");
        System.out.println("       Your Cart         ");
        System.out.println("=========================");
        for (CartItem item : cart.getItems()) {
            System.out.println("  " + item.getDetails());
            System.out.println("  Item ID: " + item.getCartItemId());
            System.out.println("  -------------------------");
        }
        System.out.printf("  TOTAL: $%.2f%n", cart.getTotalPrice());
        System.out.println("=========================");
    }

    private void handleAddToCart(Customer customer) {
        ArrayList<Product> allProducts = productController.listProducts();
        if (allProducts.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        productView.displayProductList(allProducts);

        System.out.print("Enter Product ID to add: ");
        String productId = scanner.nextLine().trim();
        Product product = productController.getProductDetails(productId);
        if (product == null) return;

        System.out.println("Available Sizes: " + product.getSizes());
        System.out.print("Select Size: ");
        String size = scanner.nextLine().trim();
        if (!product.getSizes().contains(size)) {
            System.out.println("✗ Invalid size selected.");
            return;
        }

        System.out.println("Available Colors: " + product.getColors());
        System.out.print("Select Color (or press Enter to skip): ");
        String color = scanner.nextLine().trim();
        if (color.isEmpty()) color = "Default";

        System.out.print("Enter Quantity: ");
        int quantity = readInt();
        if (quantity <= 0) {
            System.out.println("✗ Quantity must be greater than zero.");
            return;
        }

        Inventory inventory = productController.getInventory(productId);
        if (inventory != null && !inventory.checkAvailability(quantity)) {
            System.out.println("✗ Not enough stock available. Available: "
                    + inventory.getAvailableStock());
            return;
        }

        cartController.addToCart(customer.getCustomerId(), product, quantity, size, color);
    }

    private void handlePlaceOrder(Customer customer) {
        Cart cart = cartController.getCart(customer.getCustomerId());
        if (cart == null || cart.isEmpty()) {
            System.out.println("✗ Your cart is empty. Add items before placing an order.");
            return;
        }

        handleViewCart(customer);

        System.out.print("Enter shipping address (or press Enter to use default): ");
        String address = scanner.nextLine().trim();
        if (address.isEmpty()) address = "Default Address";

        double shippingCost = 9.99;
        System.out.println("Shipping Cost: $" + String.format("%.2f", shippingCost));
        System.out.printf("Order Total  : $%.2f%n", cart.getTotalPrice() + shippingCost);
        System.out.print("Confirm order? (yes/no): ");
        String confirm = scanner.nextLine().trim();
        if (!confirm.equalsIgnoreCase("yes")) {
            System.out.println("Order cancelled.");
            return;
        }

        Order order = orderController.placeOrder(customer.getCustomerId(), cart, shippingCost);
        if (order == null) return;

        System.out.println("=========================");
        System.out.println("  Select Payment Method  ");
        System.out.println("=========================");
        System.out.println("1) Credit Card");
        System.out.println("2) Debit Card");
        System.out.println("3) UPI / Net Banking");
        System.out.println("4) Cash on Delivery");
        System.out.print("Enter choice: ");
        int paymentChoice = readInt();
        String paymentMethod;
        switch (paymentChoice) {
            case 1: paymentMethod = "CREDIT_CARD"; break;
            case 2: paymentMethod = "DEBIT_CARD"; break;
            case 3: paymentMethod = "UPI"; break;
            case 4: paymentMethod = "COD"; break;
            default: paymentMethod = "COD";
        }

        Payment payment = paymentController.processPayment(
                order.getOrderId(), customer.getCustomerId(),
                order.calculateTotal(), paymentMethod);

        if (payment != null) {
            payment.generateReceipt();
            order.generateInvoice();
            cartController.clearCart(customer.getCustomerId());
            System.out.println("✓ Order confirmed! Tracking No: " + order.getTrackingNumber());
        }
    }

    private void handleViewOrders(Customer customer) {
        ArrayList<Order> orders = orderController.listOrders(customer.getCustomerId());
        if (orders.isEmpty()) {
            System.out.println("You have no orders yet.");
            return;
        }
        System.out.println("=========================");
        System.out.println("      Your Orders        ");
        System.out.println("=========================");
        for (Order order : orders) {
            System.out.println("Order ID   : " + order.getOrderId());
            System.out.println("Status     : " + order.getStatus());
            System.out.println("Total      : $" + String.format("%.2f", order.getTotalAmount()));
            System.out.println("Tracking   : " + order.getTrackingNumber());
            System.out.println("Date       : " + order.getOrderDate());
            System.out.println("-------------------------");
        }
    }

    private void handleWriteReview(Customer customer) {
        ArrayList<Order> orders = orderController.listOrders(customer.getCustomerId());
        if (orders.isEmpty()) {
            System.out.println("✗ You have no orders to review.");
            return;
        }
        System.out.print("Enter Product ID to review: ");
        String productId = scanner.nextLine().trim();
        Product product = productController.getProductDetails(productId);
        if (product == null) return;

        System.out.print("Enter rating (1-5): ");
        int rating = readInt();
        if (rating < 1 || rating > 5) {
            System.out.println("✗ Rating must be between 1 and 5.");
            return;
        }
        System.out.print("Enter your comment: ");
        String comment = scanner.nextLine().trim();

        String reviewId = "REV" + System.currentTimeMillis();
        Review review = new Review(reviewId, customer.getCustomerId(), productId,
                rating, comment, true);
        review.submitReview();
        System.out.println("✓ Thank you for your review on \"" + product.getName() + "\"!");
    }

    private int readInt() {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException exception) {
            return -1;
        } catch (NoSuchElementException exception) {
            return 8;
        }
    }
}
