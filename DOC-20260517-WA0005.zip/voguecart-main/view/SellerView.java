package voguecart.view;

import voguecart.controller.OrderController;
import voguecart.controller.ProductController;
import voguecart.model.Inventory;
import voguecart.model.Order;
import voguecart.model.Product;
import voguecart.model.Seller;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class SellerView {

    private Scanner scanner;
    private ProductController productController;
    private OrderController orderController;
    private ProductView productView;

    public SellerView(Scanner scanner, ProductController productController,
                      OrderController orderController) {
        this.scanner = scanner;
        this.productController = productController;
        this.orderController = orderController;
        this.productView = new ProductView();
    }

    public void showMenu(Seller seller) {
        boolean loggedIn = true;
        while (loggedIn) {
            System.out.println("=========================");
            System.out.println("    Seller Dashboard     ");
            System.out.println("  Store: " + seller.getStoreName());
            System.out.println("=========================");
            System.out.println("1) Add Product");
            System.out.println("2) View My Products");
            System.out.println("3) Update Product");
            System.out.println("4) Delete Product");
            System.out.println("5) View Sales Report");
            System.out.println("6) Manage Inventory");
            System.out.println("7) View Orders");
            System.out.println("8) Logout");
            System.out.println("=========================");
            System.out.print("Enter your choice: ");

            int choice = readInt();
            switch (choice) {
                case 1:
                    handleAddProduct(seller);
                    break;
                case 2:
                    handleViewMyProducts(seller);
                    break;
                case 3:
                    handleUpdateProduct(seller);
                    break;
                case 4:
                    handleDeleteProduct(seller);
                    break;
                case 5:
                    handleViewSalesReport(seller);
                    break;
                case 6:
                    handleManageInventory(seller);
                    break;
                case 7:
                    handleViewOrders();
                    break;
                case 8:
                    loggedIn = false;
                    seller.logout();
                    break;
                default:
                    System.out.println("✗ Invalid option. Please try again.");
            }
        }
    }

    private void handleAddProduct(Seller seller) {
        System.out.println("=========================");
        System.out.println("       Add Product       ");
        System.out.println("=========================");

        System.out.print("Product Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Description: ");
        String description = scanner.nextLine().trim();

        System.out.print("Price ($): ");
        double price = readDouble();
        if (price <= 0) {
            System.out.println("✗ Price must be greater than zero.");
            return;
        }

        System.out.print("Brand: ");
        String brand = scanner.nextLine().trim();

        System.out.print("Category (e.g. Tops, Bottoms, Footwear): ");
        String category = scanner.nextLine().trim();

        System.out.print("Sizes (comma-separated, e.g. S,M,L,XL): ");
        String sizesInput = scanner.nextLine().trim();
        ArrayList<String> sizes = new ArrayList<>();
        for (String size : sizesInput.split(",")) {
            sizes.add(size.trim());
        }

        System.out.print("Colors (comma-separated, e.g. Red,Blue): ");
        String colorsInput = scanner.nextLine().trim();
        ArrayList<String> colors = new ArrayList<>();
        for (String color : colorsInput.split(",")) {
            colors.add(color.trim());
        }

        System.out.print("Initial Stock Quantity: ");
        int stock = readInt();
        if (stock < 0) {
            System.out.println("✗ Stock cannot be negative.");
            return;
        }

        productController.addProduct(name, description, price, category,
                seller.getSellerId(), brand, sizes, colors, stock);
    }

    private void handleViewMyProducts(Seller seller) {
        ArrayList<Product> myProducts = productController.getProductsBySeller(seller.getSellerId());
        if (myProducts.isEmpty()) {
            System.out.println("You have no products listed yet.");
            return;
        }
        System.out.println("=========================");
        System.out.println("      My Products        ");
        System.out.println("=========================");
        productView.displayProductList(myProducts);
    }

    private void handleUpdateProduct(Seller seller) {
        ArrayList<Product> myProducts = productController.getProductsBySeller(seller.getSellerId());
        if (myProducts.isEmpty()) {
            System.out.println("You have no products to update.");
            return;
        }
        productView.displayProductList(myProducts);

        System.out.print("Enter Product ID to update: ");
        String productId = scanner.nextLine().trim();

        boolean owned = false;
        for (Product product : myProducts) {
            if (product.getProductId().equals(productId)) {
                owned = true;
                break;
            }
        }
        if (!owned) {
            System.out.println("✗ You do not own this product.");
            return;
        }

        System.out.print("New Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("New Description: ");
        String description = scanner.nextLine().trim();

        System.out.print("New Price ($): ");
        double price = readDouble();

        productController.updateProduct(productId, name, description, price);
    }

    private void handleDeleteProduct(Seller seller) {
        ArrayList<Product> myProducts = productController.getProductsBySeller(seller.getSellerId());
        if (myProducts.isEmpty()) {
            System.out.println("You have no products to delete.");
            return;
        }
        productView.displayProductList(myProducts);

        System.out.print("Enter Product ID to delete: ");
        String productId = scanner.nextLine().trim();

        boolean owned = false;
        for (Product product : myProducts) {
            if (product.getProductId().equals(productId)) {
                owned = true;
                break;
            }
        }
        if (!owned) {
            System.out.println("✗ You do not own this product.");
            return;
        }

        System.out.print("Are you sure you want to delete this product? (yes/no): ");
        String confirm = scanner.nextLine().trim();
        if (confirm.equalsIgnoreCase("yes")) {
            productController.deleteProduct(productId);
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    private void handleViewSalesReport(Seller seller) {
        System.out.println("=========================");
        System.out.println("      Sales Report       ");
        System.out.println("=========================");
        System.out.println("Store Name  : " + seller.getStoreName());
        System.out.println("Total Sales : " + seller.getTotalSales());
        System.out.println("Store Rating: " + seller.getRating());
        ArrayList<Product> myProducts = productController.getProductsBySeller(seller.getSellerId());
        System.out.println("Products    : " + myProducts.size());
        System.out.println("=========================");
    }

    private void handleManageInventory(Seller seller) {
        ArrayList<Product> myProducts = productController.getProductsBySeller(seller.getSellerId());
        if (myProducts.isEmpty()) {
            System.out.println("No products to manage.");
            return;
        }
        System.out.println("=========================");
        System.out.println("    Inventory Status     ");
        System.out.println("=========================");
        for (Product product : myProducts) {
            Inventory inventory = productController.getInventory(product.getProductId());
            if (inventory != null) {
                System.out.printf("%-20s | ID: %-5s | Stock: %d | Reserved: %d | Available: %d%n",
                        product.getName(), product.getProductId(),
                        inventory.getStockLevel(), inventory.getReservedStock(),
                        inventory.getAvailableStock());
            }
        }
        System.out.println("=========================");
        System.out.print("Enter Product ID to restock (or press Enter to skip): ");
        String productId = scanner.nextLine().trim();
        if (!productId.isEmpty()) {
            System.out.print("Enter quantity to add: ");
            int quantity = readInt();
            if (quantity > 0) {
                productController.updateStock(productId, quantity);
            }
        }
    }

    private void handleViewOrders() {
        ArrayList<Order> allOrders = orderController.listAllOrders();
        if (allOrders.isEmpty()) {
            System.out.println("No orders have been placed yet.");
            return;
        }
        System.out.println("=========================");
        System.out.println("        All Orders       ");
        System.out.println("=========================");
        for (Order order : allOrders) {
            System.out.println("Order ID : " + order.getOrderId()
                    + " | Status: " + order.getStatus()
                    + " | Total: $" + String.format("%.2f", order.getTotalAmount()));
        }
        System.out.println("=========================");
    }

    private int readInt() {
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException exception) {
            return -1;
        } catch (NoSuchElementException exception) {
            return 8;
        }
    }

    private double readDouble() {
        try {
            return Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException exception) {
            return -1.0;
        } catch (NoSuchElementException exception) {
            return -1.0;
        }
    }
}
