package voguecart.controller;

import voguecart.model.Cart;
import voguecart.model.CartItem;
import voguecart.model.Product;

import java.util.ArrayList;

public class CartController {

    private ArrayList<Cart> carts;
    private int cartIdCounter;
    private int cartItemIdCounter;

    public CartController() {
        this.carts = new ArrayList<>();
        this.cartIdCounter = 1;
        this.cartItemIdCounter = 1;
    }

    public boolean addToCart(String customerId, Product product,
                              int quantity, String selectedSize, String selectedColor) {
        Cart cart = getOrCreateCart(customerId);
        String cartItemId = "CI" + cartItemIdCounter++;
        double unitPrice = product.getEffectivePrice();
        CartItem item = new CartItem(cartItemId, product.getProductId(),
                product.getName(), quantity, unitPrice, selectedSize, selectedColor);
        cart.addItem(item);
        return true;
    }

    public boolean updateCart(String customerId, String cartItemId, int newQuantity) {
        Cart cart = findCartByCustomerId(customerId);
        if (cart == null) {
            System.out.println("✗ Cart not found!");
            return false;
        }
        return cart.updateQuantity(cartItemId, newQuantity);
    }

    public boolean removeFromCart(String customerId, String cartItemId) {
        Cart cart = findCartByCustomerId(customerId);
        if (cart == null) {
            System.out.println("✗ Cart not found!");
            return false;
        }
        return cart.removeItem(cartItemId);
    }

    public Cart getCart(String customerId) {
        Cart cart = findCartByCustomerId(customerId);
        if (cart == null) {
            System.out.println("Cart is empty.");
        }
        return cart;
    }

    public void clearCart(String customerId) {
        Cart cart = findCartByCustomerId(customerId);
        if (cart != null) {
            cart.clearCart();
        }
    }

    public Cart getOrCreateCart(String customerId) {
        Cart cart = findCartByCustomerId(customerId);
        if (cart == null) {
            String cartId = "CART" + cartIdCounter++;
            cart = new Cart(cartId, customerId);
            carts.add(cart);
        }
        return cart;
    }

    private Cart findCartByCustomerId(String customerId) {
        for (Cart cart : carts) {
            if (cart.getCustomerId().equals(customerId)) {
                return cart;
            }
        }
        return null;
    }
}
