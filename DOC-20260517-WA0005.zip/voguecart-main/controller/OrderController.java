package voguecart.controller;

import voguecart.model.Cart;
import voguecart.model.CartItem;
import voguecart.model.Order;
import voguecart.model.OrderItem;

import java.util.ArrayList;

public class OrderController {

    private ArrayList<Order> orders;
    private int orderIdCounter;
    private int orderItemIdCounter;

    public OrderController() {
        this.orders = new ArrayList<>();
        this.orderIdCounter = 1;
        this.orderItemIdCounter = 1;
    }

    public Order placeOrder(String customerId, Cart cart, double shippingCost) {
        if (cart == null || cart.isEmpty()) {
            System.out.println("✗ Cannot place order — cart is empty!");
            return null;
        }
        String orderId = "ORD" + orderIdCounter++;
        Order order = new Order(orderId, customerId, shippingCost);

        for (CartItem cartItem : cart.getItems()) {
            String orderItemId = "OI" + orderItemIdCounter++;
            OrderItem orderItem = new OrderItem(orderItemId, orderId,
                    cartItem.getProductId(), cartItem.getProductName(),
                    cartItem.getQuantity(), cartItem.getUnitPrice());
            order.addItem(orderItem);
        }

        order.placeOrder();
        orders.add(order);
        return order;
    }

    public Order getOrderDetails(String orderId) {
        Order order = findOrderById(orderId);
        if (order == null) {
            System.out.println("✗ Order not found!");
        }
        return order;
    }

    public boolean cancelOrder(String orderId) {
        Order order = findOrderById(orderId);
        if (order == null) {
            System.out.println("✗ Order not found!");
            return false;
        }
        return order.cancelOrder();
    }

    public boolean updateOrderStatus(String orderId, String newStatus) {
        Order order = findOrderById(orderId);
        if (order == null) {
            System.out.println("✗ Order not found!");
            return false;
        }
        order.updateStatus(newStatus);
        return true;
    }

    public ArrayList<Order> listOrders(String customerId) {
        ArrayList<Order> customerOrders = new ArrayList<>();
        for (Order order : orders) {
            if (order.getCustomerId().equals(customerId)) {
                customerOrders.add(order);
            }
        }
        return customerOrders;
    }

    public ArrayList<Order> listAllOrders() {
        return orders;
    }

    private Order findOrderById(String orderId) {
        for (Order order : orders) {
            if (order.getOrderId().equals(orderId)) {
                return order;
            }
        }
        return null;
    }
}
