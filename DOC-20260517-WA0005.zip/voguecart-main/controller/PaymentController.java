package voguecart.controller;

import voguecart.model.Payment;

import java.util.ArrayList;

public class PaymentController {

    private ArrayList<Payment> payments;
    private int paymentIdCounter;

    public PaymentController() {
        this.payments = new ArrayList<>();
        this.paymentIdCounter = 1;
    }

    public Payment processPayment(String orderId, String customerId,
                                   double amount, String method) {
        String paymentId = "PAY" + paymentIdCounter++;
        Payment payment = new Payment(paymentId, orderId, customerId, amount, method);
        boolean success = payment.processPayment();
        if (success) {
            payments.add(payment);
            return payment;
        }
        return null;
    }

    public Payment getPaymentDetails(String paymentId) {
        for (Payment payment : payments) {
            if (payment.getPaymentId().equals(paymentId)) {
                return payment;
            }
        }
        System.out.println("✗ Payment record not found!");
        return null;
    }

    public boolean refundPayment(String paymentId) {
        Payment payment = getPaymentDetails(paymentId);
        if (payment == null) return false;
        return payment.refundPayment();
    }

    public ArrayList<Payment> getTransactionHistory(String customerId) {
        ArrayList<Payment> history = new ArrayList<>();
        for (Payment payment : payments) {
            if (payment.getCustomerId().equals(customerId)) {
                history.add(payment);
            }
        }
        return history;
    }

    public ArrayList<Payment> getAllPayments() {
        return payments;
    }
}
