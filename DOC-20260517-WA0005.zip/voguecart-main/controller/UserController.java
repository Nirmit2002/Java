package voguecart.controller;

import voguecart.model.Admin;
import voguecart.model.Customer;
import voguecart.model.Notification;
import voguecart.model.Seller;
import voguecart.model.User;

import java.util.ArrayList;

public class UserController {

    private ArrayList<User> users;
    private ArrayList<Notification> notifications;
    private int userIdCounter;
    private int notificationIdCounter;

    public UserController() {
        this.users = new ArrayList<>();
        this.notifications = new ArrayList<>();
        this.userIdCounter = 1;
        this.notificationIdCounter = 1;
    }

    public Customer register(String name, String email, String password, String phone) {
        if (findUserByEmail(email) != null) {
            System.out.println("✗ Email already registered!");
            return null;
        }
        String userId = "U" + userIdCounter;
        String customerId = "C" + userIdCounter;
        userIdCounter++;
        Customer customer = new Customer(userId, customerId, name, email, password, phone);
        users.add(customer);
        System.out.println("✓ Registration successful! Welcome, " + name + "!");
        return customer;
    }

    public Seller registerSeller(String name, String email, String password,
                                  String phone, String storeName) {
        if (findUserByEmail(email) != null) {
            System.out.println("✗ Email already registered!");
            return null;
        }
        String userId = "U" + userIdCounter;
        String sellerId = "S" + userIdCounter;
        userIdCounter++;
        Seller seller = new Seller(userId, sellerId, name, email, password, phone, storeName);
        users.add(seller);
        System.out.println("✓ Seller registration successful! Welcome, " + name + "!");
        return seller;
    }

    public User login(String email, String password) {
        User foundUser = findUserByEmail(email);
        if (foundUser == null) {
            System.out.println("✗ No account found with that email!");
            return null;
        }
        boolean success = false;
        if (foundUser instanceof Customer) {
            success = ((Customer) foundUser).login(email, password);
        } else if (foundUser instanceof Seller) {
            success = ((Seller) foundUser).login(email, password);
        } else if (foundUser instanceof Admin) {
            success = ((Admin) foundUser).login(email, password);
        }
        return success ? foundUser : null;
    }

    public void logout(User user) {
        if (user instanceof Customer) {
            ((Customer) user).logout();
        } else if (user instanceof Seller) {
            ((Seller) user).logout();
        } else if (user instanceof Admin) {
            ((Admin) user).logout();
        }
    }

    public void updateProfile(User user, String name, String phone) {
        user.updateProfile(name, phone);
    }

    public User getUserDetails(String userId) {
        for (User user : users) {
            if (user.getUserId().equals(userId)) {
                return user;
            }
        }
        System.out.println("✗ User not found!");
        return null;
    }

    public void listUsers() {
        if (users.isEmpty()) {
            System.out.println("No users registered.");
            return;
        }
        System.out.println("=========================");
        System.out.println("  All Registered Users   ");
        System.out.println("=========================");
        int index = 1;
        for (User user : users) {
            System.out.println(index + ". [" + user.getRole() + "] "
                    + user.getName() + " | " + user.getEmail()
                    + " | ID: " + user.getUserId());
            index++;
        }
        System.out.println("=========================");
    }

    public void sendNotification(String userId, String message, String type) {
        String notifId = "N" + notificationIdCounter++;
        Notification notification = new Notification(notifId, userId, message, type, "");
        notifications.add(notification);
        notification.sendNotification();
    }

    public void addUser(User user) {
        users.add(user);
        try {
            int seededId = Integer.parseInt(user.getUserId().replace("U", ""));
            if (seededId >= userIdCounter) {
                userIdCounter = seededId + 1;
            }
        } catch (NumberFormatException ignored) {}
    }

    public ArrayList<User> getAllUsers() {
        return users;
    }

    public ArrayList<Notification> getAllNotifications() {
        return notifications;
    }

    private User findUserByEmail(String email) {
        for (User user : users) {
            if (user.getEmail().equalsIgnoreCase(email)) {
                return user;
            }
        }
        return null;
    }
}
