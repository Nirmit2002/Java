package voguecart.controller;

import voguecart.model.Inventory;
import voguecart.model.Product;

import java.util.ArrayList;

public class ProductController {

    private ArrayList<Product> products;
    private ArrayList<Inventory> inventories;
    private int productIdCounter;
    private int inventoryIdCounter;

    public ProductController() {
        this.products = new ArrayList<>();
        this.inventories = new ArrayList<>();
        this.productIdCounter = 1;
        this.inventoryIdCounter = 1;
    }

    public Product addProduct(String name, String description, double price,
                               String categoryId, String sellerId, String brand,
                               ArrayList<String> sizes, ArrayList<String> colors,
                               int initialStock) {
        String productId = "P" + productIdCounter++;
        Product product = new Product(productId, name, description, price, categoryId, sellerId, brand);
        product.setSizes(sizes);
        product.setColors(colors);
        products.add(product);

        String inventoryId = "INV" + inventoryIdCounter++;
        Inventory inventory = new Inventory(inventoryId, productId, initialStock, "Warehouse-A", 5);
        inventories.add(inventory);

        System.out.println("✓ Product added successfully! ID: " + productId);
        return product;
    }

    public boolean updateProduct(String productId, String name, String description, double price) {
        Product product = findProductById(productId);
        if (product == null) {
            System.out.println("✗ Product not found!");
            return false;
        }
        product.setName(name);
        product.setDescription(description);
        product.setPrice(price);
        System.out.println("✓ Product updated successfully!");
        return true;
    }

    public boolean deleteProduct(String productId) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getProductId().equals(productId)) {
                products.remove(i);
                System.out.println("✓ Product deleted successfully!");
                return true;
            }
        }
        System.out.println("✗ Product not found!");
        return false;
    }

    public ArrayList<Product> searchProduct(String keyword) {
        ArrayList<Product> results = new ArrayList<>();
        String lower = keyword.toLowerCase();
        for (Product product : products) {
            if (product.getName().toLowerCase().contains(lower)
                    || product.getBrand().toLowerCase().contains(lower)
                    || product.getDescription().toLowerCase().contains(lower)) {
                results.add(product);
            }
        }
        return results;
    }

    public ArrayList<Product> listProducts() {
        return products;
    }

    public Product getProductDetails(String productId) {
        Product product = findProductById(productId);
        if (product == null) {
            System.out.println("✗ Product not found!");
        }
        return product;
    }

    public Inventory getInventory(String productId) {
        for (Inventory inventory : inventories) {
            if (inventory.getProductId().equals(productId)) {
                return inventory;
            }
        }
        return null;
    }

    public void updateStock(String productId, int delta) {
        Inventory inventory = getInventory(productId);
        if (inventory != null) {
            inventory.updateStock(delta);
        } else {
            System.out.println("✗ Inventory record not found for product: " + productId);
        }
    }

    public ArrayList<Product> getProductsBySeller(String sellerId) {
        ArrayList<Product> sellerProducts = new ArrayList<>();
        for (Product product : products) {
            if (product.getSellerId().equals(sellerId)) {
                sellerProducts.add(product);
            }
        }
        return sellerProducts;
    }

    public void addProductDirect(Product product) {
        products.add(product);
        try {
            int seededId = Integer.parseInt(product.getProductId().replace("P", ""));
            if (seededId >= productIdCounter) {
                productIdCounter = seededId + 1;
            }
        } catch (NumberFormatException ignored) {}
    }

    public void addInventoryDirect(Inventory inventory) {
        inventories.add(inventory);
        try {
            int seededId = Integer.parseInt(inventory.getInventoryId().replace("INV", ""));
            if (seededId >= inventoryIdCounter) {
                inventoryIdCounter = seededId + 1;
            }
        } catch (NumberFormatException ignored) {}
    }

    public ArrayList<Inventory> getAllInventories() {
        return inventories;
    }

    private Product findProductById(String productId) {
        for (Product product : products) {
            if (product.getProductId().equals(productId)) {
                return product;
            }
        }
        return null;
    }
}
