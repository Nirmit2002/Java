// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

import controller.OrderController;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

// Customer can browse products, manage their cart, and place orders
public class Customer extends User {

    private String shippingAddress;
    private int loyaltyPoints;

    public Customer(String userId, String username, String name, String email,
                    String password, String phoneNumber, String shippingAddress) {
        super(userId, username, name, email, password, phoneNumber, "CUSTOMER");
        this.shippingAddress = shippingAddress;
        this.loyaltyPoints = 0;
    }

    @Override
    public void login() {
        System.out.println("Customer logged in successfully! Welcome, " + getName() + "!");
    }

    public void browseProducts(List<Product> products) {
        if (products.isEmpty()) {
            System.out.println("No products available right now.");
            return;
        }
        System.out.println("\n=================== All Products ===================");
        System.out.printf("%-4s %-25s %-18s %-6s %-9s %-5s%n",
            "No.", "Name", "Brand", "Size", "Price", "Stock");
        System.out.println("-----------------------------------------------------");
        int num = 1;
        for (Product p : products) {
            System.out.printf("%-4d %-25s %-18s %-6s $%-8.2f %-5d%n",
                num++, p.getName(), p.getBrand(), p.getSize(),
                p.getPrice(), p.getStockQuantity());
        }
        System.out.println("=====================================================");
    }

    public void searchProduct(List<Product> products, String keyword) {
        List<Product> results = new ArrayList<>();
        String lower = keyword.toLowerCase();

        for (Product p : products) {
            if (p.getName().toLowerCase().contains(lower) ||
                p.getCategory().toLowerCase().contains(lower)) {
                results.add(p);
            }
        }

        if (results.isEmpty()) {
            System.out.println("No products found for: \"" + keyword + "\"");
        } else {
            System.out.println("\nSearch results for \"" + keyword + "\":");
            browseProducts(results);
        }
    }

    public void addToCart(Cart cart, Product product, int quantity) {
        if (product.getStockQuantity() == 0) {
            System.out.println("Sorry, this product is out of stock.");
            return;
        }
        if (product.getStockQuantity() < quantity) {
            System.out.println("Sorry, only " + product.getStockQuantity() + " unit(s) available.");
            return;
        }
        cart.addItem(product, quantity);
        System.out.println("Added " + product.getName() + " to cart!");
    }

    public void placeOrder(Cart cart, OrderController orderController) {
        if (cart.isEmpty()) {
            System.out.println("Your cart is empty!");
            return;
        }
        Order order = new Order(getUsername(), getName(),
            new ArrayList<>(cart.getCartItems()), shippingAddress);
        orderController.placeOrder(order);
        cart.clearCart();

        System.out.println("\n=== Order Placed Successfully! ===");
        System.out.println("Order ID : " + order.getOrderId());
        System.out.printf("Total    : $%.2f%n", order.getTotalAmount());
        System.out.println("Status   : " + order.getStatus());
        System.out.println("Your order is being processed. Thank you!");
    }

    public void cancelOrder(List<Order> orders, String orderId) {
        for (Order o : orders) {
            if (o.getOrderId().equals(orderId) &&
                o.getCustomerUsername().equals(getUsername())) {
                o.updateStatus("Cancelled");
                System.out.println("Order " + orderId + " has been cancelled.");
                return;
            }
        }
        System.out.println("Order not found or you don't have permission to cancel it.");
    }

    public void writeReview(Product product, int rating, String comment) {
        Review review = new Review(getUsername(), product.getName(), rating, comment);
        review.displayReview();
    }

    public void viewOrderHistory(List<Order> orders) {
        System.out.println("\n========== Your Order History ==========");
        boolean found = false;
        for (Order o : orders) {
            if (o.getCustomerUsername().equals(getUsername())) {
                System.out.println(o.getOrderDetails());
                found = true;
            }
        }
        if (!found) {
            System.out.println("You haven't placed any orders yet.");
        }
        System.out.println("=========================================");
    }

    // picks 3 random products to show as recommendations
    public void viewRecommendations(List<Product> products) {
        if (products.isEmpty()) {
            System.out.println("No products available for recommendations.");
            return;
        }
        System.out.println("\n===== Recommended For You =====");
        Random random = new Random();
        List<Product> copy = new ArrayList<>(products);
        int count = Math.min(3, copy.size());

        for (int i = 0; i < count; i++) {
            int idx = random.nextInt(copy.size());
            Product p = copy.remove(idx);
            System.out.printf("%d. %s by %s - $%.2f%n",
                i + 1, p.getName(), p.getBrand(), p.getPrice());
        }
        System.out.println("================================");
    }

    public String getShippingAddress() { return shippingAddress; }
    public void setShippingAddress(String shippingAddress) { this.shippingAddress = shippingAddress; }

    public int getLoyaltyPoints() { return loyaltyPoints; }
    public void setLoyaltyPoints(int loyaltyPoints) { this.loyaltyPoints = loyaltyPoints; }
}
