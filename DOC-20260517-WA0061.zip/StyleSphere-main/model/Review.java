// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

import java.time.LocalDate;

public class Review {

    private static int counter = 1;

    private String reviewId;
    private String customerUsername;
    private String productName;
    private int rating; // 1 to 5
    private String comment;
    private String reviewDate;

    public Review(String customerUsername, String productName, int rating, String comment) {
        this.reviewId = "REV-" + String.format("%03d", counter++);
        this.customerUsername = customerUsername;
        this.productName = productName;
        this.rating = rating;
        this.comment = comment;
        this.reviewDate = LocalDate.now().toString();
    }

    // builds the star display e.g. ★★★★☆ for rating 4
    private String getStars() {
        String stars = "";
        for (int i = 1; i <= 5; i++) {
            if (i <= rating) {
                stars += "★";
            } else {
                stars += "☆";
            }
        }
        return stars;
    }

    public void displayReview() {
        System.out.println("\n--- Review Submitted ---");
        System.out.println("Review ID : " + reviewId);
        System.out.println("Product   : " + productName);
        System.out.println("By        : " + customerUsername);
        System.out.println("Rating    : " + getStars() + " (" + rating + "/5)");
        System.out.println("Comment   : " + comment);
        System.out.println("Date      : " + reviewDate);
        System.out.println("------------------------");
    }

    public String getReviewId() { return reviewId; }
    public void setReviewId(String reviewId) { this.reviewId = reviewId; }

    public String getCustomerUsername() { return customerUsername; }
    public void setCustomerUsername(String customerUsername) { this.customerUsername = customerUsername; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public String getReviewDate() { return reviewDate; }
    public void setReviewDate(String reviewDate) { this.reviewDate = reviewDate; }
}
