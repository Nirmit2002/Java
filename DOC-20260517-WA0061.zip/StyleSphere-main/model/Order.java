// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Order {

    private static int counter = 1;

    private String orderId;
    private String customerUsername;
    private String customerName;
    private ArrayList<CartItem> items;
    private String orderDate;
    private String status;
    private double totalAmount;
    private String shippingAddress;

    public Order(String customerUsername, String customerName,
                 List<CartItem> cartItems, String shippingAddress) {
        this.orderId = "ORD-" + String.format("%03d", counter++);
        this.customerUsername = customerUsername;
        this.customerName = customerName;
        this.shippingAddress = shippingAddress;
        this.orderDate = LocalDate.now().toString();
        this.status = "Processing";

        this.items = new ArrayList<>();
        for (CartItem item : cartItems) {
            this.items.add(item);
        }

        this.totalAmount = 0;
        for (CartItem item : this.items) {
            this.totalAmount += item.getSubtotal();
        }
    }

    public String getOrderDetails() {
        String details = "\n----- Order Details -----\n";
        details += "Order ID    : " + orderId + "\n";
        details += "Customer    : " + customerName + "\n";
        details += "Date        : " + orderDate + "\n";
        details += "Status      : " + status + "\n";
        details += "Ship To     : " + shippingAddress + "\n";
        details += "Items:\n";
        for (CartItem item : items) {
            details += String.format("  - %-25s x%d @ $%.2f = $%.2f%n",
                item.getProduct().getName(), item.getQuantity(),
                item.getPrice(), item.getSubtotal());
        }
        details += String.format("Total       : $%.2f%n", totalAmount);
        details += "-------------------------";
        return details;
    }

    public void updateStatus(String status) {
        this.status = status;
        System.out.println("Order " + orderId + " status updated to: " + status);
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getCustomerUsername() { return customerUsername; }
    public void setCustomerUsername(String customerUsername) { this.customerUsername = customerUsername; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public ArrayList<CartItem> getItems() { return items; }
    public void setItems(ArrayList<CartItem> items) { this.items = items; }

    public String getOrderDate() { return orderDate; }
    public void setOrderDate(String orderDate) { this.orderDate = orderDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public String getShippingAddress() { return shippingAddress; }
    public void setShippingAddress(String shippingAddress) { this.shippingAddress = shippingAddress; }
}
