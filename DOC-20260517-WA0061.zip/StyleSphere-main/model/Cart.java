// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

import java.util.ArrayList;

public class Cart {

    private static int counter = 1;

    private String cartId;
    private String customerUsername;
    private ArrayList<CartItem> cartItems;

    public Cart(String customerUsername) {
        this.cartId = "CART-" + String.format("%03d", counter++);
        this.customerUsername = customerUsername;
        this.cartItems = new ArrayList<>();
    }

    public void addItem(Product product, int quantity) {
        CartItem item = new CartItem(product, quantity);
        cartItems.add(item);
        // reduce stock right away so it reflects availability for other customers
        product.setStockQuantity(product.getStockQuantity() - quantity);
    }

    public void removeItem(String productId) {
        CartItem toRemove = null;
        for (CartItem item : cartItems) {
            if (item.getProduct().getProductId().equals(productId)) {
                toRemove = item;
                break;
            }
        }
        if (toRemove != null) {
            // put the stock back since the customer no longer wants it
            toRemove.getProduct().setStockQuantity(
                toRemove.getProduct().getStockQuantity() + toRemove.getQuantity()
            );
            cartItems.remove(toRemove);
            System.out.println("Item removed from cart.");
        } else {
            System.out.println("Item not found in cart.");
        }
    }

    public double getTotal() {
        double total = 0;
        for (CartItem item : cartItems) {
            total += item.getSubtotal();
        }
        return total;
    }

    // clears the cart after order is placed - we do NOT restore stock here
    // because the order is confirmed so the stock is actually sold
    public void clearCart() {
        cartItems.clear();
    }

    public void displayCart() {
        if (cartItems.isEmpty()) {
            System.out.println("Your cart is empty!");
            return;
        }
        System.out.println("\n========== Your Cart ==========");
        for (CartItem item : cartItems) {
            item.displayItem();
        }
        System.out.println("--------------------------------");
        System.out.printf("  Grand Total: $%.2f%n", getTotal());
        System.out.println("================================");
    }

    public boolean isEmpty() {
        return cartItems.isEmpty();
    }

    public String getCartId() { return cartId; }
    public void setCartId(String cartId) { this.cartId = cartId; }

    public String getCustomerUsername() { return customerUsername; }
    public void setCustomerUsername(String customerUsername) { this.customerUsername = customerUsername; }

    public ArrayList<CartItem> getCartItems() { return cartItems; }
    public void setCartItems(ArrayList<CartItem> cartItems) { this.cartItems = cartItems; }
}
