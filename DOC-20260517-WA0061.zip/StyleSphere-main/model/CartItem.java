// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

// one line item inside a cart (product + how many the customer wants)
public class CartItem {

    private static int counter = 1;

    private String cartItemId;
    private Product product;
    private int quantity;
    private double price; // we store the price at the time of adding so it doesnt change later

    public CartItem(Product product, int quantity) {
        this.cartItemId = "ITEM-" + String.format("%03d", counter++);
        this.product = product;
        this.quantity = quantity;
        this.price = product.getPrice();
    }

    public double getSubtotal() {
        return quantity * price;
    }

    public void displayItem() {
        System.out.printf("  %-25s x%-3d @ $%-8.2f = $%.2f%n",
            product.getName(), quantity, price, getSubtotal());
    }

    public String getCartItemId() { return cartItemId; }
    public void setCartItemId(String cartItemId) { this.cartItemId = cartItemId; }

    public Product getProduct() { return product; }
    public void setProduct(Product product) { this.product = product; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
}
