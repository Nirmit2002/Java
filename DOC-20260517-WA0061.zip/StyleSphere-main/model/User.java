// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

// base class for all users - customer, seller and admin all extend from here
public abstract class User {

    private String userId;
    private String username;
    private String name;
    private String email;
    private String password;
    private String phoneNumber;
    private String role;

    public User(String userId, String username, String name, String email,
                String password, String phoneNumber, String role) {
        this.userId = userId;
        this.username = username;
        this.name = name;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.role = role;
    }

    // every subclass needs to have their own login message
    public abstract void login();

    public void logout() {
        System.out.println("Goodbye " + name + "! You have been logged out.");
    }

    public void updateProfile() {
        System.out.println("Profile updated successfully for " + username + "!");
    }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
