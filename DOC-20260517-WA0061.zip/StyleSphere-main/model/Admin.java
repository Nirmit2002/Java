// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

import controller.AuthController;
import java.util.List;

public class Admin extends User {

    private int adminLevel;

    public Admin(String userId, String username, String name, String email,
                 String password, String phoneNumber, int adminLevel) {
        super(userId, username, name, email, password, phoneNumber, "ADMIN");
        this.adminLevel = adminLevel;
    }

    @Override
    public void login() {
        System.out.println("Admin logged in! Welcome, " + getName() + "!");
    }

    public void manageUsers(List<User> users) {
        System.out.println("\n========== All Registered Users ==========");
        System.out.printf("%-15s %-20s %-10s%n", "Username", "Name", "Role");
        System.out.println("-------------------------------------------");
        for (User u : users) {
            System.out.printf("%-15s %-20s %-10s%n",
                u.getUsername(), u.getName(), u.getRole());
        }
        System.out.println("===========================================");
    }

    public void approveSeller(AuthController ac, String username) {
        User user = ac.getUserByUsername(username);
        if (user instanceof Seller) {
            Seller seller = (Seller) user;
            seller.setApproved(true);
            System.out.println("Seller " + username + " has been approved!");
        } else if (user == null) {
            System.out.println("No user found with username: " + username);
        } else {
            System.out.println(username + " is not a seller account.");
        }
    }

    public void monitorTransactions(List<Order> orders) {
        System.out.println("\n========== All Transactions ==========");
        System.out.printf("%-12s %-15s %-9s %-12s%n",
            "Order ID", "Customer", "Total", "Status");
        System.out.println("----------------------------------------");
        if (orders.isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            for (Order o : orders) {
                System.out.printf("%-12s %-15s $%-8.2f %-12s%n",
                    o.getOrderId(), o.getCustomerName(),
                    o.getTotalAmount(), o.getStatus());
            }
        }
        System.out.println("========================================");
    }

    public void handleComplaints() {
        System.out.println("No active complaints at the moment.");
    }

    public void detectFraud() {
        System.out.println("System scan complete. No fraudulent activity detected.");
    }

    public int getAdminLevel() { return adminLevel; }
    public void setAdminLevel(int adminLevel) { this.adminLevel = adminLevel; }
}
