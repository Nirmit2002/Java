// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

public class Product {

    private String productId;
    private String name;
    private String description;
    private double price;
    private String category;
    private String brand;
    private String size;
    private int stockQuantity;
    private double rating;
    private String sellerId;

    public Product(String productId, String name, String description, double price,
                   String category, String brand, String size, int stockQuantity,
                   double rating, String sellerId) {
        this.productId = productId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.category = category;
        this.brand = brand;
        this.size = size;
        this.stockQuantity = stockQuantity;
        this.rating = rating;
        this.sellerId = sellerId;
    }

    public String getDetails() {
        return "ID: " + productId + " | " + name + " | Brand: " + brand +
               " | Size: " + size + " | Price: $" + String.format("%.2f", price) +
               " | Stock: " + stockQuantity + " | Rating: " + rating + "★ | " + description;
    }

    public void updateStock(int quantity) {
        this.stockQuantity += quantity;
    }

    // reduces price - percentage is like 10 for 10% off
    public void applyDiscount(double percentage) {
        this.price = this.price - (this.price * percentage / 100);
    }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public String getSize() { return size; }
    public void setSize(String size) { this.size = size; }

    public int getStockQuantity() { return stockQuantity; }
    public void setStockQuantity(int stockQuantity) { this.stockQuantity = stockQuantity; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    public String getSellerId() { return sellerId; }
    public void setSellerId(String sellerId) { this.sellerId = sellerId; }
}
