// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package model;

import controller.ProductController;
import java.util.List;
import java.util.Scanner;

// Seller can list their own products and track how they are selling
public class Seller extends User {

    private String businessName;
    private String bankDetails;
    private boolean isApproved;

    public Seller(String userId, String username, String name, String email,
                  String password, String phoneNumber, String businessName, boolean isApproved) {
        super(userId, username, name, email, password, phoneNumber, "SELLER");
        this.businessName = businessName;
        this.bankDetails = "";
        this.isApproved = isApproved;
    }

    @Override
    public void login() {
        System.out.println("Seller logged in! Welcome, " + businessName + "!");
    }

    // takes input from the seller and adds a new product to the system
    public void addProduct(ProductController pc, Scanner scanner) {
        System.out.println("\n--- Add New Product ---");
        System.out.print("Product Name     : ");
        String name = scanner.nextLine();
        System.out.print("Description      : ");
        String description = scanner.nextLine();
        System.out.print("Price ($)        : ");
        double price = 0;
        try {
            price = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid price. Setting to 0.00");
        }
        System.out.print("Category         : ");
        String category = scanner.nextLine();
        System.out.print("Brand            : ");
        String brand = scanner.nextLine();
        System.out.print("Size             : ");
        String size = scanner.nextLine();
        System.out.print("Stock Quantity   : ");
        int stock = 0;
        try {
            stock = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid quantity. Setting to 0");
        }

        String productId = pc.generateProductId();
        Product product = new Product(productId, name, description, price,
            category, brand, size, stock, 0.0, getUsername());
        pc.addProduct(product);
        System.out.println("\nProduct \"" + name + "\" added successfully! ID: " + productId);
    }

    public void removeProduct(ProductController pc, String productId) {
        Product product = pc.getProductById(productId);
        if (product != null && product.getSellerId().equals(getUsername())) {
            pc.removeProduct(productId);
            System.out.println("Product " + productId + " removed successfully.");
        } else {
            System.out.println("Product not found or you don't have permission to remove it.");
        }
    }

    public void viewInventory(ProductController pc) {
        List<Product> all = pc.getAllProducts();
        System.out.println("\n========== Your Inventory ==========");
        System.out.printf("%-10s %-25s %-12s %-9s %-6s%n",
            "ID", "Name", "Category", "Price", "Stock");
        System.out.println("---------------------------------------------");
        boolean found = false;
        for (Product p : all) {
            if (p.getSellerId().equals(getUsername())) {
                System.out.printf("%-10s %-25s %-12s $%-8.2f %-6d%n",
                    p.getProductId(), p.getName(), p.getCategory(),
                    p.getPrice(), p.getStockQuantity());
                found = true;
            }
        }
        if (!found) {
            System.out.println("You have no products listed yet.");
        }
        System.out.println("=============================================");
    }

    public void viewOrders(List<Order> orders) {
        System.out.println("\n===== Orders Containing Your Products =====");
        boolean found = false;
        for (Order o : orders) {
            for (CartItem item : o.getItems()) {
                if (item.getProduct().getSellerId().equals(getUsername())) {
                    System.out.printf("Order: %-10s | Customer: %-15s | Status: %-12s | Total: $%.2f%n",
                        o.getOrderId(), o.getCustomerName(), o.getStatus(), o.getTotalAmount());
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            System.out.println("No orders found for your products.");
        }
        System.out.println("===========================================");
    }

    public void viewSalesAnalytics(List<Order> orders) {
        int totalOrders = 0;
        double totalRevenue = 0;

        for (Order o : orders) {
            for (CartItem item : o.getItems()) {
                if (item.getProduct().getSellerId().equals(getUsername())) {
                    totalOrders++;
                    totalRevenue += o.getTotalAmount();
                    break;
                }
            }
        }

        System.out.println("\n===== Sales Analytics for " + businessName + " =====");
        System.out.println("Total Orders  : " + totalOrders);
        System.out.printf("Total Revenue : $%.2f%n", totalRevenue);
        System.out.println("================================================");
    }

    public String getBusinessName() { return businessName; }
    public void setBusinessName(String businessName) { this.businessName = businessName; }

    public String getBankDetails() { return bankDetails; }
    public void setBankDetails(String bankDetails) { this.bankDetails = bankDetails; }

    public boolean isApproved() { return isApproved; }
    public void setApproved(boolean approved) { isApproved = approved; }
}
