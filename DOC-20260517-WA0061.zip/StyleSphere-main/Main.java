// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

import controller.AuthController;
import controller.OrderController;
import controller.ProductController;
import model.Admin;
import model.Customer;
import model.Seller;
import model.User;
import view.AdminView;
import view.CustomerView;
import view.SellerView;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        // only one scanner created here and passed down to all views
        Scanner scanner = new Scanner(System.in);

        AuthController authController = new AuthController();
        ProductController productController = new ProductController();
        OrderController orderController = new OrderController();

        productController.loadSampleProducts();

        // pre-load admin account
        Admin admin = new Admin("USR-000", "sarahjones", "Sarah Jones",
            "sarah.jones@stylesphere.com", "sarah123", "08-9001-2345", 1);
        authController.registerUser(admin);

        // pre-load seller account (already approved so they can login right away)
        Seller seller1 = new Seller("USR-001", "mikebrown", "Michael Brown",
            "mike@trendwear.com.au", "mike123", "04-5678-9012",
            "TrendWear", true);
        authController.registerUser(seller1);

        boolean running = true;
        while (running) {
            printMainMenu();
            String input = scanner.nextLine().trim();
            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }

            switch (choice) {
                case 1:
                    handleLogin(scanner, authController, productController, orderController);
                    break;

                case 2:
                    handleRegisterCustomer(scanner, authController);
                    break;

                case 3:
                    handleRegisterSeller(scanner, authController);
                    break;

                case 0:
                    System.out.println("\nThank you for visiting StyleSphere! Goodbye! 👋");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice. Please enter 0, 1, 2, or 3.");
            }
        }

        scanner.close();
    }

    private static void printMainMenu() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║                                      ║");
        System.out.println("║   Welcome to StyleSphere! 👗         ║");
        System.out.println("║   Smart Fashion E-commerce Platform  ║");
        System.out.println("║                                      ║");
        System.out.println("╠══════════════════════════════════════╣");
        System.out.println("║   1. Login                           ║");
        System.out.println("║   2. Register as Customer            ║");
        System.out.println("║   3. Register as Seller              ║");
        System.out.println("║   0. Exit                            ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.print("Enter your choice: ");
    }

    private static void handleLogin(Scanner scanner, AuthController ac,
                                    ProductController pc, OrderController oc) {
        System.out.println("\n--- Login ---");
        System.out.print("Username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine().trim();

        User user = ac.loginUser(username, password);

        if (user == null) {
            System.out.println("Invalid username or password. Please try again.");
            return;
        }

        if (user instanceof Customer) {
            CustomerView cv = new CustomerView(scanner, (Customer) user, pc, oc);
            cv.showMenu();

        } else if (user instanceof Seller) {
            Seller seller = (Seller) user;
            // seller needs admin approval before they can access the dashboard
            if (!seller.isApproved()) {
                System.out.println("Your seller account is pending admin approval.");
                System.out.println("Please contact admin to get your account approved.");
                return;
            }
            SellerView sv = new SellerView(scanner, seller, pc, oc);
            sv.showMenu();

        } else if (user instanceof Admin) {
            AdminView av = new AdminView(scanner, (Admin) user, ac, oc);
            av.showMenu();
        }
    }

    private static void handleRegisterCustomer(Scanner scanner, AuthController ac) {
        System.out.println("\n--- Register as Customer ---");

        System.out.print("Choose a username  : ");
        String username = scanner.nextLine().trim();

        if (ac.userExists(username)) {
            System.out.println("Username already exists. Please choose another.");
            return;
        }

        System.out.print("Full name          : ");
        String name = scanner.nextLine();
        System.out.print("Email              : ");
        String email = scanner.nextLine();
        System.out.print("Password           : ");
        String password = scanner.nextLine();
        System.out.print("Phone number       : ");
        String phone = scanner.nextLine();
        System.out.print("Shipping address   : ");
        String address = scanner.nextLine();

        String userId = "USR-" + String.format("%03d", ac.getAllUsers().size() + 1);
        Customer customer = new Customer(userId, username, name, email,
            password, phone, address);
        ac.registerUser(customer);
        System.out.println("Registration successful! You can now login.");
    }

    private static void handleRegisterSeller(Scanner scanner, AuthController ac) {
        System.out.println("\n--- Register as Seller ---");

        System.out.print("Choose a username  : ");
        String username = scanner.nextLine().trim();

        if (ac.userExists(username)) {
            System.out.println("Username already exists. Please choose another.");
            return;
        }

        System.out.print("Full name          : ");
        String name = scanner.nextLine();
        System.out.print("Email              : ");
        String email = scanner.nextLine();
        System.out.print("Password           : ");
        String password = scanner.nextLine();
        System.out.print("Phone number       : ");
        String phone = scanner.nextLine();
        System.out.print("Business name      : ");
        String businessName = scanner.nextLine();

        // new sellers start unapproved - admin has to approve them first
        String userId = "USR-" + String.format("%03d", ac.getAllUsers().size() + 1);
        Seller seller = new Seller(userId, username, name, email,
            password, phone, businessName, false);
        ac.registerUser(seller);
        System.out.println("Registration submitted! Please wait for admin approval.");
    }
}
