// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package view;

import controller.OrderController;
import controller.ProductController;
import model.Seller;

import java.util.Scanner;

public class SellerView {

    private Scanner scanner;
    private Seller seller;
    private ProductController pc;
    private OrderController oc;

    public SellerView(Scanner scanner, Seller seller,
                      ProductController pc, OrderController oc) {
        this.scanner = scanner;
        this.seller = seller;
        this.pc = pc;
        this.oc = oc;
    }

    private void printMenu() {
        System.out.println("\n╔════════════════════════════════╗");
        System.out.println("║   Welcome " + seller.getBusinessName() + "! 🛍️");
        System.out.println("║   StyleSphere Seller Dashboard ║");
        System.out.println("╠════════════════════════════════╣");
        System.out.println("║  1. Add New Product            ║");
        System.out.println("║  2. View My Inventory          ║");
        System.out.println("║  3. Remove a Product           ║");
        System.out.println("║  4. View Customer Orders       ║");
        System.out.println("║  5. View Sales Analytics       ║");
        System.out.println("║  0. Logout                     ║");
        System.out.println("╚════════════════════════════════╝");
        System.out.print("Enter your choice: ");
    }

    public void showMenu() {
        seller.login();
        int choice = -1;

        while (choice != 0) {
            printMenu();
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }

            switch (choice) {
                case 1:
                    seller.addProduct(pc, scanner);
                    break;

                case 2:
                    seller.viewInventory(pc);
                    break;

                case 3:
                    handleRemoveProduct();
                    break;

                case 4:
                    seller.viewOrders(oc.getAllOrders());
                    break;

                case 5:
                    seller.viewSalesAnalytics(oc.getAllOrders());
                    break;

                case 0:
                    seller.logout();
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void handleRemoveProduct() {
        seller.viewInventory(pc);
        System.out.print("Enter Product ID to remove (e.g. PRD-001): ");
        String productId = scanner.nextLine().trim();
        seller.removeProduct(pc, productId);
    }
}
