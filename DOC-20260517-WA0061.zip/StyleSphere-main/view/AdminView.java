// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package view;

import controller.AuthController;
import controller.OrderController;
import model.Admin;

import java.util.Scanner;

public class AdminView {

    private Scanner scanner;
    private Admin admin;
    private AuthController ac;
    private OrderController oc;

    public AdminView(Scanner scanner, Admin admin,
                     AuthController ac, OrderController oc) {
        this.scanner = scanner;
        this.admin = admin;
        this.ac = ac;
        this.oc = oc;
    }

    private void printMenu() {
        System.out.println("\n╔════════════════════════════════╗");
        System.out.println("║   StyleSphere Admin Panel 🔧   ║");
        System.out.println("║   Welcome " + admin.getName() + "!              ║");
        System.out.println("╠════════════════════════════════╣");
        System.out.println("║  1. View All Users             ║");
        System.out.println("║  2. Approve Seller Account     ║");
        System.out.println("║  3. Monitor All Transactions   ║");
        System.out.println("║  4. Handle Complaints          ║");
        System.out.println("║  5. Detect Fraud Activity      ║");
        System.out.println("║  0. Logout                     ║");
        System.out.println("╚════════════════════════════════╝");
        System.out.print("Enter your choice: ");
    }

    public void showMenu() {
        admin.login();
        int choice = -1;

        while (choice != 0) {
            printMenu();
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }

            switch (choice) {
                case 1:
                    admin.manageUsers(ac.getAllUsers());
                    break;

                case 2:
                    System.out.print("Enter seller's username to approve: ");
                    String username = scanner.nextLine().trim();
                    admin.approveSeller(ac, username);
                    break;

                case 3:
                    admin.monitorTransactions(oc.getAllOrders());
                    break;

                case 4:
                    admin.handleComplaints();
                    break;

                case 5:
                    admin.detectFraud();
                    break;

                case 0:
                    admin.logout();
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
