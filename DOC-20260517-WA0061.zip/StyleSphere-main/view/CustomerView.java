// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package view;

import controller.OrderController;
import controller.ProductController;
import model.Cart;
import model.Customer;
import model.Product;

import java.util.List;
import java.util.Scanner;

public class CustomerView {

    private Scanner scanner;
    private Customer customer;
    private ProductController pc;
    private OrderController oc;
    private Cart cart;

    public CustomerView(Scanner scanner, Customer customer,
                        ProductController pc, OrderController oc) {
        this.scanner = scanner;
        this.customer = customer;
        this.pc = pc;
        this.oc = oc;
        this.cart = new Cart(customer.getUsername());
    }

    private void printMenu() {
        System.out.println("\n╔════════════════════════════════╗");
        System.out.println("║   Welcome " + customer.getName() + "! 👗");
        System.out.println("║   StyleSphere Customer Menu    ║");
        System.out.println("╠════════════════════════════════╣");
        System.out.println("║  1. Browse All Products        ║");
        System.out.println("║  2. Search Products            ║");
        System.out.println("║  3. Add Product to Cart        ║");
        System.out.println("║  4. View My Cart               ║");
        System.out.println("║  5. Place Order                ║");
        System.out.println("║  6. View Order History         ║");
        System.out.println("║  7. Cancel an Order            ║");
        System.out.println("║  8. Write a Review             ║");
        System.out.println("║  9. View Recommendations       ║");
        System.out.println("║  0. Logout                     ║");
        System.out.println("╚════════════════════════════════╝");
        System.out.print("Enter your choice: ");
    }

    public void showMenu() {
        customer.login();
        int choice = -1;

        while (choice != 0) {
            printMenu();
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }

            switch (choice) {
                case 1:
                    customer.browseProducts(pc.getAllProducts());
                    break;

                case 2:
                    System.out.print("Enter search keyword: ");
                    String keyword = scanner.nextLine();
                    customer.searchProduct(pc.getAllProducts(), keyword);
                    break;

                case 3:
                    handleAddToCart();
                    break;

                case 4:
                    cart.displayCart();
                    break;

                case 5:
                    customer.placeOrder(cart, oc);
                    break;

                case 6:
                    customer.viewOrderHistory(oc.getAllOrders());
                    break;

                case 7:
                    handleCancelOrder();
                    break;

                case 8:
                    handleWriteReview();
                    break;

                case 9:
                    customer.viewRecommendations(pc.getAllProducts());
                    break;

                case 0:
                    customer.logout();
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void handleAddToCart() {
        List<Product> products = pc.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("No products available.");
            return;
        }
        customer.browseProducts(products);
        System.out.print("Enter product number to add to cart (0 to cancel): ");
        try {
            int productNum = Integer.parseInt(scanner.nextLine().trim());
            if (productNum == 0) return;
            if (productNum < 1 || productNum > products.size()) {
                System.out.println("Invalid product number.");
                return;
            }
            Product selected = products.get(productNum - 1);
            System.out.print("Enter quantity: ");
            int quantity = Integer.parseInt(scanner.nextLine().trim());
            if (quantity <= 0) {
                System.out.println("Quantity must be at least 1.");
                return;
            }
            customer.addToCart(cart, selected, quantity);
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
        }
    }

    private void handleCancelOrder() {
        customer.viewOrderHistory(oc.getAllOrders());
        System.out.print("Enter Order ID to cancel (e.g. ORD-001): ");
        String orderId = scanner.nextLine().trim();
        customer.cancelOrder(oc.getAllOrders(), orderId);
    }

    private void handleWriteReview() {
        List<Product> products = pc.getAllProducts();
        if (products.isEmpty()) {
            System.out.println("No products available to review.");
            return;
        }
        customer.browseProducts(products);
        System.out.print("Enter product number to review (0 to cancel): ");
        try {
            int productNum = Integer.parseInt(scanner.nextLine().trim());
            if (productNum == 0) return;
            if (productNum < 1 || productNum > products.size()) {
                System.out.println("Invalid product number.");
                return;
            }
            Product selected = products.get(productNum - 1);
            System.out.print("Enter rating (1-5): ");
            int rating = Integer.parseInt(scanner.nextLine().trim());
            if (rating < 1 || rating > 5) {
                System.out.println("Rating must be between 1 and 5.");
                return;
            }
            System.out.print("Enter your comment: ");
            String comment = scanner.nextLine();
            customer.writeReview(selected, rating, comment);
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid number.");
        }
    }
}
