================================================================================
  StyleSphere - How to Compile and Run
  ICT 602 - Software Engineering, Semester 1 2026
  Group 17 Adelaide
================================================================================

REQUIREMENTS:
  - Java JDK 8 or higher installed on your computer
  - A terminal / command prompt

--------------------------------------------------------------------------------
HOW TO COMPILE:

  Step 1: Open your terminal (Command Prompt, PowerShell, or any terminal)

  Step 2: Navigate to the StyleSphere folder
          Example:
            cd path/to/StyleSphere

  Step 3: Run this compile command (compiles all source files at once):
            javac -d . model/*.java controller/*.java view/*.java Main.java

          If successful, you will see .class files created inside the folders.

  Step 4: Run the program:
            java Main

--------------------------------------------------------------------------------
TEST CREDENTIALS (Pre-loaded Accounts):

  Admin Account:
    Username : sarahjones
    Password : sarah123

  Seller Account (Pre-approved):
    Username : mikebrown
    Password : mike123

  Customer Account:
    Register a new account from the main menu (Option 2)

--------------------------------------------------------------------------------
FEATURES TO DEMO FOR ASSIGNMENT:

  1. Admin Login
     - Login as admin (sarahjones / sarah123)
     - Go to "View All Users" to see registered accounts
     - Register a new seller first, then use "Approve Seller Account"

  2. Customer Registration and Shopping
     - Register a new customer from the main menu
     - Login and browse all 8 pre-loaded products
     - Search for products by name or category
     - Add products to cart and view cart
     - Place an order and view order history
     - Write a product review

  3. Seller Dashboard
     - Login as seller (mikebrown / mike123)
     - View your product inventory
     - Add a new product to the catalogue
     - View orders containing your products
     - Check sales analytics

  4. Full Flow Demo
     a. Register a new seller -> Login as admin -> Approve the seller
     b. Login as new seller -> Add products
     c. Register as customer -> Browse -> Add to cart -> Place order
     d. Login as seller -> Check orders and analytics

--------------------------------------------------------------------------------
PROJECT STRUCTURE:

  StyleSphere/
  ├── model/
  │   ├── User.java          - Abstract base class for all users
  │   ├── Customer.java      - Customer user type
  │   ├── Seller.java        - Seller user type
  │   ├── Admin.java         - Admin user type
  │   ├── Product.java       - Product listing
  │   ├── CartItem.java      - Single item in a cart
  │   ├── Cart.java          - Shopping cart
  │   ├── Order.java         - Confirmed purchase order
  │   └── Review.java        - Product review
  ├── controller/
  │   ├── AuthController.java    - Login and registration logic
  │   ├── ProductController.java - Product catalogue management
  │   └── OrderController.java   - Order management
  ├── view/
  │   ├── CustomerView.java  - Customer menu and UI
  │   ├── SellerView.java    - Seller dashboard UI
  │   └── AdminView.java     - Admin panel UI
  ├── Main.java              - Program entry point
  └── README.txt             - This file

--------------------------------------------------------------------------------
OOP CONCEPTS USED:

  - Inheritance    : Customer, Seller, Admin all extend User
  - Encapsulation  : All fields are private with getters and setters
  - Polymorphism   : login() is overridden differently in each subclass
  - Abstraction    : User is an abstract class with abstract login()
  - MVC Pattern    : Model (model/), View (view/), Controller (controller/)

================================================================================
