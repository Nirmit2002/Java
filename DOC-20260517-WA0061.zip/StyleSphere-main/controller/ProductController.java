// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package controller;

import model.Product;
import java.util.ArrayList;
import java.util.List;

public class ProductController {

    private ArrayList<Product> products;
    private static int counter = 1;

    public ProductController() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product p) {
        products.add(p);
    }

    public void removeProduct(String productId) {
        Product toRemove = null;
        for (Product p : products) {
            if (p.getProductId().equals(productId)) {
                toRemove = p;
                break;
            }
        }
        if (toRemove != null) {
            products.remove(toRemove);
        }
    }

    // searches both name and category for the keyword
    public List<Product> searchProduct(String keyword) {
        List<Product> results = new ArrayList<>();
        String lower = keyword.toLowerCase();
        for (Product p : products) {
            if (p.getName().toLowerCase().contains(lower) ||
                p.getCategory().toLowerCase().contains(lower)) {
                results.add(p);
            }
        }
        return results;
    }

    public ArrayList<Product> getAllProducts() {
        return products;
    }

    public Product getProductById(String id) {
        for (Product p : products) {
            if (p.getProductId().equals(id)) {
                return p;
            }
        }
        return null;
    }

    public String generateProductId() {
        return "PRD-" + String.format("%03d", counter++);
    }

    public void loadSampleProducts() {
        products.add(new Product(generateProductId(),
            "Classic White Shirt",
            "Clean and crisp white shirt perfect for any occasion",
            29.99, "Tops", "Zara", "M", 50, 4.5, "mikebrown"));

        products.add(new Product(generateProductId(),
            "Slim Fit Jeans",
            "Comfortable slim fit jeans with a modern cut",
            59.99, "Bottoms", "Levis", "32", 30, 4.3, "mikebrown"));

        products.add(new Product(generateProductId(),
            "Floral Summer Dress",
            "Light and breezy floral dress for summer days",
            44.99, "Dresses", "H&M", "S", 25, 4.7, "mikebrown"));

        products.add(new Product(generateProductId(),
            "Leather Jacket",
            "Premium leather jacket with a sleek finish",
            129.99, "Outerwear", "Zara", "L", 15, 4.8, "mikebrown"));

        products.add(new Product(generateProductId(),
            "Running Sneakers",
            "Lightweight sneakers built for performance",
            89.99, "Footwear", "Nike", "42", 40, 4.6, "mikebrown"));

        products.add(new Product(generateProductId(),
            "Casual Hoodie",
            "Soft and warm hoodie for casual everyday wear",
            39.99, "Tops", "Adidas", "XL", 35, 4.2, "mikebrown"));

        products.add(new Product(generateProductId(),
            "Formal Blazer",
            "Sharp formal blazer for professional settings",
            149.99, "Outerwear", "Marks and Spencer", "M", 20, 4.9, "mikebrown"));

        products.add(new Product(generateProductId(),
            "Flare Trousers",
            "Trendy flare trousers with a retro vibe",
            49.99, "Bottoms", "H&M", "S", 28, 4.1, "mikebrown"));

        System.out.println("Sample products loaded successfully.");
    }
}
