// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package controller;

import model.Order;
import java.util.ArrayList;
import java.util.List;

public class OrderController {

    private ArrayList<Order> orders;

    public OrderController() {
        this.orders = new ArrayList<>();
    }

    public void placeOrder(Order order) {
        orders.add(order);
    }

    public void cancelOrder(String orderId) {
        for (Order o : orders) {
            if (o.getOrderId().equals(orderId)) {
                o.setStatus("Cancelled");
                System.out.println("Order " + orderId + " has been cancelled.");
                return;
            }
        }
        System.out.println("Order not found: " + orderId);
    }

    public ArrayList<Order> getAllOrders() {
        return orders;
    }

    public List<Order> getOrdersByCustomer(String username) {
        List<Order> result = new ArrayList<>();
        for (Order o : orders) {
            if (o.getCustomerUsername().equals(username)) {
                result.add(o);
            }
        }
        return result;
    }
}
