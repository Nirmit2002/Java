// StyleSphere - Smart Fashion E-commerce Platform
// ICT 602 - Software Engineering, Semester 1 2026
// Group 17 Adelaide

package controller;

import model.User;
import java.util.ArrayList;

public class AuthController {

    private ArrayList<User> users;

    public AuthController() {
        this.users = new ArrayList<>();
    }

    public void registerUser(User user) {
        users.add(user);
        System.out.println("User \"" + user.getUsername() + "\" registered successfully!");
    }

    // loops through and checks both username and password match
    public User loginUser(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }

    public boolean userExists(String username) {
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<User> getAllUsers() {
        return users;
    }

    public User getUserByUsername(String username) {
        for (User u : users) {
            if (u.getUsername().equals(username)) {
                return u;
            }
        }
        return null;
    }
}
